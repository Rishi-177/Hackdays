/**
 * CarbonPilot — Core Domain Types and Data Models
 * Carbon- and Latency-Aware Agent Workflow Scheduler
 */

export type ModelTier = 'small' | 'medium' | 'large' | 'frontier';

export type NodeStatus = 
  | 'pending'
  | 'scheduled'
  | 'running'
  | 'completed'
  | 'escalated'
  | 'failed'
  | 'delayed';

export type NodeType = 
  | 'triage'
  | 'retrieval'
  | 'generation'
  | 'verifier'
  | 'synthesis'
  | 'action';

export type Priority = 'low' | 'medium' | 'high' | 'critical';

export interface DecisionReason {
  headline: string;
  explanation: string;
  tradeOffs?: string;
  confidenceScore?: number;
  policyTriggered?: string;
}

export interface WorkflowNode {
  id: string;
  name: string;
  type: NodeType;
  status: NodeStatus;
  model: string;
  modelTier: ModelTier;
  estimatedLatencyMs: number;
  estimatedCarbonGrams: number; // in gCO₂e
  estimatedCostUsd: number;
  qualityConfidence: number; // 0 to 100
  requiredQualityThreshold: number; // 0 to 100
  priority: Priority;
  deadlineMs: number;
  slackMs: number;
  dependencies: string[]; // parent node IDs
  decisionReason: DecisionReason;
  actualExecution?: {
    latencyMs: number;
    carbonGrams: number;
    costUsd: number;
    achievedQuality: number;
  };
  position?: {
    x: number;
    y: number;
  };
}

export interface WorkflowEdge {
  id: string;
  source: string;
  target: string;
  label?: string;
  isCriticalPath?: boolean;
}

export interface WorkflowMetrics {
  totalCarbonGrams: number; // Total estimated or actual carbon in gCO₂e
  totalLatencyMs: number; // Total critical path latency in ms
  totalCostUsd: number; // Total cost in USD
  carbonSavedGrams: number; // Savings compared to default frontier-model baseline
  carbonSavingsPercent: number; // Percentage saved
  latencySavedMs: number; // Latency reduction vs sequential execution
  confidenceAverage: number; // Average workflow confidence percentage
  nodesCount: number;
  criticalPathDurationMs: number;
  currentGridIntensity: number; // gCO₂e/kWh of current target datacenter
  gridRegion: string;
  budgetStatus: 'within_budget' | 'warning' | 'exceeded';
}

export interface Workflow {
  id: string;
  name: string;
  description: string;
  createdAt: string;
  status: 'draft' | 'optimizing' | 'optimized' | 'executing' | 'completed' | 'failed';
  nodes: WorkflowNode[];
  edges: WorkflowEdge[];
  metrics: WorkflowMetrics;
  deadlineBudgetMs: number;
  carbonBudgetGrams: number;
}

export interface Agent {
  id: string;
  name: string;
  role: string;
  assignedModel: string;
  currentStatus: 'idle' | 'executing' | 'paused' | 'escalated';
  carbonBurnRate: number; // gCO₂e/min
  lastConfidence: number;
}

export interface AgentDecision {
  nodeId: string;
  nodeName: string;
  agentId: string;
  timestamp: string;
  chosenModel: string;
  action: 'execute_now' | 'delay_for_cleaner_grid' | 'escalate_model' | 'parallelize' | 'cancel_redundant';
  rationale: string;
  carbonImpactGrams: number;
  latencyImpactMs: number;
}

export interface QualityCheck {
  id: string;
  nodeId: string;
  nodeName: string;
  checkName: string;
  confidence: number;
  threshold: number;
  passed: boolean;
  escalationRequired: boolean;
  escalatedToModel?: string;
  explanation: string;
  timestamp: string;
}

export interface CarbonBudget {
  allocatedGrams: number; // Allocated budget in gCO₂e
  consumedGrams: number; // Burnt carbon so far
  projectedRemainingGrams: number;
  currentRunRateGramsPerHour: number;
  status: 'healthy' | 'warning' | 'critical';
  resetPeriod: string;
  lastOptimizedAt: string;
}

export interface SchedulingDecision {
  decisionId: string;
  workflowId: string;
  timestamp: string;
  summary: string;
  carbonReductionGrams: number;
  latencyVarianceMs: number;
  details: {
    nodeId: string;
    nodeName: string;
    action: string;
    reason: string;
  }[];
}

export interface WhatIfScenario {
  id: string;
  name: string;
  description: string;
  carbonBudgetSliderGrams: number;
  latencyDeadlineSliderMs: number;
  minQualityThresholdSlider: number;
  gridIntensityOverrideGramsPerKwh?: number;
  projectedCarbonGrams: number;
  projectedLatencyMs: number;
  projectedCostUsd: number;
  tradeoffSummary: string;
}

export interface BaselineComparison {
  baselineName: string;
  baselineModelStrategy: string;
  baselineCarbonGrams: number;
  baselineLatencyMs: number;
  baselineCostUsd: number;
  baselineQuality: number;
  carbonPilotCarbonGrams: number;
  carbonPilotLatencyMs: number;
  carbonPilotCostUsd: number;
  carbonPilotQuality: number;
  carbonDeltaPercent: number; // e.g. -48%
  latencyDeltaPercent: number; // e.g. -32%
  costDeltaPercent: number; // e.g. -54%
  qualityDeltaPercent: number; // e.g. +1%
}

export interface DemoScenario {
  id: string;
  title: string;
  category: string;
  description: string;
  highlightFeature: string;
  initialBudgetGrams: number;
  initialDeadlineMs: number;
  workflowPreset: Workflow;
}

export type NavigationTabId = 
  | 'overview'
  | 'optimizer'
  | 'quality'
  | 'budget'
  | 'what-if'
  | 'deadline'
  | 'playground'
  | 'comparison'
  | 'demo'
  | 'settings'
  | 'design-system';

export interface NavigationItem {
  id: NavigationTabId;
  label: string;
  description: string;
  iconName: string;
  badge?: string;
  badgeVariant?: 'default' | 'success' | 'warning' | 'outline';
  isPlanned?: boolean; // Indicates a planned future view in the foundation
}
