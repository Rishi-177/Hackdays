/**
 * CarbonPilot Workflow Service Interface & Mock Implementation
 * Decouples visual UI components from data fetching and backend execution.
 */

import {
  Workflow,
  WorkflowMetrics,
  Agent,
  CarbonBudget,
  QualityCheck,
  SchedulingDecision,
  WhatIfScenario,
  BaselineComparison,
  DemoScenario,
} from '../types';
import {
  PRIMARY_WORKFLOW,
  PRIMARY_WORKFLOW_METRICS,
  MOCK_AGENTS,
  MOCK_CARBON_BUDGET,
  MOCK_BASELINE_COMPARISON,
  MOCK_WHAT_IF_SCENARIOS,
  MOCK_DEMO_SCENARIOS,
} from './mockData';

export interface IWorkflowService {
  getWorkflow(workflowId?: string): Promise<Workflow>;
  getWorkflowMetrics(workflowId?: string): Promise<WorkflowMetrics>;
  getAgentStatus(): Promise<Agent[]>;
  getCarbonBudget(): Promise<CarbonBudget>;
  runQualityGate(nodeId: string): Promise<QualityCheck>;
  runScheduler(workflowId: string): Promise<SchedulingDecision>;
  simulateWhatIf(params: Partial<WhatIfScenario>): Promise<WhatIfScenario>;
  getBaselineComparison(workflowId?: string): Promise<BaselineComparison>;
  getDemoScenarios(): Promise<DemoScenario[]>;
}

class MockWorkflowService implements IWorkflowService {
  private workflowState: Workflow = JSON.parse(JSON.stringify(PRIMARY_WORKFLOW));
  private budgetState: CarbonBudget = JSON.parse(JSON.stringify(MOCK_CARBON_BUDGET));

  async getWorkflow(workflowId?: string): Promise<Workflow> {
    // Simulated micro-delay representing fast local service retrieval
    return Promise.resolve({ ...this.workflowState });
  }

  async getWorkflowMetrics(workflowId?: string): Promise<WorkflowMetrics> {
    return Promise.resolve({ ...this.workflowState.metrics });
  }

  async getAgentStatus(): Promise<Agent[]> {
    return Promise.resolve([...MOCK_AGENTS]);
  }

  async getCarbonBudget(): Promise<CarbonBudget> {
    return Promise.resolve({ ...this.budgetState });
  }

  async runQualityGate(nodeId: string): Promise<QualityCheck> {
    const node = this.workflowState.nodes.find((n) => n.id === nodeId);
    const confidence = node ? node.qualityConfidence : 94;
    const threshold = node ? node.requiredQualityThreshold : 90;
    const passed = confidence >= threshold;

    return Promise.resolve({
      id: `qc-${Date.now()}`,
      nodeId,
      nodeName: node ? node.name : 'Unknown Node',
      checkName: 'Hallucination & Policy Conformance Gate',
      confidence,
      threshold,
      passed,
      escalationRequired: !passed,
      escalatedToModel: !passed ? 'Gemini 2.5 Pro' : undefined,
      explanation: passed
        ? `Quality score of ${confidence}% meets or exceeds the required safety threshold of ${threshold}%. No model escalation required.`
        : `Quality score of ${confidence}% fell below the safety threshold of ${threshold}%. Escalating to frontier model to guarantee compliance.`,
      timestamp: new Date().toISOString(),
    });
  }

  async runScheduler(workflowId: string): Promise<SchedulingDecision> {
    return Promise.resolve({
      decisionId: `dec-${Date.now()}`,
      workflowId: workflowId || this.workflowState.id,
      timestamp: new Date().toISOString(),
      summary: 'Optimal global DAG plan found: 59.6% carbon reduction with zero SLA deadline violations.',
      carbonReductionGrams: 36.8,
      latencyVarianceMs: -890,
      details: [
        {
          nodeId: 'node-triage',
          nodeName: 'Triage & Intent Classifier',
          action: 'Select Gemini 2.5 Flash',
          reason: 'High inherent classification confidence (96%) enables low-carbon model routing.',
        },
        {
          nodeId: 'node-doc-analysis',
          nodeName: 'Multimodal Contract Extraction',
          action: 'Parallelize with Policy Retrieval',
          reason: 'Independent input dependencies permit concurrent execution, reducing critical path latency by 320ms.',
        },
        {
          nodeId: 'node-synthesis',
          nodeName: 'Risk Synthesis & Remediation',
          action: 'Allocate Gemini 2.5 Pro from Saved Carbon Surplus',
          reason: 'Early stage carbon savings (36.8 gCO₂e) freed up budget for frontier synthesis reasoning.',
        },
      ],
    });
  }

  async simulateWhatIf(params: Partial<WhatIfScenario>): Promise<WhatIfScenario> {
    const base = MOCK_WHAT_IF_SCENARIOS[0];
    const budget = params.carbonBudgetSliderGrams ?? base.carbonBudgetSliderGrams;
    const deadline = params.latencyDeadlineSliderMs ?? base.latencyDeadlineSliderMs;
    const quality = params.minQualityThresholdSlider ?? base.minQualityThresholdSlider;

    // Deterministic simulation heuristic for responsive what-if analysis
    const isUltraGreen = budget < 30;
    const isRush = deadline < 2000;

    let projectedCarbon = 24.9;
    let projectedLatency = 2160;
    let projectedCost = 0.0093;
    let tradeoff = 'Balanced operational configuration.';

    if (isUltraGreen) {
      projectedCarbon = Math.max(12, budget * 0.85);
      projectedLatency = Math.min(5200, deadline * 1.5);
      projectedCost = 0.0045;
      tradeoff = 'Maximizes carbon savings by deferring batch synthesis and selecting lean models.';
    } else if (isRush) {
      projectedCarbon = 44.5;
      projectedLatency = Math.min(1400, deadline * 0.95);
      projectedCost = 0.0195;
      tradeoff = 'Prioritizes maximum execution speed to satisfy aggressive deadline SLA.';
    }

    return Promise.resolve({
      id: `sim-${Date.now()}`,
      name: 'Simulated Dynamic Plan',
      description: 'Parametric optimization output based on active constraint adjustments.',
      carbonBudgetSliderGrams: budget,
      latencyDeadlineSliderMs: deadline,
      minQualityThresholdSlider: quality,
      projectedCarbonGrams: Number(projectedCarbon.toFixed(1)),
      projectedLatencyMs: Math.round(projectedLatency),
      projectedCostUsd: Number(projectedCost.toFixed(4)),
      tradeoffSummary: tradeoff,
    });
  }

  async getBaselineComparison(workflowId?: string): Promise<BaselineComparison> {
    return Promise.resolve({ ...MOCK_BASELINE_COMPARISON });
  }

  async getDemoScenarios(): Promise<DemoScenario[]> {
    return Promise.resolve([...MOCK_DEMO_SCENARIOS]);
  }
}

export const workflowService: IWorkflowService = new MockWorkflowService();
