/**
 * CarbonPilot — Carbon- and Latency-Aware Agent Workflow Scheduler
 * Root Application Shell & Main Dashboard
 */

import React, { useState, useEffect } from 'react';
import {
  NavigationTabId,
  Workflow,
  WorkflowMetrics,
  CarbonBudget,
  BaselineComparison,
} from './types';
import { workflowService } from './services/workflowService';
import { AppHeader } from './components/layout/AppHeader';
import { Sidebar } from './components/layout/Sidebar';
import { OverviewView } from './components/views/OverviewView';
import { WorkflowView } from './components/views/WorkflowView';
import { QualityEscalationView } from './components/views/QualityEscalationView';
import { CarbonBudgetView } from './components/views/CarbonBudgetView';
import { DeadlineSlackView } from './components/views/DeadlineSlackView';
import { WhatIfSimulatorView } from './components/views/WhatIfSimulatorView';
import { BaselineComparisonView } from './components/views/BaselineComparisonView';
import { DemoModeView } from './components/views/DemoModeView';
import { LoadingState } from './components/design-system/LoadingState';
import { LandingPage } from './components/landing/LandingPage';
import { DesignSystemShowcase } from './components/views/DesignSystemShowcase';
import { PlaceholderPage } from './components/common/PlaceholderPage';
import {
  GitMerge,
  ShieldCheck,
  Leaf,
  Scale,
  Sliders,
  Clock,
  PlayCircle,
  Sparkles,
} from 'lucide-react';

export default function App() {
  const [pageMode, setPageMode] = useState<'landing' | 'dashboard'>(() => {
    if (typeof window !== 'undefined') {
      if (
        window.location.pathname === '/dashboard' ||
        window.location.pathname.startsWith('/dashboard') ||
        window.location.hash.includes('dashboard')
      ) {
        return 'dashboard';
      }
    }
    return 'landing';
  });

  const [currentTab, setCurrentTab] = useState<NavigationTabId>('overview');
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  // Workflow Service State
  const [workflow, setWorkflow] = useState<Workflow | null>(null);
  const [metrics, setMetrics] = useState<WorkflowMetrics | null>(null);
  const [budget, setBudget] = useState<CarbonBudget | null>(null);
  const [baseline, setBaseline] = useState<BaselineComparison | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [isRunningScheduler, setIsRunningScheduler] = useState(false);

  // Sync browser URL / history changes
  useEffect(() => {
    const handleLocationChange = () => {
      const hash = window.location.hash.toLowerCase();
      const path = window.location.pathname.toLowerCase();

      if (path === '/workflow' || hash.includes('workflow') || hash.includes('optimizer')) {
        setPageMode('dashboard');
        setCurrentTab('optimizer');
      } else if (path === '/quality' || hash.includes('quality')) {
        setPageMode('dashboard');
        setCurrentTab('quality');
      } else if (path === '/budget' || hash.includes('budget')) {
        setPageMode('dashboard');
        setCurrentTab('budget');
      } else if (path === '/deadline' || hash.includes('deadline')) {
        setPageMode('dashboard');
        setCurrentTab('deadline');
      } else if (path === '/what-if' || hash.includes('what-if') || hash.includes('whatif')) {
        setPageMode('dashboard');
        setCurrentTab('what-if');
      } else if (path === '/comparison' || hash.includes('comparison') || hash.includes('baseline')) {
        setPageMode('dashboard');
        setCurrentTab('comparison');
      } else if (path === '/demo' || hash.includes('demo')) {
        setPageMode('dashboard');
        setCurrentTab('demo');
      } else if (
        path === '/dashboard' ||
        path.startsWith('/dashboard') ||
        hash.includes('dashboard')
      ) {
        setPageMode('dashboard');
      } else if (path === '/' && !hash.includes('dashboard')) {
        setPageMode('landing');
      }
    };

    window.addEventListener('popstate', handleLocationChange);
    window.addEventListener('hashchange', handleLocationChange);
    return () => {
      window.removeEventListener('popstate', handleLocationChange);
      window.removeEventListener('hashchange', handleLocationChange);
    };
  }, []);

  // Fetch initial service data
  useEffect(() => {
    async function loadInitialData() {
      try {
        setIsLoading(true);
        const [wf, m, b, base] = await Promise.all([
          workflowService.getWorkflow(),
          workflowService.getWorkflowMetrics(),
          workflowService.getCarbonBudget(),
          workflowService.getBaselineComparison(),
        ]);
        setWorkflow(wf);
        setMetrics(m);
        setBudget(b);
        setBaseline(base);
      } catch (err) {
        console.error('Failed to load CarbonPilot foundation data', err);
      } finally {
        setIsLoading(false);
      }
    }
    loadInitialData();
  }, []);

  const navigateToDashboard = (tab: NavigationTabId = 'overview') => {
    setPageMode('dashboard');
    setCurrentTab(tab);
    if (typeof window !== 'undefined') {
      try {
        window.history.pushState(null, '', '/dashboard');
      } catch {
        // Fallback for strict sandbox iframe environments
        window.location.hash = 'dashboard';
      }
    }
  };

  const navigateToLanding = () => {
    setPageMode('landing');
    if (typeof window !== 'undefined') {
      try {
        window.history.pushState(null, '', '/');
      } catch {
        window.location.hash = '';
      }
    }
  };

  // Handler for triggering whole-workflow scheduler optimization
  const handleTriggerSchedulerRun = async () => {
    setIsRunningScheduler(true);
    try {
      await workflowService.runScheduler(workflow?.id || 'wf-compliance-pipeline-01');
      const updatedMetrics = await workflowService.getWorkflowMetrics();
      const updatedBudget = await workflowService.getCarbonBudget();
      setMetrics(updatedMetrics);
      setBudget(updatedBudget);
    } finally {
      setTimeout(() => {
        setIsRunningScheduler(false);
      }, 600);
    }
  };

  const renderActiveView = () => {
    if (isLoading || !workflow || !metrics || !budget || !baseline) {
      return (
        <div className="flex items-center justify-center min-h-[60vh]">
          <LoadingState
            message="Initializing CarbonPilot..."
            subtitle="Loading multimodal compliance workflow, agent telemetry, and carbon budget state"
          />
        </div>
      );
    }

    if (currentTab === 'overview') {
      return (
        <OverviewView
          workflow={workflow}
          metrics={metrics}
          budget={budget}
          baseline={baseline}
          onNavigateTab={(tab) => setCurrentTab(tab)}
          onTriggerSchedulerRun={handleTriggerSchedulerRun}
          isRunningScheduler={isRunningScheduler}
        />
      );
    }

    if (currentTab === 'optimizer') {
      return (
        <WorkflowView
          onNavigateToDesignSystem={() => setCurrentTab('design-system')}
        />
      );
    }

    switch (currentTab) {
      case 'design-system':
        return <DesignSystemShowcase />;

      case 'quality':
        return <QualityEscalationView />;

      case 'budget':
        return <CarbonBudgetView />;

      case 'comparison':
        return (
          <BaselineComparisonView
            onNavigateDemo={() => setCurrentTab('demo')}
            onNavigateOverview={() => setCurrentTab('overview')}
          />
        );

      case 'what-if':
        return <WhatIfSimulatorView />;

      case 'deadline':
        return <DeadlineSlackView />;

      case 'playground':
        return (
          <PlaceholderPage
            title="Agent Playground"
            description="Interactive execution sandbox to test prompt configurations and agent routing decisions."
            icon={PlayCircle}
            plannedFeatures={[
              'Live prompt execution with agent routing visualization',
              'Model tier switching simulator',
              'Instant explainable rationale generation',
            ]}
            onNavigateOverview={() => setCurrentTab('overview')}
          />
        );

      case 'demo':
        return (
          <DemoModeView
            onNavigateComparison={() => setCurrentTab('comparison')}
            onNavigateWorkflow={() => setCurrentTab('optimizer')}
          />
        );

      default:
        return (
          <OverviewView
            workflow={workflow}
            metrics={metrics}
            budget={budget}
            baseline={baseline}
            onNavigateTab={(tab) => setCurrentTab(tab)}
            onTriggerSchedulerRun={handleTriggerSchedulerRun}
            isRunningScheduler={isRunningScheduler}
          />
        );
    }
  };

  if (pageMode === 'landing') {
    return (
      <LandingPage
        onLaunchDashboard={() => navigateToDashboard('overview')}
        onLaunchDemo={() => navigateToDashboard('demo')}
      />
    );
  }

  return (
    <div className="min-h-screen bg-[#F7F8F5] text-[#0A0D0C] flex flex-col font-sans selection:bg-[#00D98B]/30 selection:text-[#0A0D0C]">
      {/* Top Header: Minimal, Clean, One Primary Action */}
      <AppHeader
        currentTab={currentTab}
        onSelectTab={setCurrentTab}
        mobileMenuOpen={mobileMenuOpen}
        onToggleMobileMenu={() => setMobileMenuOpen(!mobileMenuOpen)}
        workflowName="Multimodal Compliance Workflow"
        workflowStatus="Optimized"
        onTriggerSchedulerRun={handleTriggerSchedulerRun}
        isRunningScheduler={isRunningScheduler}
        onNavigateLanding={navigateToLanding}
      />

      <div className="flex-1 flex overflow-hidden">
        {/* Left Sidebar Navigation */}
        <div className="hidden lg:block">
          <Sidebar
            currentTab={currentTab}
            onSelectTab={setCurrentTab}
            carbonBudgetConsumed={budget?.consumedGrams || 24.9}
            carbonBudgetAllocated={budget?.allocatedGrams || 50.0}
            onNavigateLanding={navigateToLanding}
          />
        </div>

        {/* Mobile Collapsible Sidebar Drawer */}
        {mobileMenuOpen && (
          <div className="fixed inset-0 z-50 lg:hidden flex">
            <div
              className="fixed inset-0 bg-[#0A0D0C]/35 backdrop-blur-xs"
              onClick={() => setMobileMenuOpen(false)}
            />
            <div className="relative z-10 w-72 bg-[#FFFFFF] border-r border-[#DDE2DE] h-full shadow-2xl">
              <Sidebar
                currentTab={currentTab}
                onSelectTab={setCurrentTab}
                carbonBudgetConsumed={budget?.consumedGrams || 24.9}
                carbonBudgetAllocated={budget?.allocatedGrams || 50.0}
                onCloseMobile={() => setMobileMenuOpen(false)}
                onNavigateLanding={navigateToLanding}
              />
            </div>
          </div>
        )}

        {/* Main Content Area */}
        <main className="flex-1 overflow-y-auto p-4 sm:p-6 lg:p-8 bg-[#F7F8F5]">
          {renderActiveView()}
        </main>
      </div>
    </div>
  );
}
