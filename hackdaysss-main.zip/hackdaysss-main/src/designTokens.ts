/**
 * CarbonPilot Global Design Token System
 *
 * Unified visual identity across Landing Page & Dashboard:
 * - BACKGROUND: Warm off-white #F7F8F5
 * - PRIMARY SURFACE: White #FFFFFF
 * - PRIMARY TEXT: Near black #0A0D0C
 * - SECONDARY TEXT: Muted charcoal #68706B
 * - SUBTLE TEXT: #8A918D
 * - BORDERS: Very light neutral #DDE2DE
 * - STRONGER BORDER: #C9D0CB
 * - PRIMARY GREEN: #00D98B (Brand accent)
 * - DARK GREEN FOR TEXT/DETAILS: #007A52
 * - VERY LIGHT GREEN SURFACE: #E7F8F1
 * - WARNING: Restrained warm amber #D97706
 * - ERROR: Restrained red #DC2626
 */

export const tokens = {
  colors: {
    background: '#F7F8F5',       // Warm off-white canvas
    surface: '#FFFFFF',          // Pure white surface
    surfaceMuted: '#F0F2EE',     // Subtle warm neutral surface
    surfaceHover: '#F4F6F2',     // Hover state surface
    surfaceActive: '#E7F8F1',    // Selected / active state surface (very light green)
    border: '#DDE2DE',           // Very light neutral border
    borderStrong: '#C9D0CB',     // Stronger divider / container border
    borderFocus: '#00D98B',      // Active focused border
    text: {
      primary: '#0A0D0C',        // Near black high-contrast primary text
      secondary: '#68706B',      // Muted charcoal secondary text
      muted: '#8A918D',          // Subtle gray text / timestamps
      inverse: '#FFFFFF',        // White text on dark/green buttons
      accent: '#007A52',         // Dark green for text & details
      brand: '#00D98B',          // Primary green text
    },
    accent: {
      primary: '#00D98B',        // Signature vivid green
      hover: '#00C47D',          // Refined green hover
      active: '#00B070',         // Pressed green
      dark: '#007A52',           // Dark green for high readability on light surfaces
      soft: '#E7F8F1',           // Very light green tint
      border: 'rgba(0, 217, 139, 0.4)',
    },
    state: {
      success: {
        bg: '#E7F8F1',
        text: '#007A52',
        border: 'rgba(0, 217, 139, 0.35)',
      },
      warning: {
        bg: '#FFFBEB',
        text: '#B45309',
        border: '#FDE68A',
      },
      error: {
        bg: '#FEF2F2',
        text: '#B91C1C',
        border: '#FECACA',
      },
      neutral: {
        bg: '#F7F8F5',
        text: '#68706B',
        border: '#DDE2DE',
      },
    },
  },
  typography: {
    fontFamily: {
      sans: "'Plus Jakarta Sans', system-ui, -apple-system, sans-serif",
      mono: "'JetBrains Mono', ui-monospace, monospace",
    },
    scale: {
      hero: 'clamp(2.5rem, 5vw + 1rem, 4.25rem)',
      sectionTitle: 'clamp(1.75rem, 3vw + 0.5rem, 2.5rem)',
      cardTitle: '1.125rem',
      body: '0.9375rem',
      small: '0.8125rem',
      caption: '0.6875rem',
    },
  },
  spacing: {
    sectionPaddingY: 'py-20 sm:py-28',
    sectionPaddingX: 'px-4 sm:px-6 lg:px-8',
    containerMax: 'max-w-6xl mx-auto',
  },
  radius: {
    sm: '0.375rem',
    md: '0.5rem',
    lg: '0.75rem',
    xl: '1rem',
    '2xl': '1.25rem',
    full: '9999px',
  },
  shadow: {
    subtle: '0 1px 3px rgba(10, 13, 12, 0.04), 0 1px 2px rgba(10, 13, 12, 0.02)',
    card: '0 2px 8px rgba(10, 13, 12, 0.04), 0 1px 2px rgba(10, 13, 12, 0.02)',
    popover: '0 10px 30px rgba(10, 13, 12, 0.08), 0 2px 8px rgba(10, 13, 12, 0.04)',
  },
} as const;

export type DesignTokens = typeof tokens;
