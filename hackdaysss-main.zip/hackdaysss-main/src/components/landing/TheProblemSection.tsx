import React from 'react';
import { X, Check } from 'lucide-react';

export const TheProblemSection: React.FC = () => {
  return (
    <section id="why-carbonpilot" className="py-24 sm:py-32 border-t border-[#DDE2DE] bg-[#F7F8F5]">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 space-y-14">
        {/* Section Header */}
        <div className="space-y-3 max-w-2xl">
          <div className="inline-flex items-center gap-2 text-xs font-mono font-medium text-[#007A52] tracking-wider uppercase">
            <span className="w-1.5 h-1.5 rounded-full bg-[#00D98B]" />
            The Architectural Shift
          </div>
          <h2 className="text-3xl sm:text-4xl font-extrabold tracking-tight text-[#0A0D0C] leading-tight">
            AI workflows contain multiple decisions. <br className="hidden sm:block" />
            Isolated execution wastes carbon.
          </h2>
          <p className="text-[#68706B] text-sm sm:text-base leading-relaxed">
            Traditional pipelines route every sub-task independently without considering upstream results, slack windows, or future steps. CarbonPilot orchestrates the entire workflow as a unified graph.
          </p>
        </div>

        {/* Visual Comparison: Left (Run Everything Now) vs Right (CarbonPilot) */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 sm:gap-8">
          {/* LEFT: Run Everything Now */}
          <div className="rounded-2xl border border-[#DDE2DE] bg-[#FFFFFF] p-6 sm:p-8 flex flex-col justify-between space-y-6 shadow-sm">
            <div className="space-y-4">
              <div className="flex items-center justify-between pb-3 border-b border-[#DDE2DE]">
                <div className="flex items-center gap-2">
                  <div className="w-5 h-5 rounded-full bg-[#FEF2F2] border border-[#FECACA] text-[#B91C1C] flex items-center justify-center">
                    <X className="w-3 h-3" />
                  </div>
                  <span className="text-xs font-mono font-semibold uppercase tracking-wider text-[#B91C1C]">
                    Traditional Approach
                  </span>
                </div>
                <span className="text-xs font-mono text-[#8A918D]">Run Everything Now</span>
              </div>

              <h3 className="text-lg sm:text-xl font-bold text-[#0A0D0C]">
                Every task runs on the largest model immediately
              </h3>
              <p className="text-sm text-[#68706B] leading-relaxed">
                Sub-steps like extraction, intent categorization, and format conversion are assigned heavy frontier models. Non-urgent background steps execute instantly during peak fossil grid hours.
              </p>

              {/* Step by step execution trace */}
              <div className="space-y-2 pt-2">
                <div className="flex items-center justify-between p-2.5 rounded-lg bg-[#F7F8F5] border border-[#DDE2DE] text-xs">
                  <span className="text-[#0A0D0C] font-mono">1. Extraction</span>
                  <span className="text-[#B91C1C] font-mono font-medium">Frontier Model (0.28 gCO₂e)</span>
                </div>
                <div className="flex items-center justify-between p-2.5 rounded-lg bg-[#F7F8F5] border border-[#DDE2DE] text-xs">
                  <span className="text-[#0A0D0C] font-mono">2. Summarization</span>
                  <span className="text-[#B91C1C] font-mono font-medium">Frontier Model (0.42 gCO₂e)</span>
                </div>
                <div className="flex items-center justify-between p-2.5 rounded-lg bg-[#F7F8F5] border border-[#DDE2DE] text-xs">
                  <span className="text-[#0A0D0C] font-mono">3. Synthesis</span>
                  <span className="text-[#B91C1C] font-mono font-medium">Frontier Model (0.55 gCO₂e)</span>
                </div>
              </div>
            </div>

            {/* Bottom Outcome Metric */}
            <div className="pt-4 border-t border-[#DDE2DE] flex items-center justify-between">
              <div>
                <span className="text-[11px] text-[#68706B] font-mono uppercase">Total Emissions</span>
                <div className="text-xl font-bold text-[#0A0D0C] font-mono">41.2 gCO₂e</div>
              </div>
              <div className="text-right">
                <span className="text-[11px] text-[#68706B] font-mono uppercase">Budget Efficiency</span>
                <div className="text-sm font-semibold text-[#B91C1C]">Rigid &amp; Uncoordinated</div>
              </div>
            </div>
          </div>

          {/* RIGHT: CarbonPilot */}
          <div className="rounded-2xl border border-[#00D98B]/50 bg-[#FFFFFF] p-6 sm:p-8 flex flex-col justify-between space-y-6 ring-1 ring-[#00D98B]/20 shadow-[0_2px_12px_rgba(10,13,12,0.04)]">
            <div className="space-y-4">
              <div className="flex items-center justify-between pb-3 border-b border-[#DDE2DE]">
                <div className="flex items-center gap-2">
                  <div className="w-5 h-5 rounded-full bg-[#E7F8F1] border border-[#DDE2DE] text-[#007A52] flex items-center justify-center">
                    <Check className="w-3 h-3 text-[#00D98B]" />
                  </div>
                  <span className="text-xs font-mono font-semibold uppercase tracking-wider text-[#007A52]">
                    CarbonPilot Approach
                  </span>
                </div>
                <span className="text-xs font-mono text-[#007A52] font-semibold">Whole-Workflow Coordination</span>
              </div>

              <h3 className="text-lg sm:text-xl font-bold text-[#0A0D0C]">
                Coordinated routing across models, quality gates, and time
              </h3>
              <p className="text-sm text-[#68706B] leading-relaxed">
                Early routine steps execute on fast, lightweight models. Quality gates verify confidence before advancing. Non-critical tasks shift into clean grid windows, leaving ample carbon budget for the final high-impact synthesis.
              </p>

              {/* Step by step execution trace */}
              <div className="space-y-2 pt-2">
                <div className="flex items-center justify-between p-2.5 rounded-lg bg-[#F7F8F5] border border-[#DDE2DE] text-xs">
                  <span className="text-[#0A0D0C] font-mono">1. Extraction</span>
                  <div className="flex items-center gap-2">
                    <span className="text-[#68706B] text-[11px]">Flash + Quality Gate</span>
                    <span className="text-[#007A52] font-mono font-bold">0.05 gCO₂e</span>
                  </div>
                </div>
                <div className="flex items-center justify-between p-2.5 rounded-lg bg-[#F7F8F5] border border-[#DDE2DE] text-xs">
                  <span className="text-[#0A0D0C] font-mono">2. Background Index</span>
                  <div className="flex items-center gap-2">
                    <span className="text-[#68706B] text-[11px]">Shifted 18m to clean grid</span>
                    <span className="text-[#007A52] font-mono font-bold">0.03 gCO₂e</span>
                  </div>
                </div>
                <div className="flex items-center justify-between p-2.5 rounded-lg bg-[#F7F8F5] border border-[#DDE2DE] text-xs">
                  <span className="text-[#0A0D0C] font-mono">3. Synthesis</span>
                  <div className="flex items-center gap-2">
                    <span className="text-[#68706B] text-[11px]">Frontier (Funded by savings)</span>
                    <span className="text-[#0A0D0C] font-mono font-semibold">0.38 gCO₂e</span>
                  </div>
                </div>
              </div>
            </div>

            {/* Bottom Outcome Metric */}
            <div className="pt-4 border-t border-[#DDE2DE] flex items-center justify-between">
              <div>
                <span className="text-[11px] text-[#68706B] font-mono uppercase">Total Emissions</span>
                <div className="text-xl font-bold text-[#007A52] font-mono">
                  8.4 gCO₂e <span className="text-xs font-medium text-[#007A52]">(-79.6%)</span>
                </div>
              </div>
              <div className="text-right">
                <span className="text-[11px] text-[#68706B] font-mono uppercase">Verified Accuracy</span>
                <div className="text-sm font-semibold text-[#007A52] flex items-center justify-end gap-1">
                  <Check className="w-3.5 h-3.5 text-[#00D98B]" />
                  <span>95.4% (Preserved Quality)</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
