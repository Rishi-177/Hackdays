import React, { useState } from 'react';
import { Check, AlertCircle } from 'lucide-react';

export const InteractiveDecisionDemo: React.FC = () => {
  // Slider values: 0 = Standard (Speed Priority), 1 = Balanced, 2 = Maximum Carbon Priority
  const [priorityLevel, setPriorityLevel] = useState<number>(1);

  const configs = [
    {
      level: 0,
      label: 'Speed Priority',
      description: 'Minimum latency, unconstrained emissions',
      workflowSteps: [
        {
          name: 'Task 1: Search & Filter',
          model: 'Frontier Heavy',
          timing: 'Execute Immediately',
          gate: 'None (Bypassed)',
          carbon: '18.4 gCO₂e',
          latency: '420 ms',
          isGreen: false,
        },
        {
          name: 'Task 2: Background Indexing',
          model: 'Frontier Heavy',
          timing: 'Execute Immediately (Peak Grid)',
          gate: 'None',
          carbon: '14.2 gCO₂e',
          latency: '510 ms',
          isGreen: false,
        },
        {
          name: 'Task 3: Synthesis',
          model: 'Frontier Heavy',
          timing: 'Execute Immediately',
          gate: 'None',
          carbon: '24.1 gCO₂e',
          latency: '480 ms',
          isGreen: false,
        },
      ],
      metrics: {
        carbon: '56.7 gCO₂e',
        carbonDelta: 'Baseline (+0%)',
        latency: '1,410 ms',
        latencyDelta: 'Fastest',
        quality: '96.2%',
        deadline: 'Met (Within SLA)',
      },
    },
    {
      level: 1,
      label: 'Balanced Optimization',
      description: 'Whole-workflow routing with automated quality gates',
      workflowSteps: [
        {
          name: 'Task 1: Search & Filter',
          model: 'Flash Tier (Lightweight)',
          timing: 'Execute Immediately',
          gate: 'Quality Gate: 94.8% Confirmed',
          carbon: '3.6 gCO₂e',
          latency: '240 ms',
          isGreen: true,
        },
        {
          name: 'Task 2: Background Indexing',
          model: 'Flash Tier (Lightweight)',
          timing: 'Parallel Execution',
          gate: 'Verified',
          carbon: '2.8 gCO₂e',
          latency: '280 ms',
          isGreen: true,
        },
        {
          name: 'Task 3: Synthesis',
          model: 'Frontier Model (Funded by Savings)',
          timing: 'Execute Immediately',
          gate: 'Confidence Gate: Passed',
          carbon: '15.2 gCO₂e',
          latency: '720 ms',
          isGreen: true,
        },
      ],
      metrics: {
        carbon: '21.6 gCO₂e',
        carbonDelta: '-61.9% Carbon',
        latency: '1,240 ms',
        latencyDelta: '-170 ms (Parallel)',
        quality: '95.8%',
        deadline: 'Met (Within SLA)',
      },
    },
    {
      level: 2,
      label: 'Maximum Carbon Priority',
      description: 'Aggressive right-sizing + slack shifted to clean energy window',
      workflowSteps: [
        {
          name: 'Task 1: Search & Filter',
          model: 'Flash Tier (Lightweight)',
          timing: 'Execute Immediately',
          gate: 'Quality Gate: 94.2% Confirmed',
          carbon: '3.6 gCO₂e',
          latency: '240 ms',
          isGreen: true,
        },
        {
          name: 'Task 2: Background Indexing',
          model: 'Flash Tier (Lightweight)',
          timing: 'Shifted 18m to clean energy window',
          gate: 'Scheduled into Slack',
          carbon: '0.8 gCO₂e',
          latency: 'Slack used (non-critical)',
          isGreen: true,
        },
        {
          name: 'Task 3: Synthesis',
          model: 'Pro Tier + Verification',
          timing: 'Immediate on Task 1 completion',
          gate: 'Verified: 94.4%',
          carbon: '6.4 gCO₂e',
          latency: '680 ms',
          isGreen: true,
        },
      ],
      metrics: {
        carbon: '10.8 gCO₂e',
        carbonDelta: '-80.9% Carbon',
        latency: '1,600 ms total path',
        latencyDelta: 'Acceptable SLA Slack',
        quality: '94.4%',
        deadline: 'Met (Within SLA)',
      },
    },
  ];

  const current = configs[priorityLevel];

  return (
    <section id="decision-demo" className="py-24 sm:py-32 border-t border-[#DDE2DE] bg-[#FFFFFF] relative">
      <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 space-y-12">
        {/* Section Header */}
        <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4">
          <div className="space-y-2">
            <div className="inline-flex items-center gap-2 text-xs font-mono font-medium text-[#007A52] tracking-wider uppercase">
              <span className="w-1.5 h-1.5 rounded-full bg-[#00D98B]" />
              Interactive Decision Demo
            </div>
            <h2 className="text-3xl sm:text-4xl font-extrabold tracking-tight text-[#0A0D0C] leading-tight">
              One workflow. Different priorities.
            </h2>
            <p className="text-[#68706B] text-sm max-w-xl">
              See how CarbonPilot reorganizes execution models, quality verification, and scheduling when operational priorities shift.
            </p>
          </div>

          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-md bg-[#F7F8F5] border border-[#DDE2DE] text-[#68706B] text-xs font-mono">
            <AlertCircle className="w-3.5 h-3.5 text-[#00D98B]" />
            <span>Simulated Example</span>
          </div>
        </div>

        {/* Priority Slider Control */}
        <div className="rounded-2xl border border-[#DDE2DE] bg-[#FFFFFF] p-6 sm:p-8 space-y-6 shadow-sm">
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-xs font-mono uppercase tracking-wider text-[#68706B]">
                Carbon Optimization Priority
              </span>
              <span className="text-xs font-mono font-semibold text-[#007A52] px-2.5 py-0.5 rounded bg-[#E7F8F1] border border-[#DDE2DE]">
                {current.label}
              </span>
            </div>

            {/* Slider Track */}
            <div className="relative pt-2 pb-1">
              <input
                type="range"
                min="0"
                max="2"
                step="1"
                value={priorityLevel}
                onChange={(e) => setPriorityLevel(parseInt(e.target.value, 10))}
                className="w-full h-2 bg-[#DDE2DE] rounded-lg appearance-none cursor-pointer accent-[#00D98B] focus:outline-none"
              />
              <div className="flex justify-between text-[11px] font-mono text-[#68706B] mt-2">
                <button
                  onClick={() => setPriorityLevel(0)}
                  className={`hover:text-[#0A0D0C] transition-colors cursor-pointer ${
                    priorityLevel === 0 ? 'text-[#007A52] font-bold' : ''
                  }`}
                >
                  01 Speed Focused
                </button>
                <button
                  onClick={() => setPriorityLevel(1)}
                  className={`hover:text-[#0A0D0C] transition-colors cursor-pointer ${
                    priorityLevel === 1 ? 'text-[#007A52] font-bold' : ''
                  }`}
                >
                  02 Balanced
                </button>
                <button
                  onClick={() => setPriorityLevel(2)}
                  className={`hover:text-[#0A0D0C] transition-colors cursor-pointer ${
                    priorityLevel === 2 ? 'text-[#007A52] font-bold' : ''
                  }`}
                >
                  03 Max Carbon Savings
                </button>
              </div>
            </div>
            <p className="text-xs text-[#68706B] font-sans italic">
              {current.description}
            </p>
          </div>

          {/* Dynamic Workflow Steps */}
          <div className="space-y-3 pt-2">
            <span className="text-[11px] font-mono uppercase tracking-wider text-[#68706B] block">
              Workflow Execution Plan
            </span>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
              {current.workflowSteps.map((step, idx) => (
                <div
                  key={idx}
                  className="p-4 rounded-xl border border-[#DDE2DE] bg-[#F7F8F5] transition-all duration-200"
                >
                  <div className="flex items-center justify-between pb-2 border-b border-[#DDE2DE] text-xs">
                    <span className="font-semibold text-[#0A0D0C]">{step.name}</span>
                  </div>

                  <div className="space-y-2 pt-3 text-xs">
                    <div className="flex items-center justify-between">
                      <span className="text-[#68706B] font-mono text-[11px]">Model:</span>
                      <span
                        className={`font-mono text-[11px] font-medium ${
                          step.isGreen ? 'text-[#007A52] font-semibold' : 'text-[#0A0D0C]'
                        }`}
                      >
                        {step.model}
                      </span>
                    </div>

                    <div className="flex items-center justify-between">
                      <span className="text-[#68706B] font-mono text-[11px]">Timing:</span>
                      <span className="font-mono text-[11px] text-[#0A0D0C]">
                        {step.timing}
                      </span>
                    </div>

                    <div className="flex items-center justify-between">
                      <span className="text-[#68706B] font-mono text-[11px]">Verification:</span>
                      <span className="font-mono text-[11px] text-[#68706B]">
                        {step.gate}
                      </span>
                    </div>

                    <div className="pt-2 border-t border-[#DDE2DE] flex items-center justify-between text-[11px] font-mono">
                      <span className="text-[#68706B]">Emissions:</span>
                      <span
                        className={`font-bold ${
                          step.isGreen ? 'text-[#007A52]' : 'text-[#B91C1C]'
                        }`}
                      >
                        {step.carbon}
                      </span>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Summary Bar */}
          <div className="pt-4 border-t border-[#DDE2DE] grid grid-cols-2 sm:grid-cols-4 gap-4 text-center">
            <div className="p-3 rounded-lg bg-[#F7F8F5] border border-[#DDE2DE]">
              <span className="text-[10px] font-mono uppercase text-[#68706B] block">Carbon</span>
              <div className="text-base font-bold text-[#007A52] font-mono mt-0.5">
                {current.metrics.carbon}
              </div>
              <span className="text-[10px] font-mono text-[#68706B]">
                {current.metrics.carbonDelta}
              </span>
            </div>

            <div className="p-3 rounded-lg bg-[#F7F8F5] border border-[#DDE2DE]">
              <span className="text-[10px] font-mono uppercase text-[#68706B] block">Latency</span>
              <div className="text-base font-bold text-[#0A0D0C] font-mono mt-0.5">
                {current.metrics.latency}
              </div>
              <span className="text-[10px] font-mono text-[#68706B]">
                {current.metrics.latencyDelta}
              </span>
            </div>

            <div className="p-3 rounded-lg bg-[#F7F8F5] border border-[#DDE2DE]">
              <span className="text-[10px] font-mono uppercase text-[#68706B] block">Quality</span>
              <div className="text-base font-bold text-[#0A0D0C] font-mono mt-0.5 flex items-center justify-center gap-1">
                <Check className="w-3.5 h-3.5 text-[#00D98B]" />
                <span>{current.metrics.quality}</span>
              </div>
              <span className="text-[10px] font-mono text-[#007A52] font-medium">Confidence High</span>
            </div>

            <div className="p-3 rounded-lg bg-[#F7F8F5] border border-[#DDE2DE]">
              <span className="text-[10px] font-mono uppercase text-[#68706B] block">Deadline</span>
              <div className="text-base font-bold text-[#0A0D0C] font-mono mt-0.5 flex items-center justify-center gap-1">
                <Check className="w-3.5 h-3.5 text-[#00D98B]" />
                <span>Verified</span>
              </div>
              <span className="text-[10px] font-mono text-[#68706B]">{current.metrics.deadline}</span>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
