import React, { useState } from 'react';
import { Leaf, Clock, ShieldCheck, Coins, Calendar, Check } from 'lucide-react';

export const WhyWorkflowMatters: React.FC = () => {
  const [activeConstraint, setActiveConstraint] = useState<string>('carbon');

  const constraints = [
    {
      id: 'carbon',
      name: 'Carbon Emissions',
      short: 'CO₂e',
      icon: Leaf,
      question: 'How clean is the datacenter grid right now?',
      role: 'Reduces embodied & operational carbon by targeting green grid hours and right-sized model parameters.',
      rule: 'CarbonPilot never degrades quality just to minimize carbon.',
    },
    {
      id: 'latency',
      name: 'Path Latency',
      short: 'SLA ms',
      icon: Clock,
      question: 'Where is the critical execution path?',
      role: 'Calculates DAG parallel branches and isolates steps that truly impact user response times.',
      rule: 'Critical path steps run without artificial delays.',
    },
    {
      id: 'quality',
      name: 'Verified Quality',
      short: 'Score %',
      icon: ShieldCheck,
      question: 'Does the output satisfy accuracy criteria?',
      role: 'Automated verification gates confirm confidence before downstream tasks execute.',
      rule: 'Uncertain outputs trigger instant escalation to frontier models.',
    },
    {
      id: 'cost',
      name: 'Operational Cost',
      short: 'Token $',
      icon: Coins,
      question: 'Are token budgets being spent effectively?',
      role: 'Eliminates redundant large-model inferences on simple intermediary tasks.',
      rule: 'Reinvests token savings into high-impact final synthesis.',
    },
    {
      id: 'deadline',
      name: 'Deadline & Slack',
      short: 'Slack min',
      icon: Calendar,
      question: 'How much tolerance exists before SLA breach?',
      role: 'Identifies non-blocking tasks that can safely wait for lower-carbon renewable generation.',
      rule: 'Zero SLA breaches guaranteed through strict slack bounds.',
    },
  ];

  const current = constraints.find((c) => c.id === activeConstraint) || constraints[0];

  return (
    <section className="py-24 sm:py-32 border-t border-[#DDE2DE] bg-[#F7F8F5]">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 space-y-16">
        {/* Section Header */}
        <div className="space-y-3 max-w-2xl">
          <div className="inline-flex items-center gap-2 text-xs font-mono font-medium text-[#007A52] tracking-wider uppercase">
            <span className="w-1.5 h-1.5 rounded-full bg-[#00D98B]" />
            Holistic Optimization
          </div>
          <h2 className="text-3xl sm:text-4xl font-extrabold tracking-tight text-[#0A0D0C] leading-tight">
            Not simply "use the smallest model."
          </h2>
          <p className="text-[#68706B] text-sm sm:text-base leading-relaxed">
            Real enterprise AI operations cannot compromise on quality or miss user deadlines. CarbonPilot models five interdependent dimensions simultaneously.
          </p>
        </div>

        {/* Visual Interconnected Diagram of the 5 Constraints */}
        <div className="rounded-2xl border border-[#DDE2DE] bg-[#FFFFFF] p-6 sm:p-8 space-y-8 shadow-sm">
          {/* Interactive constraint tabs / pillars */}
          <div className="grid grid-cols-2 sm:grid-cols-5 gap-2 sm:gap-3">
            {constraints.map((item) => {
              const Icon = item.icon;
              const isSelected = item.id === activeConstraint;
              return (
                <button
                  key={item.id}
                  onClick={() => setActiveConstraint(item.id)}
                  className={`p-3.5 rounded-xl border text-left transition-all duration-150 flex flex-col justify-between cursor-pointer ${
                    isSelected
                      ? 'bg-[#E7F8F1] border-[#00D98B] ring-1 ring-[#00D98B] shadow-xs'
                      : 'bg-[#FFFFFF] border-[#DDE2DE] hover:border-[#C9D0CB] hover:bg-[#F7F8F5]'
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <div
                      className={`w-7 h-7 rounded flex items-center justify-center ${
                        isSelected
                          ? 'bg-[#00D98B] text-[#0A0D0C]'
                          : 'bg-[#F7F8F5] text-[#68706B]'
                      }`}
                    >
                      <Icon className="w-3.5 h-3.5" />
                    </div>
                    <span className="text-[10px] font-mono text-[#8A918D]">
                      {item.short}
                    </span>
                  </div>

                  <div className="mt-3">
                    <span className="text-xs font-bold text-[#0A0D0C] block">
                      {item.name}
                    </span>
                  </div>
                </button>
              );
            })}
          </div>

          {/* Active Constraint Inspector */}
          <div className="rounded-xl border border-[#DDE2DE] bg-[#F7F8F5] p-5 sm:p-6 space-y-4">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-[#DDE2DE]">
              <div className="flex items-center gap-2">
                <span className="text-xs font-mono text-[#68706B] uppercase">Constraint focus:</span>
                <span className="text-sm font-bold text-[#0A0D0C]">{current.name}</span>
              </div>
              <div className="text-xs font-mono text-[#007A52] font-semibold flex items-center gap-1.5">
                <Check className="w-3.5 h-3.5 text-[#00D98B]" />
                <span>{current.rule}</span>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 pt-1 text-xs">
              <div className="space-y-1">
                <span className="text-[#68706B] font-mono text-[11px] uppercase">Evaluation Query</span>
                <p className="text-[#0A0D0C] text-sm font-medium">
                  "{current.question}"
                </p>
              </div>
              <div className="space-y-1">
                <span className="text-[#68706B] font-mono text-[11px] uppercase">CarbonPilot Optimization Role</span>
                <p className="text-[#68706B] leading-relaxed font-sans">
                  {current.role}
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
