import React, { useState } from 'react';
import { Leaf, Clock, ShieldCheck, CheckCircle2, AlertTriangle, ArrowRight, RefreshCw, Cpu } from 'lucide-react';

export const DecisionComparisonDemo: React.FC = () => {
  const [activeTab, setActiveTab] = useState<'after' | 'before'>('after');

  return (
    <div className="rounded-2xl border border-slate-800 bg-slate-900/60 p-5 sm:p-7 space-y-6">
      {/* Top Header with Simulated Example disclaimer badge */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-4 border-b border-slate-800/80">
        <div>
          <h3 className="text-sm sm:text-base font-semibold text-slate-100">
            Interactive Decision Trace
          </h3>
          <p className="text-xs text-slate-400 mt-0.5">
            Compare how a single agent task executes under naive routing versus CarbonPilot whole-workflow scheduling.
          </p>
        </div>

        <div className="flex items-center gap-2 self-start sm:self-center">
          <span className="text-[10px] font-mono px-2.5 py-1 rounded-full bg-slate-800 text-slate-400 border border-slate-700">
            Simulated Example
          </span>
        </div>
      </div>

      {/* Tab Selector */}
      <div className="flex items-center justify-center">
        <div className="inline-flex rounded-xl p-1 bg-slate-950 border border-slate-800 text-xs">
          <button
            onClick={() => setActiveTab('before')}
            className={`px-4 py-2 rounded-lg font-medium transition-all ${
              activeTab === 'before'
                ? 'bg-rose-500/10 text-rose-300 border border-rose-500/30 shadow-sm'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            Before: Static Approach
          </button>
          <button
            onClick={() => setActiveTab('after')}
            className={`px-4 py-2 rounded-lg font-medium transition-all ${
              activeTab === 'after'
                ? 'bg-emerald-500/10 text-emerald-300 border border-emerald-500/30 shadow-sm'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            After: CarbonPilot
          </button>
        </div>
      </div>

      {/* Comparison Panel */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {/* State Card: Before / Static */}
        <div
          className={`rounded-xl border p-5 space-y-4 transition-all ${
            activeTab === 'before'
              ? 'border-rose-500/40 bg-slate-900/90 ring-1 ring-rose-500/20 shadow-md'
              : 'border-slate-800/80 bg-slate-950/40 opacity-70'
          }`}
        >
          <div className="flex items-center justify-between pb-3 border-b border-slate-800">
            <div>
              <span className="text-xs font-semibold text-slate-300 block">
                Traditional Approach
              </span>
              <span className="text-[11px] text-slate-500 font-mono">
                Static Frontier Deployment
              </span>
            </div>
            <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-rose-950/60 text-rose-400 border border-rose-500/30">
              Unoptimized
            </span>
          </div>

          <div className="space-y-3 text-xs">
            <div className="flex items-start gap-2.5">
              <Cpu className="w-4 h-4 text-slate-400 shrink-0 mt-0.5" />
              <div>
                <span className="font-semibold text-slate-200 block">Large Frontier Model</span>
                <span className="text-[11px] text-slate-400">
                  Blindly used for every step regardless of task complexity.
                </span>
              </div>
            </div>

            <div className="flex items-start gap-2.5">
              <Clock className="w-4 h-4 text-slate-400 shrink-0 mt-0.5" />
              <div>
                <span className="font-semibold text-slate-200 block">Execute Now</span>
                <span className="text-[11px] text-slate-400">
                  Executed immediately during peak-carbon grid hours without checking slack.
                </span>
              </div>
            </div>

            <div className="flex items-start gap-2.5">
              <AlertTriangle className="w-4 h-4 text-rose-400 shrink-0 mt-0.5" />
              <div>
                <span className="font-semibold text-slate-200 block">No Verification Gate</span>
                <span className="text-[11px] text-slate-400">
                  No early confidence checks; whole pipeline re-runs if error occurs later.
                </span>
              </div>
            </div>
          </div>

          {/* Metrics block */}
          <div className="pt-3 border-t border-slate-800 grid grid-cols-3 gap-2 text-center">
            <div className="p-2 rounded bg-slate-950/80 border border-slate-800/80">
              <span className="text-[10px] text-slate-400 block">Carbon</span>
              <span className="font-mono text-xs font-semibold text-rose-400 mt-0.5 block">
                41.2 gCO₂e
              </span>
            </div>
            <div className="p-2 rounded bg-slate-950/80 border border-slate-800/80">
              <span className="text-[10px] text-slate-400 block">Latency</span>
              <span className="font-mono text-xs font-semibold text-slate-300 mt-0.5 block">
                1,450 ms
              </span>
            </div>
            <div className="p-2 rounded bg-slate-950/80 border border-slate-800/80">
              <span className="text-[10px] text-slate-400 block">Quality</span>
              <span className="font-mono text-xs font-semibold text-slate-300 mt-0.5 block">
                93.0%
              </span>
            </div>
          </div>
        </div>

        {/* State Card: After / CarbonPilot */}
        <div
          className={`rounded-xl border p-5 space-y-4 transition-all ${
            activeTab === 'after'
              ? 'border-emerald-500/50 bg-slate-900/90 ring-1 ring-emerald-500/20 shadow-md'
              : 'border-slate-800/80 bg-slate-950/40 opacity-70'
          }`}
        >
          <div className="flex items-center justify-between pb-3 border-b border-slate-800">
            <div>
              <span className="text-xs font-semibold text-emerald-300 block">
                CarbonPilot Optimization
              </span>
              <span className="text-[11px] text-slate-400 font-mono">
                Context- &amp; Slack-Aware
              </span>
            </div>
            <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-emerald-950/60 text-emerald-400 border border-emerald-500/30">
              -79% Carbon
            </span>
          </div>

          <div className="space-y-3 text-xs">
            <div className="flex items-start gap-2.5">
              <Cpu className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
              <div>
                <span className="font-semibold text-slate-200 block">Right-Sized Small Model</span>
                <span className="text-[11px] text-slate-400">
                  Allocates fast, efficient model because task certainty is high.
                </span>
              </div>
            </div>

            <div className="flex items-start gap-2.5">
              <Clock className="w-4 h-4 text-purple-400 shrink-0 mt-0.5" />
              <div>
                <span className="font-semibold text-slate-200 block">Lower-Carbon Window / Parallel Slack</span>
                <span className="text-[11px] text-slate-400">
                  Exploits non-critical path slack to execute cleanly without delay.
                </span>
              </div>
            </div>

            <div className="flex items-start gap-2.5">
              <ShieldCheck className="w-4 h-4 text-sky-400 shrink-0 mt-0.5" />
              <div>
                <span className="font-semibold text-slate-200 block">Quality Gate Passed (94.2%)</span>
                <span className="text-[11px] text-slate-400">
                  Grounding validated against threshold; no costly fallback required.
                </span>
              </div>
            </div>
          </div>

          {/* Metrics block */}
          <div className="pt-3 border-t border-slate-800 grid grid-cols-3 gap-2 text-center">
            <div className="p-2 rounded bg-slate-950/80 border border-emerald-500/20">
              <span className="text-[10px] text-slate-400 block">Carbon</span>
              <span className="font-mono text-xs font-semibold text-emerald-400 mt-0.5 block">
                8.4 gCO₂e
              </span>
            </div>
            <div className="p-2 rounded bg-slate-950/80 border border-slate-800/80">
              <span className="text-[10px] text-slate-400 block">Latency</span>
              <span className="font-mono text-xs font-semibold text-emerald-300 mt-0.5 block">
                520 ms
              </span>
            </div>
            <div className="p-2 rounded bg-slate-950/80 border border-slate-800/80">
              <span className="text-[10px] text-slate-400 block">Quality</span>
              <span className="font-mono text-xs font-semibold text-sky-300 mt-0.5 block">
                94.2%
              </span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
