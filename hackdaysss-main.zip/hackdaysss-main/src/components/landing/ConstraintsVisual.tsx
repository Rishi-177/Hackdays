import React from 'react';
import { Leaf, Clock, ShieldCheck, DollarSign, Calendar, RefreshCw, Compass } from 'lucide-react';

export const ConstraintsVisual: React.FC = () => {
  const constraints = [
    {
      id: 'carbon',
      name: 'Carbon Emissions',
      detail: 'Regional grid intensity & carbon budget caps',
      icon: Leaf,
      color: 'text-emerald-400 border-emerald-500/30 bg-emerald-950/40',
    },
    {
      id: 'latency',
      name: 'Latency',
      detail: 'Critical path duration & real-time responsiveness',
      icon: Clock,
      color: 'text-amber-400 border-amber-500/30 bg-amber-950/40',
    },
    {
      id: 'quality',
      name: 'Quality & Accuracy',
      detail: 'Confidence gates, grounding checks, and escalation',
      icon: ShieldCheck,
      color: 'text-sky-400 border-sky-500/30 bg-sky-950/40',
    },
    {
      id: 'cost',
      name: 'Cost',
      detail: 'Token economics and compute resource pricing',
      icon: DollarSign,
      color: 'text-emerald-300 border-emerald-500/30 bg-emerald-950/40',
    },
    {
      id: 'deadline',
      name: 'Deadline & Slack',
      detail: 'SLA guarantees & delayable execution buffers',
      icon: Calendar,
      color: 'text-purple-400 border-purple-500/30 bg-purple-950/40',
    },
  ];

  return (
    <div className="rounded-2xl border border-slate-800 bg-slate-900/60 p-6 sm:p-8 space-y-6">
      {/* Visual Header */}
      <div className="text-center max-w-xl mx-auto space-y-2">
        <h3 className="text-base sm:text-lg font-bold text-slate-100">
          Not Simply "Use the Smallest Model"
        </h3>
        <p className="text-xs sm:text-sm text-slate-400 leading-relaxed">
          CarbonPilot performs multi-objective optimization across all 5 operational constraints simultaneously.
        </p>
      </div>

      {/* Constraints Grid / Ring Structure */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-3 pt-2">
        {constraints.map((c) => {
          const Icon = c.icon;
          return (
            <div
              key={c.id}
              className={`rounded-xl border p-4 space-y-2 flex flex-col justify-between transition-all hover:border-slate-700 ${c.color}`}
            >
              <div className="flex items-center justify-between">
                <Icon className="w-5 h-5" />
                <span className="text-[10px] font-mono uppercase tracking-wider text-slate-400">
                  Constraint
                </span>
              </div>
              <div>
                <h4 className="text-xs font-bold text-slate-100">{c.name}</h4>
                <p className="text-[11px] text-slate-400 mt-0.5 leading-snug">
                  {c.detail}
                </p>
              </div>
            </div>
          );
        })}
      </div>

      {/* Central Scheduler Integration Bar */}
      <div className="rounded-xl border border-slate-800 bg-slate-950/80 p-4 flex flex-col sm:flex-row items-center justify-between gap-3 text-xs">
        <div className="flex items-center gap-2.5">
          <div className="p-1.5 rounded-lg bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
            <Compass className="w-4 h-4" />
          </div>
          <div>
            <span className="font-semibold text-slate-200">
              Whole-Workflow Pareto Optimization
            </span>
            <p className="text-[11px] text-slate-400">
              Downscaling early tasks frees up carbon allowance for frontier synthesis without violating SLA deadlines.
            </p>
          </div>
        </div>

        <span className="text-[10px] font-mono px-2.5 py-1 rounded bg-slate-900 border border-slate-700 text-slate-300 shrink-0">
          Zero-Compromise Accuracy
        </span>
      </div>
    </div>
  );
};
