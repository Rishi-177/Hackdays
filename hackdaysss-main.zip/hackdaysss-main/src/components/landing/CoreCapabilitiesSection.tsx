import React from 'react';
import {
  GitMerge,
  ShieldCheck,
  Leaf,
  Clock,
  Sliders,
  Scale,
} from 'lucide-react';

export const CoreCapabilitiesSection: React.FC = () => {
  const capabilities = [
    {
      id: 'whole-workflow',
      title: 'Whole-Workflow Optimization',
      explanation:
        'Coordinates the full execution graph so that early carbon savings can be purposefully reinvested into frontier models where output depth matters most.',
      icon: GitMerge,
    },
    {
      id: 'quality-gate',
      title: 'Quality Gate + Escalation',
      explanation:
        'Evaluates confidence at each stage. Verified sub-task results complete instantly, while uncertain outputs escalate to larger models seamlessly.',
      icon: ShieldCheck,
    },
    {
      id: 'carbon-budget',
      title: 'Carbon Budget',
      explanation:
        'Tracks real-time cumulative grams of CO₂e against workflow caps, factoring in regional datacenter marginal grid carbon factors.',
      icon: Leaf,
    },
    {
      id: 'deadline-slack',
      title: 'Deadline & Slack',
      explanation:
        'Analyzes critical paths and execution slack to shift non-urgent tasks into upcoming low-carbon grid windows without violating SLA deadlines.',
      icon: Clock,
    },
    {
      id: 'what-if-engine',
      title: 'What-If Decision Engine',
      explanation:
        'Simulates trade-offs across carbon caps, latency tolerances, and model allocations along an empirical Pareto frontier.',
      icon: Sliders,
    },
    {
      id: 'baseline-comparison',
      title: 'Baseline Comparison',
      explanation:
        'Benchmarks whole-workflow scheduling against unoptimized all-frontier baselines with transparent telemetry and decision traces.',
      icon: Scale,
    },
  ];

  return (
    <section id="capabilities" className="py-24 sm:py-32 border-t border-[#DDE2DE] bg-[#F7F8F5]">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 space-y-16">
        {/* Section Header */}
        <div className="space-y-3 max-w-2xl">
          <div className="inline-flex items-center gap-2 text-xs font-mono font-medium text-[#007A52] tracking-wider uppercase">
            <span className="w-1.5 h-1.5 rounded-full bg-[#00D98B]" />
            Core Capabilities
          </div>
          <h2 className="text-3xl sm:text-4xl font-extrabold tracking-tight text-[#0A0D0C] leading-tight">
            Engineered for high-reliability AI pipelines.
          </h2>
          <p className="text-[#68706B] text-sm sm:text-base leading-relaxed">
            Six focused capabilities designed to make whole-workflow scheduling deterministic, transparent, and auditable.
          </p>
        </div>

        {/* 6 Elegant, Lightweight Capability Blocks */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {capabilities.map((cap) => {
            const Icon = cap.icon;
            return (
              <div
                key={cap.id}
                className="group relative p-6 rounded-xl border border-[#DDE2DE] bg-[#FFFFFF] hover:border-[#C9D0CB] hover:shadow-sm transition-all duration-200 flex flex-col justify-between shadow-xs"
              >
                {/* Subtle active accent line on top hover */}
                <div className="absolute top-0 left-6 right-6 h-[2px] bg-[#00D98B] opacity-0 group-hover:opacity-100 transition-opacity duration-200" />

                <div className="space-y-3">
                  <div className="w-8 h-8 rounded-md bg-[#F7F8F5] border border-[#DDE2DE] text-[#68706B] group-hover:text-[#007A52] group-hover:border-[#00D98B]/40 flex items-center justify-center transition-colors">
                    <Icon className="w-4 h-4" />
                  </div>

                  <h3 className="text-base font-bold text-[#0A0D0C] tracking-tight group-hover:text-[#007A52] transition-colors">
                    {cap.title}
                  </h3>

                  <p className="text-xs text-[#68706B] leading-relaxed font-sans">
                    {cap.explanation}
                  </p>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
};
