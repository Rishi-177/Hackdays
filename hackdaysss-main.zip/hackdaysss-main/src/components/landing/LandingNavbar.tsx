import React, { useState, useEffect } from 'react';
import { Compass, Menu, X, ArrowUpRight } from 'lucide-react';

export interface LandingNavbarProps {
  onLaunchDashboard: () => void;
  onLaunchDemo?: () => void;
  onNavigateSection: (sectionId: string) => void;
}

export const LandingNavbar: React.FC<LandingNavbarProps> = ({
  onLaunchDashboard,
  onLaunchDemo,
  onNavigateSection,
}) => {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [isScrolled, setIsScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 20);
    };
    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const handleNavClick = (sectionId: string) => {
    setMobileMenuOpen(false);
    onNavigateSection(sectionId);
  };

  return (
    <header
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
        isScrolled
          ? 'bg-[#FFFFFF]/90 backdrop-blur-md border-b border-[#DDE2DE] py-3.5 shadow-[0_1px_4px_rgba(10,13,12,0.03)]'
          : 'bg-transparent border-b border-transparent py-5'
      }`}
    >
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 flex items-center justify-between">
        {/* Brand Logo */}
        <button
          onClick={() => handleNavClick('hero')}
          className="flex items-center gap-3 cursor-pointer select-none text-left group focus:outline-none"
        >
          <div className="flex h-8 w-8 items-center justify-center rounded-md bg-[#E7F8F1] border border-[#DDE2DE] text-[#007A52] group-hover:bg-[#00D98B]/20 transition-all duration-200">
            <Compass className="w-4 h-4" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="text-sm font-bold tracking-tight text-[#0A0D0C] font-sans">
                CarbonPilot
              </span>
              <span className="inline-block w-1.5 h-1.5 rounded-full bg-[#00D98B]" />
            </div>
            <p className="text-[10px] text-[#68706B] font-mono tracking-wide leading-none mt-0.5">
              AI Workflow Scheduler
            </p>
          </div>
        </button>

        {/* Center Navigation Links */}
        <nav className="hidden md:flex items-center gap-9 text-xs font-medium text-[#68706B]">
          <button
            onClick={() => handleNavClick('why-carbonpilot')}
            className="hover:text-[#0A0D0C] transition-colors duration-150 relative py-1 hover:after:w-full after:w-0 after:h-[2px] after:bg-[#00D98B] after:absolute after:bottom-0 after:left-0 after:transition-all after:duration-200 cursor-pointer"
          >
            Product
          </button>
          <button
            onClick={() => handleNavClick('how-it-works')}
            className="hover:text-[#0A0D0C] transition-colors duration-150 relative py-1 hover:after:w-full after:w-0 after:h-[2px] after:bg-[#00D98B] after:absolute after:bottom-0 after:left-0 after:transition-all after:duration-200 cursor-pointer"
          >
            How It Works
          </button>
          <button
            onClick={() => handleNavClick('capabilities')}
            className="hover:text-[#0A0D0C] transition-colors duration-150 relative py-1 hover:after:w-full after:w-0 after:h-[2px] after:bg-[#00D98B] after:absolute after:bottom-0 after:left-0 after:transition-all after:duration-200 cursor-pointer"
          >
            Capabilities
          </button>
          <button
            onClick={() => handleNavClick('decision-demo')}
            className="hover:text-[#0A0D0C] transition-colors duration-150 relative py-1 hover:after:w-full after:w-0 after:h-[2px] after:bg-[#00D98B] after:absolute after:bottom-0 after:left-0 after:transition-all after:duration-200 cursor-pointer"
          >
            Interactive Demo
          </button>
        </nav>

        {/* Right CTA */}
        <div className="hidden md:flex items-center gap-2.5">
          {onLaunchDemo && (
            <button
              onClick={onLaunchDemo}
              className="inline-flex items-center justify-center gap-1.5 px-3 py-1.5 rounded-md text-xs font-medium text-[#0A0D0C] hover:bg-[#F7F8F5] border border-[#DDE2DE] hover:border-[#00D98B] transition-all duration-150 cursor-pointer"
            >
              <span>3-Min Demo</span>
            </button>
          )}
          <button
            onClick={onLaunchDashboard}
            className="inline-flex items-center justify-center gap-1.5 px-4 py-2 rounded-md text-xs font-semibold bg-[#00D98B] text-[#0A0D0C] hover:bg-[#00C47D] active:bg-[#00B070] transition-all duration-150 shadow-[0_1px_2px_rgba(10,13,12,0.06)] cursor-pointer"
          >
            <span>Open Dashboard</span>
            <ArrowUpRight className="w-3.5 h-3.5" />
          </button>
        </div>

        {/* Mobile Hamburger */}
        <button
          onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
          className="md:hidden p-2 rounded-md text-[#68706B] hover:text-[#0A0D0C] hover:bg-[#F7F8F5] border border-[#DDE2DE] transition-colors"
          aria-label={mobileMenuOpen ? 'Close menu' : 'Open menu'}
        >
          {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
        </button>
      </div>

      {/* Mobile Drawer */}
      {mobileMenuOpen && (
        <div className="md:hidden border-b border-[#DDE2DE] bg-[#FFFFFF] px-4 py-5 space-y-4 shadow-xl">
          <div className="flex flex-col space-y-2 text-sm font-medium text-[#68706B]">
            <button
              onClick={() => handleNavClick('why-carbonpilot')}
              className="text-left px-3 py-2 rounded-md hover:bg-[#F7F8F5] hover:text-[#0A0D0C] transition-colors"
            >
              Product
            </button>
            <button
              onClick={() => handleNavClick('how-it-works')}
              className="text-left px-3 py-2 rounded-md hover:bg-[#F7F8F5] hover:text-[#0A0D0C] transition-colors"
            >
              How It Works
            </button>
            <button
              onClick={() => handleNavClick('capabilities')}
              className="text-left px-3 py-2 rounded-md hover:bg-[#F7F8F5] hover:text-[#0A0D0C] transition-colors"
            >
              Capabilities
            </button>
            <button
              onClick={() => handleNavClick('decision-demo')}
              className="text-left px-3 py-2 rounded-md hover:bg-[#F7F8F5] hover:text-[#0A0D0C] transition-colors"
            >
              Interactive Demo
            </button>
          </div>

          <div className="pt-3 border-t border-[#DDE2DE] flex flex-col gap-2">
            {onLaunchDemo && (
              <button
                onClick={() => {
                  setMobileMenuOpen(false);
                  onLaunchDemo();
                }}
                className="w-full flex items-center justify-center gap-2 px-4 py-2.5 rounded-md text-sm font-medium text-[#0A0D0C] bg-[#F7F8F5] border border-[#DDE2DE] hover:bg-[#FFFFFF] transition-colors"
              >
                <span>Run 3-Min Demo</span>
              </button>
            )}
            <button
              onClick={() => {
                setMobileMenuOpen(false);
                onLaunchDashboard();
              }}
              className="w-full flex items-center justify-center gap-2 px-4 py-2.5 rounded-md text-sm font-semibold bg-[#00D98B] text-[#0A0D0C] hover:bg-[#00C47D] transition-colors shadow-sm"
            >
              <span>Open Dashboard</span>
              <ArrowUpRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      )}
    </header>
  );
};
