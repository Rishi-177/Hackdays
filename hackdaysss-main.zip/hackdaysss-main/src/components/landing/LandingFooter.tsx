import React from 'react';
import { Compass } from 'lucide-react';

export interface LandingFooterProps {
  onNavigateSection: (sectionId: string) => void;
  onLaunchDashboard: () => void;
}

export const LandingFooter: React.FC<LandingFooterProps> = ({
  onNavigateSection,
  onLaunchDashboard,
}) => {
  return (
    <footer className="py-12 border-t border-[#DDE2DE] bg-[#FFFFFF] text-xs text-[#68706B]">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col sm:flex-row items-center justify-between gap-6">
        {/* Brand */}
        <div className="flex items-center gap-3">
          <div className="flex h-7 w-7 items-center justify-center rounded-md bg-[#E7F8F1] border border-[#DDE2DE] text-[#007A52]">
            <Compass className="w-3.5 h-3.5" />
          </div>
          <div>
            <span className="font-bold text-[#0A0D0C] tracking-tight block">
              CarbonPilot
            </span>
            <span className="text-[11px] text-[#68706B] font-mono">
              Carbon- and Latency-Aware Agent Workflow Scheduler
            </span>
          </div>
        </div>

        {/* Minimal Navigation Links */}
        <div className="flex items-center gap-6 font-medium">
          <button
            onClick={() => onNavigateSection('why-carbonpilot')}
            className="hover:text-[#0A0D0C] transition-colors cursor-pointer"
          >
            Product
          </button>
          <button
            onClick={() => onNavigateSection('how-it-works')}
            className="hover:text-[#0A0D0C] transition-colors cursor-pointer"
          >
            How It Works
          </button>
          <button
            onClick={onLaunchDashboard}
            className="hover:text-[#007A52] transition-colors text-[#0A0D0C] font-semibold cursor-pointer"
          >
            Dashboard
          </button>
        </div>
      </div>
    </footer>
  );
};
