import React, { useState } from 'react';
import {
  Layers,
  GitBranch,
  Cpu,
  ShieldCheck,
  Clock,
  Sparkles,
  Check,
} from 'lucide-react';

interface WorkflowNode {
  id: string;
  name: string;
  category: 'task' | 'decision' | 'model' | 'gate' | 'schedule' | 'result';
  subtitle: string;
  tag: string;
  status: 'optimized' | 'active' | 'scheduled' | 'verified';
  confidence?: string;
  carbonDelta?: string;
  detail: {
    title: string;
    metric: string;
    action: string;
    rationale: string;
  };
  x: number; // percentage
  y: number; // percentage
}

export const HeroWorkflowDag: React.FC = () => {
  const [selectedNodeId, setSelectedNodeId] = useState<string>('gate');

  const nodes: WorkflowNode[] = [
    {
      id: 'task',
      name: 'Task Ingest',
      category: 'task',
      subtitle: 'Multi-step Query',
      tag: 'DAG Root',
      status: 'active',
      detail: {
        title: 'Task Ingestion & Parsing',
        metric: '4 sub-tasks mapped',
        action: 'Branching DAG graph constructed',
        rationale: 'Dependencies identified: 2 parallel steps, 1 serial aggregation step.',
      },
      x: 10,
      y: 50,
    },
    {
      id: 'decision',
      name: 'Path Decision',
      category: 'decision',
      subtitle: 'Pareto Optimizer',
      tag: 'Dynamic Policy',
      status: 'optimized',
      detail: {
        title: 'Multi-Objective Path Optimizer',
        metric: 'Grid: 285 gCO₂/kWh',
        action: 'Selected low-carbon execution trajectory',
        rationale: 'Grid intensity drops in 20 min. Urgent path isolated from deferrable background path.',
      },
      x: 28,
      y: 30,
    },
    {
      id: 'model',
      name: 'Model Tier',
      category: 'model',
      subtitle: 'Fast Efficient Tier',
      tag: 'Gemini Flash',
      carbonDelta: '-78% CO₂',
      status: 'optimized',
      detail: {
        title: 'Model Tier Allocation',
        metric: '0.04 gCO₂e (vs 0.28)',
        action: 'Routed to efficient instruction tier',
        rationale: 'Task complexity score is 0.24. High quality achievable with lightweight tier.',
      },
      x: 48,
      y: 22,
    },
    {
      id: 'gate',
      name: 'Quality Gate',
      category: 'gate',
      subtitle: 'Confidence Check',
      tag: 'Confidence: 94%',
      confidence: '94%',
      status: 'verified',
      detail: {
        title: 'Automated Quality Gate',
        metric: 'Confidence: 94.2%',
        action: 'Accept small-model result',
        rationale: 'Quality threshold met (88% requirement). Escalation to heavy frontier model avoided.',
      },
      x: 68,
      y: 22,
    },
    {
      id: 'schedule',
      name: 'Scheduling',
      category: 'schedule',
      subtitle: 'Slack Deferral',
      tag: '18 min slack',
      status: 'scheduled',
      detail: {
        title: 'Deadline & Slack Scheduling',
        metric: '18 min available slack',
        action: 'Delay execution to clean window',
        rationale: 'Non-critical background branch deferred until local clean wind generation ramps up.',
      },
      x: 48,
      y: 78,
    },
    {
      id: 'result',
      name: 'Final Synthesis',
      category: 'result',
      subtitle: 'Frontier Model',
      tag: 'Saved Budget',
      status: 'active',
      detail: {
        title: 'Verified Synthesis',
        metric: 'Cumulative -62% CO₂',
        action: 'Frontier synthesis completed',
        rationale: 'Budget saved in early nodes purposefully reinvested into high-stakes final output.',
      },
      x: 90,
      y: 50,
    },
  ];

  const selectedNode = nodes.find((n) => n.id === selectedNodeId) || nodes[3];

  return (
    <div className="w-full rounded-2xl border border-[#DDE2DE] bg-[#FFFFFF] p-5 sm:p-7 shadow-[0_2px_12px_rgba(10,13,12,0.03)] relative overflow-hidden group">
      {/* Top bar */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-4 border-b border-[#DDE2DE] gap-3">
        <div className="flex items-center gap-2.5">
          <div className="w-2 h-2 rounded-full bg-[#00D98B]" />
          <span className="text-xs font-mono font-medium text-[#0A0D0C]">
            Autonomous DAG Path Execution
          </span>
          <span className="hidden sm:inline-block text-[10px] font-mono px-2 py-0.5 rounded bg-[#E7F8F1] text-[#007A52] border border-[#DDE2DE]">
            Continuous Optimization
          </span>
        </div>
        <div className="text-xs font-mono text-[#68706B] flex items-center gap-3">
          <span>Click any node to inspect decision rationale</span>
        </div>
      </div>

      {/* SVG Canvas for Connectors & Interactive Nodes */}
      <div className="relative w-full h-72 sm:h-80 my-4 select-none">
        <svg
          className="absolute inset-0 w-full h-full pointer-events-none"
          xmlns="http://www.w3.org/2000/svg"
        >
          {/* Background Structural Inactive Paths */}
          {/* Path 1: Task -> Schedule */}
          <path
            d="M 120 160 C 180 160, 210 250, 360 250"
            fill="none"
            stroke="#DDE2DE"
            strokeWidth="1.5"
            vectorEffect="non-scaling-stroke"
          />
          {/* Path 2: Schedule -> Result */}
          <path
            d="M 440 250 C 560 250, 600 160, 680 160"
            fill="none"
            stroke="#DDE2DE"
            strokeWidth="1.5"
            strokeDasharray="4 4"
            vectorEffect="non-scaling-stroke"
          />

          {/* Active Primary Optimized Path: Task -> Decision -> Model -> Gate -> Result */}
          <path
            d="M 120 160 C 170 160, 180 96, 230 96"
            fill="none"
            stroke="#C9D0CB"
            strokeWidth="1.5"
          />
          <path
            d="M 310 96 C 350 96, 360 70, 400 70"
            fill="none"
            stroke="#C9D0CB"
            strokeWidth="1.5"
          />
          <path
            d="M 470 70 L 530 70"
            fill="none"
            stroke="#00D98B"
            strokeWidth="2"
            className="animate-workflow-flow"
          />
          <path
            d="M 610 70 C 660 70, 670 160, 710 160"
            fill="none"
            stroke="#00D98B"
            strokeWidth="2"
            className="animate-workflow-flow"
          />

          {/* Traveling Signal Dot on Active Optimized Path */}
          <circle r="3.5" fill="#00D98B">
            <animateMotion
              path="M 120 160 C 170 160, 180 96, 230 96 L 310 96 C 350 96, 360 70, 400 70 L 470 70 L 530 70 L 610 70 C 660 70, 670 160, 710 160"
              dur="4.5s"
              repeatCount="indefinite"
            />
          </circle>

          {/* Secondary subtle pulse along slack branch */}
          <circle r="2.5" fill="#8A918D" opacity="0.6">
            <animateMotion
              path="M 120 160 C 180 160, 210 250, 360 250 L 440 250 C 560 250, 600 160, 680 160"
              dur="7s"
              repeatCount="indefinite"
            />
          </circle>
        </svg>

        {/* Nodes Layer */}
        {nodes.map((node) => {
          const isSelected = node.id === selectedNodeId;
          const isGate = node.id === 'gate';

          return (
            <div
              key={node.id}
              onClick={() => setSelectedNodeId(node.id)}
              style={{
                left: `${node.x}%`,
                top: `${node.y}%`,
                transform: 'translate(-50%, -50%)',
              }}
              className="absolute cursor-pointer transition-all duration-200 z-10 flex flex-col items-center group/node"
            >
              <div
                className={`flex items-center gap-2.5 px-3 py-2 rounded-lg border text-left transition-all ${
                  isSelected
                    ? 'bg-[#E7F8F1] border-[#00D98B] ring-1 ring-[#00D98B] shadow-sm scale-105'
                    : 'bg-[#FFFFFF] border-[#DDE2DE] hover:border-[#C9D0CB] hover:bg-[#F7F8F5] shadow-xs'
                }`}
              >
                {/* Icon indicator */}
                <div
                  className={`w-6 h-6 rounded flex items-center justify-center shrink-0 text-xs ${
                    isSelected
                      ? 'bg-[#00D98B] text-[#0A0D0C]'
                      : isGate
                      ? 'bg-[#E7F8F1] text-[#007A52]'
                      : 'bg-[#F7F8F5] text-[#68706B] border border-[#DDE2DE]'
                  }`}
                >
                  {node.id === 'task' && <Layers className="w-3.5 h-3.5" />}
                  {node.id === 'decision' && <GitBranch className="w-3.5 h-3.5" />}
                  {node.id === 'model' && <Cpu className="w-3.5 h-3.5" />}
                  {node.id === 'gate' && <ShieldCheck className="w-3.5 h-3.5" />}
                  {node.id === 'schedule' && <Clock className="w-3.5 h-3.5" />}
                  {node.id === 'result' && <Sparkles className="w-3.5 h-3.5" />}
                </div>

                <div>
                  <div className="flex items-center gap-1.5">
                    <span className="text-xs font-semibold text-[#0A0D0C] whitespace-nowrap">
                      {node.name}
                    </span>
                    {node.confidence && (
                      <span className="text-[9px] font-mono font-semibold px-1 rounded bg-[#E7F8F1] text-[#007A52] border border-[#DDE2DE]">
                        {node.confidence}
                      </span>
                    )}
                    {node.carbonDelta && (
                      <span className="text-[9px] font-mono font-semibold px-1 rounded bg-[#E7F8F1] text-[#007A52] border border-[#DDE2DE]">
                        {node.carbonDelta}
                      </span>
                    )}
                  </div>
                  <div className="text-[10px] text-[#68706B] font-mono whitespace-nowrap">
                    {node.subtitle}
                  </div>
                </div>
              </div>

              {/* Status pill under node */}
              <div
                className={`mt-1 text-[9px] font-mono px-1.5 py-0.2 rounded transition-opacity ${
                  isSelected
                    ? 'text-[#007A52] bg-[#E7F8F1]'
                    : 'text-[#8A918D]'
                }`}
              >
                {node.tag}
              </div>
            </div>
          );
        })}
      </div>

      {/* Contextual Explanation Card (Interactive Reaction) */}
      <div className="rounded-xl border border-[#DDE2DE] bg-[#F7F8F5] p-4 transition-all duration-200">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-2.5 border-b border-[#DDE2DE]">
          <div className="flex items-center gap-2">
            <span className="text-[11px] font-mono uppercase tracking-wider text-[#68706B]">
              Inspecting Step:
            </span>
            <span className="text-xs font-semibold text-[#0A0D0C]">
              {selectedNode.detail.title}
            </span>
            <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-[#E7F8F1] text-[#007A52] border border-[#DDE2DE] font-semibold">
              {selectedNode.detail.metric}
            </span>
          </div>
          <div className="flex items-center gap-1.5 text-xs text-[#007A52] font-semibold font-mono">
            <Check className="w-3.5 h-3.5 text-[#00D98B]" />
            <span>{selectedNode.detail.action}</span>
          </div>
        </div>
        <p className="text-xs text-[#68706B] pt-2.5 leading-relaxed font-sans">
          {selectedNode.detail.rationale}
        </p>
      </div>

      {/* Subtle bottom legend */}
      <div className="flex flex-wrap items-center justify-between gap-3 pt-3 text-[11px] font-mono text-[#68706B]">
        <div className="flex items-center gap-4">
          <div className="flex items-center gap-1.5">
            <span className="w-2 h-0.5 bg-[#00D98B] rounded" />
            <span>Optimal whole-workflow path</span>
          </div>
          <div className="flex items-center gap-1.5">
            <span className="w-2 h-0.5 bg-[#8A918D] rounded border-dashed" />
            <span>Deferred background branch (slack)</span>
          </div>
        </div>
        <div className="text-[#0A0D0C] font-medium">
          Whole-workflow efficiency: <span className="text-[#007A52] font-bold">-62% CO₂e</span>
        </div>
      </div>
    </div>
  );
};
