import React from 'react';
import { ArrowRight } from 'lucide-react';

export interface FinalCtaSectionProps {
  onLaunchDashboard: () => void;
}

export const FinalCtaSection: React.FC<FinalCtaSectionProps> = ({ onLaunchDashboard }) => {
  return (
    <section className="py-28 sm:py-36 border-t border-[#DDE2DE] bg-[#FFFFFF] relative overflow-hidden text-center">
      <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8 space-y-8 relative z-10">
        <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-[#E7F8F1] border border-[#DDE2DE] text-[#007A52] text-xs font-mono font-medium">
          <span className="w-1.5 h-1.5 rounded-full bg-[#00D98B]" />
          <span>Interactive Whole-Workflow Simulator</span>
        </div>

        <h2 className="text-3xl sm:text-5xl font-extrabold tracking-tight text-[#0A0D0C] leading-tight">
          See what your workflow <br className="hidden sm:inline" />
          could do differently.
        </h2>

        <p className="text-[#68706B] text-base sm:text-lg max-w-xl mx-auto leading-relaxed">
          Explore CarbonPilot's optimization engine and see every scheduling decision explained.
        </p>

        <div className="pt-4 flex flex-col sm:flex-row items-center justify-center gap-4">
          <button
            onClick={onLaunchDashboard}
            className="w-full sm:w-auto inline-flex items-center justify-center gap-2 px-7 py-3.5 rounded-md text-sm font-semibold bg-[#00D98B] text-[#0A0D0C] hover:bg-[#00C47D] active:bg-[#00B070] transition-all duration-150 shadow-[0_1px_3px_rgba(10,13,12,0.08)] cursor-pointer"
          >
            <span>Open CarbonPilot Dashboard</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </div>
      </div>
    </section>
  );
};
