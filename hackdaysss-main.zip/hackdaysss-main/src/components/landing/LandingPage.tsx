import React from 'react';
import { LandingNavbar } from './LandingNavbar';
import { HeroWorkflowDag } from './HeroWorkflowDag';
import { TheProblemSection } from './TheProblemSection';
import { HowItWorksSection } from './HowItWorksSection';
import { CoreCapabilitiesSection } from './CoreCapabilitiesSection';
import { InteractiveDecisionDemo } from './InteractiveDecisionDemo';
import { WhyWorkflowMatters } from './WhyWorkflowMatters';
import { FinalCtaSection } from './FinalCtaSection';
import { LandingFooter } from './LandingFooter';
import { DotShift } from '../ui/dot-shift';
import { ArrowRight } from 'lucide-react';

export interface LandingPageProps {
  onLaunchDashboard: () => void;
  onLaunchDemo?: () => void;
}

export const LandingPage: React.FC<LandingPageProps> = ({
  onLaunchDashboard,
  onLaunchDemo,
}) => {
  const scrollToSection = (sectionId: string) => {
    if (sectionId === 'hero') {
      window.scrollTo({ top: 0, behavior: 'smooth' });
      return;
    }
    const elem = document.getElementById(sectionId);
    if (elem) {
      elem.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <div className="min-h-screen bg-[#F7F8F5] text-[#0A0D0C] font-sans selection:bg-[#00D98B]/30 selection:text-[#0A0D0C]">
      {/* 1. MINIMAL NAVIGATION */}
      <LandingNavbar
        onLaunchDashboard={onLaunchDashboard}
        onLaunchDemo={onLaunchDemo}
        onNavigateSection={scrollToSection}
      />

      <main>
        {/* 2. HERO SECTION */}
        <section
          id="hero"
          className="relative pt-32 sm:pt-40 pb-20 sm:pb-28 px-4 sm:px-6 lg:px-8 overflow-hidden"
        >
          {/* React Bits Pro: Dot Shift Background adapted to CarbonPilot design tokens */}
          <div className="absolute inset-0 pointer-events-none overflow-hidden select-none">
            <DotShift
              speed={0.4}
              scale={0.7}
              dotSize={0.55}
              dotBlur={0.45}
              baseColor="#007A52"
              opacity={0.28}
              interactive={true}
              className="absolute inset-0 w-full h-full"
            />
            {/* Soft radial & linear masks to gracefully dissolve into the warm off-white canvas */}
            <div className="absolute inset-0 bg-gradient-to-b from-[#F7F8F5]/40 via-transparent to-[#F7F8F5]" />
            <div className="absolute inset-0 bg-[radial-gradient(ellipse_80%_60%_at_50%_20%,transparent_30%,#F7F8F5_90%)]" />
          </div>

          <div className="max-w-6xl mx-auto space-y-14 sm:space-y-20 relative z-10">
            {/* Hero Copy */}
            <div className="max-w-3xl space-y-6">
              {/* Refined label */}
              <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-[#FFFFFF] border border-[#DDE2DE] text-[#0A0D0C] text-xs font-mono shadow-xs">
                <span className="w-1.5 h-1.5 rounded-full bg-[#00D98B]" />
                <span>Whole-Workflow AI Infrastructure</span>
              </div>

              {/* Exact Hero Headline */}
              <h1 className="text-4xl sm:text-6xl font-extrabold tracking-tight text-[#0A0D0C] leading-[1.1]">
                Optimize the Workflow. <br />
                <span className="text-[#68706B]">Not Just the Model.</span>
              </h1>

              {/* Supporting Message */}
              <p className="text-base sm:text-lg text-[#68706B] max-w-2xl leading-relaxed">
                CarbonPilot dynamically balances carbon, latency, quality, cost, and deadlines across the entire AI workflow.
              </p>

              {/* Action Buttons */}
              <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-3 pt-2">
                <button
                  onClick={onLaunchDashboard}
                  className="inline-flex items-center justify-center gap-2 px-6 py-3.5 rounded-md text-sm font-semibold bg-[#00D98B] text-[#0A0D0C] hover:bg-[#00C47D] active:bg-[#00B070] transition-all duration-150 shadow-[0_1px_3px_rgba(10,13,12,0.06)] cursor-pointer"
                >
                  <span>Open Dashboard</span>
                  <ArrowRight className="w-4 h-4" />
                </button>
                {onLaunchDemo && (
                  <button
                    onClick={onLaunchDemo}
                    className="inline-flex items-center justify-center gap-2 px-5 py-3.5 rounded-md text-sm font-semibold bg-[#FFFFFF] text-[#0A0D0C] hover:bg-[#F7F8F5] border border-[#DDE2DE] hover:border-[#00D98B] transition-all duration-150 shadow-xs cursor-pointer"
                  >
                    <span>Run 3-Min Demo</span>
                  </button>
                )}
                <button
                  onClick={() => scrollToSection('how-it-works')}
                  className="inline-flex items-center justify-center px-4 py-3.5 rounded-md text-sm font-medium text-[#68706B] hover:text-[#0A0D0C] transition-all duration-150 cursor-pointer"
                >
                  See How It Works ↓
                </button>
              </div>
            </div>

            {/* 3. HERO VISUAL: Original Abstract Workflow Visualization */}
            <div className="w-full">
              <HeroWorkflowDag />
            </div>
          </div>
        </section>

        {/* 4. SECTION — THE PROBLEM */}
        <TheProblemSection />

        {/* 5. SECTION — HOW CARBONPILOT THINKS */}
        <HowItWorksSection />

        {/* 6. SECTION — CORE CAPABILITIES */}
        <CoreCapabilitiesSection />

        {/* 7. SECTION — INTERACTIVE DECISION DEMO */}
        <InteractiveDecisionDemo />

        {/* 8. SECTION — WHY THE WORKFLOW MATTERS */}
        <WhyWorkflowMatters />

        {/* 9. FINAL CTA */}
        <FinalCtaSection onLaunchDashboard={onLaunchDashboard} />
      </main>

      {/* 10. MINIMAL FOOTER */}
      <LandingFooter
        onNavigateSection={scrollToSection}
        onLaunchDashboard={onLaunchDashboard}
      />
    </div>
  );
};
