import React from 'react';
import { Layers, Sliders, GitMerge, ShieldCheck } from 'lucide-react';

export const HowItWorksSection: React.FC = () => {
  const sequenceSteps = [
    {
      num: '01',
      title: 'Understand',
      action: 'Understand the workflow',
      description:
        'Parses the multi-step DAG structure, mapping task dependencies, concurrency forks, and the critical path latency ceiling.',
      icon: Layers,
    },
    {
      num: '02',
      title: 'Evaluate',
      action: 'Evaluate multi-dimensional constraints',
      description:
        'Ingests real-time regional grid carbon intensity, latency SLA bounds, accumulated carbon budgets, and quality thresholds.',
      icon: Sliders,
    },
    {
      num: '03',
      title: 'Optimize',
      action: 'Choose the execution strategy',
      description:
        'Selects the optimal model tier for each step, parallelizes independent sub-tasks, and schedules non-critical tasks into clean energy windows.',
      icon: GitMerge,
    },
    {
      num: '04',
      title: 'Verify',
      action: 'Verify quality and adjust when necessary',
      description:
        'Applies confidence evaluation gates. High-confidence results advance immediately; sub-threshold runs seamlessly escalate to frontier models.',
      icon: ShieldCheck,
    },
  ];

  return (
    <section id="how-it-works" className="py-24 sm:py-32 border-t border-[#DDE2DE] bg-[#FFFFFF] relative">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 space-y-16">
        {/* Section Header */}
        <div className="space-y-3 max-w-2xl">
          <div className="inline-flex items-center gap-2 text-xs font-mono font-medium text-[#007A52] tracking-wider uppercase">
            <span className="w-1.5 h-1.5 rounded-full bg-[#00D98B]" />
            Scheduling Lifecycle
          </div>
          <h2 className="text-3xl sm:text-4xl font-extrabold tracking-tight text-[#0A0D0C] leading-tight">
            How CarbonPilot thinks.
          </h2>
          <p className="text-[#68706B] text-sm sm:text-base leading-relaxed">
            Every incoming workflow passes through a deterministic four-phase optimization loop before and during execution.
          </p>
        </div>

        {/* 4-Step Visual Grid with Connecting Line */}
        <div className="relative">
          {/* Subtle horizontal connecting line on desktop */}
          <div className="hidden lg:block absolute top-1/2 left-0 right-0 h-px bg-[#DDE2DE] -translate-y-12 z-0" />

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 relative z-10">
            {sequenceSteps.map((step, idx) => {
              const Icon = step.icon;
              return (
                <div
                  key={step.num}
                  className="rounded-xl border border-[#DDE2DE] bg-[#FFFFFF] p-6 space-y-4 hover:border-[#C9D0CB] hover:shadow-sm transition-all duration-200 group flex flex-col justify-between shadow-xs"
                >
                  <div className="space-y-4">
                    <div className="flex items-center justify-between">
                      <span className="text-2xl font-mono font-bold text-[#8A918D] group-hover:text-[#007A52] transition-colors">
                        {step.num}
                      </span>
                      <div className="w-8 h-8 rounded-md bg-[#F7F8F5] border border-[#DDE2DE] text-[#68706B] group-hover:text-[#007A52] group-hover:border-[#00D98B]/40 flex items-center justify-center transition-all">
                        <Icon className="w-4 h-4" />
                      </div>
                    </div>

                    <div>
                      <h3 className="text-base font-bold text-[#0A0D0C] tracking-tight">
                        {step.title}
                      </h3>
                      <p className="text-xs font-mono text-[#007A52] font-semibold mt-0.5">
                        {step.action}
                      </p>
                    </div>

                    <p className="text-xs text-[#68706B] leading-relaxed font-sans">
                      {step.description}
                    </p>
                  </div>

                  <div className="pt-3 border-t border-[#DDE2DE] flex items-center gap-1.5 text-[11px] font-mono text-[#8A918D]">
                    <span>Phase {idx + 1} of 4</span>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </section>
  );
};
