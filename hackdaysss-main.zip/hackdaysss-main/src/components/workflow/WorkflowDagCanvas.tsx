import React, { useState, useRef, useEffect, useMemo, useCallback } from 'react';
import { DetailedWorkflowNode, DetailedWorkflowEdge } from './workflowData';
import {
  ZoomIn,
  ZoomOut,
  Maximize2,
  Move,
  Flame,
  CheckCircle2,
  Clock,
  Sparkles,
  Info,
} from 'lucide-react';

export interface WorkflowDagCanvasProps {
  nodes: DetailedWorkflowNode[];
  edges: DetailedWorkflowEdge[];
  selectedNodeId: string | null;
  onSelectNode: (node: DetailedWorkflowNode) => void;
  highlightCriticalPath?: boolean;
  onToggleCriticalPath?: () => void;
  isOptimizing?: boolean;
}

export const WorkflowDagCanvas: React.FC<WorkflowDagCanvasProps> = ({
  nodes,
  edges,
  selectedNodeId,
  onSelectNode,
  highlightCriticalPath = true,
  onToggleCriticalPath,
  isOptimizing = false,
}) => {
  // Canvas Zoom & Pan State
  const [zoom, setZoom] = useState<number>(1);
  const [pan, setPan] = useState<{ x: number; y: number }>({ x: 20, y: 30 });
  const [isPanning, setIsPanning] = useState<boolean>(false);
  const [hoveredNodeId, setHoveredNodeId] = useState<string | null>(null);

  const containerRef = useRef<HTMLDivElement>(null);
  const panStartRef = useRef<{ x: number; y: number }>({ x: 0, y: 0 });

  // Handle Zoom In / Out / Reset
  const handleZoomIn = () => setZoom((prev) => Math.min(Number((prev + 0.15).toFixed(2)), 2.2));
  const handleZoomOut = () => setZoom((prev) => Math.max(Number((prev - 0.15).toFixed(2)), 0.4));
  const handleResetView = () => {
    setZoom(1);
    setPan({ x: 20, y: 30 });
  };
  const handleFitView = () => {
    // Fits all 8 nodes comfortably within view
    setZoom(0.85);
    setPan({ x: 15, y: 40 });
  };

  // Mouse wheel: Ctrl/Meta+wheel zooms, regular wheel pans canvas
  const handleWheel = useCallback((e: React.WheelEvent) => {
    if (e.ctrlKey || e.metaKey) {
      e.preventDefault();
      const zoomFactor = e.deltaY < 0 ? 0.08 : -0.08;
      setZoom((prev) => Math.min(Math.max(Number((prev + zoomFactor).toFixed(2)), 0.4), 2.2));
    } else {
      setPan((prev) => ({
        x: prev.x - e.deltaX * 0.75,
        y: prev.y - e.deltaY * 0.75,
      }));
    }
  }, []);

  // Pan interaction
  const handleMouseDown = (e: React.MouseEvent) => {
    // Only pan if clicking canvas background, not when clicking on nodes or controls
    const target = e.target as HTMLElement;
    if (target.closest('.dag-node') || target.closest('.canvas-control')) {
      return;
    }
    setIsPanning(true);
    panStartRef.current = {
      x: e.clientX - pan.x,
      y: e.clientY - pan.y,
    };
  };

  // Touch pan interaction for mobile / tablet
  const handleTouchStart = (e: React.TouchEvent) => {
    const target = e.target as HTMLElement;
    if (target.closest('.dag-node') || target.closest('.canvas-control')) {
      return;
    }
    if (e.touches.length === 1) {
      setIsPanning(true);
      panStartRef.current = {
        x: e.touches[0].clientX - pan.x,
        y: e.touches[0].clientY - pan.y,
      };
    }
  };

  const handleTouchMove = (e: React.TouchEvent) => {
    if (!isPanning || e.touches.length !== 1) return;
    setPan({
      x: e.touches[0].clientX - panStartRef.current.x,
      y: e.touches[0].clientY - panStartRef.current.y,
    });
  };

  const handleTouchEnd = () => {
    setIsPanning(false);
  };

  const handleMouseUp = () => {
    setIsPanning(false);
  };

  // Global window listeners when panning so dragging continues smoothly across canvas borders
  useEffect(() => {
    if (!isPanning) return;

    const handleWindowMouseMove = (e: MouseEvent) => {
      setPan({
        x: e.clientX - panStartRef.current.x,
        y: e.clientY - panStartRef.current.y,
      });
    };

    const handleWindowMouseUp = () => {
      setIsPanning(false);
    };

    window.addEventListener('mousemove', handleWindowMouseMove);
    window.addEventListener('mouseup', handleWindowMouseUp);
    return () => {
      window.removeEventListener('mousemove', handleWindowMouseMove);
      window.removeEventListener('mouseup', handleWindowMouseUp);
    };
  }, [isPanning]);

  // Active highlighted dependencies
  const activeDependencies = useMemo(() => {
    const activeId = hoveredNodeId || selectedNodeId;
    if (!activeId) return new Set<string>();

    const activeNode = nodes.find((n) => n.id === activeId);
    const related = new Set<string>();
    related.add(activeId);

    // Upstream
    if (activeNode) {
      activeNode.dependencies.forEach((dep) => related.add(dep));
    }
    // Downstream
    nodes.forEach((n) => {
      if (n.dependencies.includes(activeId)) {
        related.add(n.id);
      }
    });

    return related;
  }, [hoveredNodeId, selectedNodeId, nodes]);

  // Card dimensions for connector offset calculations
  const CARD_WIDTH = 220;
  const CARD_HEIGHT = 100;

  // Render status badge for default node
  const renderNodeStatus = (node: DetailedWorkflowNode) => {
    switch (node.status) {
      case 'completed':
        return (
          <span className="inline-flex items-center gap-1.5 px-2 py-0.5 rounded-full text-[11px] font-medium bg-[#E7F8F1] text-[#007A52] border border-[#C9EBDC]">
            <span className="w-1.5 h-1.5 rounded-full bg-[#00D98B]" />
            <span>Completed</span>
          </span>
        );
      case 'running':
        return (
          <span className="inline-flex items-center gap-1.5 px-2 py-0.5 rounded-full text-[11px] font-medium bg-[#E7F8F1] text-[#007A52] border border-[#C9EBDC]">
            <span className="w-1.5 h-1.5 rounded-full bg-[#00D98B] animate-ping" />
            <span>Running</span>
          </span>
        );
      case 'delayed':
        return (
          <span className="inline-flex items-center gap-1.5 px-2 py-0.5 rounded-full text-[11px] font-medium bg-[#FEF5E7] text-[#B9770E] border border-[#FAD7A0]">
            <span className="w-1.5 h-1.5 rounded-full bg-[#F39C12]" />
            <span>Delayed (Solar)</span>
          </span>
        );
      case 'escalated':
        return (
          <span className="inline-flex items-center gap-1.5 px-2 py-0.5 rounded-full text-[11px] font-medium bg-[#FDEDEC] text-[#C0392B] border border-[#F5B7B1]">
            <span className="w-1.5 h-1.5 rounded-full bg-[#E74C3C]" />
            <span>Escalated</span>
          </span>
        );
      case 'scheduled':
        return (
          <span className="inline-flex items-center gap-1.5 px-2 py-0.5 rounded-full text-[11px] font-medium bg-[#F7F8F5] text-[#68706B] border border-[#DDE2DE]">
            <span className="w-1.5 h-1.5 rounded-full bg-[#68706B]" />
            <span>Scheduled</span>
          </span>
        );
      default:
        return (
          <span className="inline-flex items-center gap-1.5 px-2 py-0.5 rounded-full text-[11px] font-medium bg-[#F7F8F5] text-[#8A918D] border border-[#DDE2DE]">
            <span className="w-1.5 h-1.5 rounded-full bg-[#8A918D]" />
            <span>Pending</span>
          </span>
        );
    }
  };

  return (
    <div
      ref={containerRef}
      onWheel={handleWheel}
      onMouseDown={handleMouseDown}
      onTouchStart={handleTouchStart}
      onTouchMove={handleTouchMove}
      onTouchEnd={handleTouchEnd}
      onMouseUp={handleMouseUp}
      className={`relative w-full h-[520px] sm:h-[580px] bg-[#FFFFFF] rounded-2xl border border-[#DDE2DE] overflow-hidden select-none shadow-xs ${
        isPanning ? 'cursor-grabbing' : 'cursor-grab'
      }`}
    >
      {/* Background Dot Grid Pattern */}
      <svg
        className="absolute inset-0 w-full h-full pointer-events-none opacity-40"
        xmlns="http://www.w3.org/2000/svg"
      >
        <defs>
          <pattern
            id="dag-grid-dots"
            width="24"
            height="24"
            patternUnits="userSpaceOnUse"
            patternTransform={`translate(${pan.x},${pan.y}) scale(${zoom})`}
          >
            <circle cx="2" cy="2" r="1" fill="#C9D0CB" />
          </pattern>
        </defs>
        <rect width="100%" height="100%" fill="url(#dag-grid-dots)" />
      </svg>

      {/* Top Floating Control Bar */}
      <div className="absolute top-3 left-3 right-3 flex flex-wrap items-center justify-between gap-2 z-20 pointer-events-none">
        {/* Left: Workflow Stages / Critical Path Toggle */}
        <div className="flex items-center gap-2 pointer-events-auto bg-[#FFFFFF]/90 backdrop-blur-xs p-1.5 rounded-lg border border-[#DDE2DE] shadow-xs text-xs">
          <button
            onClick={onToggleCriticalPath}
            className={`flex items-center gap-1.5 px-2.5 py-1 rounded-md font-medium text-xs transition-colors cursor-pointer ${
              highlightCriticalPath
                ? 'bg-[#FEF5E7] text-[#B9770E] border border-[#FAD7A0]'
                : 'text-[#68706B] hover:text-[#0A0D0C] hover:bg-[#F7F8F5]'
            }`}
          >
            <Flame className="w-3.5 h-3.5 text-[#B9770E]" />
            <span>Critical Path</span>
          </button>

          <div className="h-3.5 w-px bg-[#DDE2DE]" />

          <div className="hidden sm:flex items-center gap-3 text-[11px] text-[#68706B] px-1 font-mono">
            <span className="flex items-center gap-1">
              <span className="w-2 h-2 rounded-full bg-[#00D98B]" /> Completed
            </span>
            <span className="flex items-center gap-1">
              <span className="w-2 h-2 rounded-full bg-[#F39C12]" /> Delayed (Solar)
            </span>
            <span className="flex items-center gap-1">
              <span className="w-2 h-2 rounded-full bg-[#E74C3C]" /> Escalated
            </span>
          </div>
        </div>

        {/* Right: Zoom & Pan Controls */}
        <div className="flex items-center gap-1 pointer-events-auto bg-[#FFFFFF]/90 backdrop-blur-xs p-1 rounded-lg border border-[#DDE2DE] shadow-xs canvas-control">
          <button
            onClick={handleZoomIn}
            className="p-1.5 rounded text-[#68706B] hover:text-[#0A0D0C] hover:bg-[#F7F8F5] transition-colors cursor-pointer"
            title="Zoom In"
            aria-label="Zoom In"
          >
            <ZoomIn className="w-4 h-4" />
          </button>
          <span className="text-[11px] font-mono text-[#0A0D0C] px-1.5 min-w-[42px] text-center">
            {Math.round(zoom * 100)}%
          </span>
          <button
            onClick={handleZoomOut}
            className="p-1.5 rounded text-[#68706B] hover:text-[#0A0D0C] hover:bg-[#F7F8F5] transition-colors cursor-pointer"
            title="Zoom Out"
            aria-label="Zoom Out"
          >
            <ZoomOut className="w-4 h-4" />
          </button>
          <div className="h-3.5 w-px bg-[#DDE2DE] mx-0.5" />
          <button
            onClick={handleResetView}
            className="p-1.5 rounded text-[#68706B] hover:text-[#0A0D0C] hover:bg-[#F7F8F5] transition-colors cursor-pointer text-[11px] font-mono"
            title="Reset 100%"
            aria-label="Reset 100%"
          >
            100%
          </button>
          <button
            onClick={handleFitView}
            className="p-1.5 rounded text-[#68706B] hover:text-[#0A0D0C] hover:bg-[#F7F8F5] transition-colors cursor-pointer"
            title="Fit to Screen"
            aria-label="Fit to Screen"
          >
            <Maximize2 className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Main Pan/Zoom Canvas Surface */}
      <div
        className="w-full h-full origin-top-left"
        style={{
          transform: `translate(${pan.x}px, ${pan.y}px) scale(${zoom})`,
          transition: isPanning ? 'none' : 'transform 0.08s ease-out',
        }}
      >
        {/* SVG Edges Layer */}
        <svg
          className="absolute top-0 left-0 w-[1600px] h-[700px] pointer-events-none"
          style={{ overflow: 'visible' }}
        >
          <defs>
            {/* Standard Arrow Marker */}
            <marker
              id="arrowhead-default"
              viewBox="0 0 10 10"
              refX="8"
              refY="5"
              markerWidth="6"
              markerHeight="6"
              orient="auto-start-reverse"
            >
              <path d="M 0 1.5 L 8 5 L 0 8.5 z" fill="#8A918D" />
            </marker>

            {/* Critical Path Arrow Marker */}
            <marker
              id="arrowhead-critical"
              viewBox="0 0 10 10"
              refX="8"
              refY="5"
              markerWidth="7"
              markerHeight="7"
              orient="auto-start-reverse"
            >
              <path d="M 0 1.5 L 8 5 L 0 8.5 z" fill="#B9770E" />
            </marker>

            {/* Active Highlight Arrow Marker */}
            <marker
              id="arrowhead-active"
              viewBox="0 0 10 10"
              refX="8"
              refY="5"
              markerWidth="7"
              markerHeight="7"
              orient="auto-start-reverse"
            >
              <path d="M 0 1.5 L 8 5 L 0 8.5 z" fill="#007A52" />
            </marker>
          </defs>

          {/* Render All Dependency Edges */}
          {edges.map((edge) => {
            const sourceNode = nodes.find((n) => n.id === edge.source);
            const targetNode = nodes.find((n) => n.id === edge.target);
            if (!sourceNode || !targetNode) return null;

            // Compute connection ports (Right edge of source -> Left edge of target)
            const fromX = sourceNode.x + CARD_WIDTH;
            const fromY = sourceNode.y + CARD_HEIGHT / 2;
            const toX = targetNode.x;
            const toY = targetNode.y + CARD_HEIGHT / 2;

            const dx = Math.max(50, (toX - fromX) * 0.5);
            const pathData = `M ${fromX} ${fromY} C ${fromX + dx} ${fromY}, ${toX - dx} ${toY}, ${toX} ${toY}`;

            const isCritical = highlightCriticalPath && edge.isCriticalPath;
            const isSourceOrTargetActive =
              activeDependencies.has(edge.source) && activeDependencies.has(edge.target);

            return (
              <g key={edge.id} className="transition-all duration-200">
                {/* Underline halo for critical / active path */}
                {(isCritical || isSourceOrTargetActive) && (
                  <path
                    d={pathData}
                    fill="none"
                    stroke={isCritical ? '#FAD7A0' : '#C9EBDC'}
                    strokeWidth={6}
                    strokeLinecap="round"
                    opacity={0.7}
                  />
                )}

                {/* Main edge path */}
                <path
                  d={pathData}
                  fill="none"
                  stroke={
                    isSourceOrTargetActive
                      ? '#007A52'
                      : isCritical
                      ? '#B9770E'
                      : '#C9D0CB'
                  }
                  strokeWidth={isCritical ? 2.5 : isSourceOrTargetActive ? 2.5 : 1.5}
                  strokeDasharray={isCritical ? 'none' : edge.isCriticalPath ? 'none' : '4 3'}
                  markerEnd={
                    isSourceOrTargetActive
                      ? 'url(#arrowhead-active)'
                      : isCritical
                      ? 'url(#arrowhead-critical)'
                      : 'url(#arrowhead-default)'
                  }
                  className="transition-colors"
                />
              </g>
            );
          })}
        </svg>

        {/* HTML Nodes Layer */}
        {nodes.map((node) => {
          const isSelected = selectedNodeId === node.id;
          const isHovered = hoveredNodeId === node.id;
          const isRelated = activeDependencies.has(node.id);

          return (
            <div
              key={node.id}
              onClick={() => onSelectNode(node)}
              onMouseEnter={() => setHoveredNodeId(node.id)}
              onMouseLeave={() => setHoveredNodeId(null)}
              style={{
                left: `${node.x}px`,
                top: `${node.y}px`,
                width: `${CARD_WIDTH}px`,
              }}
              className={`dag-node absolute rounded-xl border bg-[#FFFFFF] p-3.5 transition-all duration-150 cursor-pointer text-left select-none ${
                isSelected
                  ? 'border-[#00D98B] ring-2 ring-[#00D98B]/30 shadow-[0_4px_16px_rgba(0,217,139,0.15)] z-20'
                  : isRelated
                  ? 'border-[#007A52] shadow-[0_2px_10px_rgba(0,122,82,0.1)] z-10'
                  : isHovered
                  ? 'border-[#C9D0CB] shadow-sm z-10'
                  : 'border-[#DDE2DE] shadow-2xs hover:border-[#C9D0CB]'
              } ${isOptimizing ? 'animate-pulse' : ''}`}
            >
              {/* Critical Path or Special Badge Indicator */}
              <div className="flex items-center justify-between gap-1 mb-1.5">
                <span className="text-[10px] font-mono uppercase tracking-wider text-[#8A918D] truncate">
                  Stage {node.stage}
                </span>

                {highlightCriticalPath && node.isCriticalPath && (
                  <span className="text-[9px] font-mono px-1.5 py-0.2 rounded font-semibold bg-[#FEF5E7] text-[#B9770E] border border-[#FAD7A0]">
                    Critical Path
                  </span>
                )}
              </div>

              {/* 1. TASK */}
              <h4
                className="text-xs sm:text-sm font-bold text-[#0A0D0C] truncate leading-snug"
                title={node.name}
              >
                {node.name}
              </h4>

              {/* 2. MODEL */}
              <p
                className="text-xs text-[#68706B] font-mono mt-1 mb-2.5 truncate"
                title={node.model}
              >
                {node.model}
              </p>

              {/* 3. STATUS */}
              <div className="flex items-center justify-between pt-2 border-t border-[#DDE2DE]">
                {renderNodeStatus(node)}

                <span className="text-[10px] text-[#8A918D] group-hover:text-[#007A52] font-medium">
                  {isSelected ? 'Selected' : 'Inspect'}
                </span>
              </div>
            </div>
          );
        })}
      </div>

      {/* Bottom Hint Strip */}
      <div className="absolute bottom-2.5 left-3 right-3 flex items-center justify-between text-[11px] text-[#8A918D] pointer-events-none bg-[#FFFFFF]/80 backdrop-blur-xs px-2.5 py-1 rounded-md border border-[#DDE2DE]">
        <span className="flex items-center gap-1">
          <Info className="w-3.5 h-3.5 text-[#68706B]" />
          <span>Click any node to inspect details in the side panel. Drag to pan. Ctrl+scroll to zoom.</span>
        </span>
        <span className="hidden sm:inline font-mono text-[10px] text-[#007A52]">
          8 tasks • 9 dependencies
        </span>
      </div>
    </div>
  );
};
