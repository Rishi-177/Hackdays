/**
 * Workflow Page Domain Data & Types
 * Dedicated data model for interactive DAG inspection and optimization
 */

export interface DetailedWorkflowNode {
  id: string;
  name: string;
  stage: number;
  type: 'triage' | 'retrieval' | 'generation' | 'verifier' | 'synthesis' | 'action';
  status: 'completed' | 'running' | 'delayed' | 'escalated' | 'scheduled' | 'pending';
  model: string;
  modelTier: 'small' | 'medium' | 'frontier';
  isCriticalPath: boolean;
  x: number;
  y: number;
  estimatedCarbonGrams: number;
  estimatedLatencyMs: number;
  qualityConfidence: number;
  estimatedCostUsd: number;
  deadlineMs: number;
  slackMs: number;
  dependencies: string[]; // parent node IDs
  decision: {
    decision: string;
    why: string;
    tradeOff: string;
    impact: string;
    policyTriggered?: string;
  };
}

export interface DetailedWorkflowEdge {
  id: string;
  source: string;
  target: string;
  isCriticalPath: boolean;
  label?: string;
}

export interface OptimizationDecisionItem {
  id: string;
  nodeId?: string;
  decision: string;
  why: string;
  tradeOff: string;
  impact: string;
  badge: string;
}

export const INITIAL_WORKFLOW_NODES: DetailedWorkflowNode[] = [
  {
    id: 'node-doc-analysis',
    name: 'Document Analysis',
    stage: 1,
    type: 'triage',
    status: 'completed',
    model: 'Small Model (Gemini 2.5 Flash)',
    modelTier: 'small',
    isCriticalPath: true,
    x: 60,
    y: 190,
    estimatedCarbonGrams: 1.4,
    estimatedLatencyMs: 190,
    qualityConfidence: 96.0,
    estimatedCostUsd: 0.00025,
    deadlineMs: 3000,
    slackMs: 1400,
    dependencies: [],
    decision: {
      decision: 'Used smaller model for document classification',
      why: 'Predicted confidence (96.0%) comfortably exceeded the 85.0% requirement for standard contract templates.',
      tradeOff: 'Negligible variance in classification accuracy (+0.2% vs Gemini Pro), saving 78% energy.',
      impact: '-5.8 gCO₂e (-78% emissions vs frontier baseline) with zero SLA delay.',
      policyTriggered: 'CP-OPT-01: Cost & Carbon Pre-Filter',
    },
  },
  {
    id: 'node-policy-retrieval',
    name: 'Contextual Policy Retrieval',
    stage: 2,
    type: 'retrieval',
    status: 'completed',
    model: 'Small Model (Flash Ranker)',
    modelTier: 'small',
    isCriticalPath: false,
    x: 340,
    y: 70,
    estimatedCarbonGrams: 2.1,
    estimatedLatencyMs: 320,
    qualityConfidence: 92.5,
    estimatedCostUsd: 0.00042,
    deadlineMs: 2800,
    slackMs: 980,
    dependencies: ['node-doc-analysis'],
    decision: {
      decision: 'Low-power semantic vector retrieval',
      why: 'Pruned 14,000 regulatory guidelines down to 12 relevant chunks using vector indexing rather than prompt bloating.',
      tradeOff: 'Saved 250k token context loading on downstream synthesis models.',
      impact: '-3.2 gCO₂e saved and fast 320ms retrieval.',
      policyTriggered: 'CP-RET-04: Carbon-Aware Chunk Filtering',
    },
  },
  {
    id: 'node-contract-extract',
    name: 'Multimodal Contract Extraction',
    stage: 2,
    type: 'generation',
    status: 'completed',
    model: 'Small Model (Gemini 2.5 Flash)',
    modelTier: 'small',
    isCriticalPath: true,
    x: 340,
    y: 200,
    estimatedCarbonGrams: 6.8,
    estimatedLatencyMs: 640,
    qualityConfidence: 89.2,
    estimatedCostUsd: 0.0018,
    deadlineMs: 2400,
    slackMs: 620,
    dependencies: ['node-doc-analysis'],
    decision: {
      decision: 'Flash vision parser for contract tables',
      why: 'Document layout parsed accurately using high-efficiency vision weights without high-carbon frontier GPU compute.',
      tradeOff: 'Extraction accuracy 89.2% vs 91.0% on Ultra, comfortably within safety tolerance.',
      impact: '-8.4 gCO₂e saved; processed within 640ms.',
      policyTriggered: 'CP-GEN-02: Structured Extraction Allocation',
    },
  },
  {
    id: 'node-audit-batch',
    name: 'Task 4: Compliance Audit Batch',
    stage: 2,
    type: 'action',
    status: 'delayed',
    model: 'Small Model (Batch Engine)',
    modelTier: 'small',
    isCriticalPath: false,
    x: 340,
    y: 330,
    estimatedCarbonGrams: 0.3,
    estimatedLatencyMs: 420,
    qualityConfidence: 99.0,
    estimatedCostUsd: 0.00008,
    deadlineMs: 3000,
    slackMs: 1400,
    dependencies: ['node-doc-analysis'],
    decision: {
      decision: 'Delayed execution by 45 seconds for solar window',
      why: 'Task has sufficient deadline slack (+1,400 ms) on a non-critical branch.',
      tradeOff: 'Execution start deferred without impacting overall critical path delivery.',
      impact: 'Shifted compute into clean solar window, dropping grid intensity from 340 to 180 gCO₂/kWh.',
      policyTriggered: 'CP-SLACK-02: Clean-Window Deferral',
    },
  },
  {
    id: 'node-quality-gate',
    name: 'Quality Gate & Hallucination Guard',
    stage: 3,
    type: 'verifier',
    status: 'completed',
    model: 'Small Model (Cross-Verifier)',
    modelTier: 'small',
    isCriticalPath: true,
    x: 620,
    y: 135,
    estimatedCarbonGrams: 1.9,
    estimatedLatencyMs: 240,
    qualityConfidence: 94.2,
    estimatedCostUsd: 0.00035,
    deadlineMs: 1800,
    slackMs: 440,
    dependencies: ['node-policy-retrieval', 'node-contract-extract'],
    decision: {
      decision: 'Passed quality gate without frontier rework',
      why: 'Factual grounding verified at 94.2% confidence against regulatory clauses.',
      tradeOff: 'Small 240ms gate check prevents expensive multi-turn rework loops.',
      impact: 'Avoided frontier model escalation loop for 85% of parsed clauses.',
      policyTriggered: 'CP-QG-01: Proactive Quality Assurance Guard',
    },
  },
  {
    id: 'node-risk-escalation',
    name: 'High-Risk Clause Escalation',
    stage: 3,
    type: 'generation',
    status: 'escalated',
    model: 'Frontier Model (Gemini 2.5 Pro)',
    modelTier: 'frontier',
    isCriticalPath: false,
    x: 620,
    y: 270,
    estimatedCarbonGrams: 4.2,
    estimatedLatencyMs: 510,
    qualityConfidence: 98.5,
    estimatedCostUsd: 0.0028,
    deadlineMs: 1600,
    slackMs: 220,
    dependencies: ['node-contract-extract'],
    decision: {
      decision: 'Escalated ambiguous clause to Frontier Model',
      why: 'Clause #14 contained novel multi-jurisdiction indemnification with confidence (84.0%) below the 90.0% threshold.',
      tradeOff: 'Allocated 4.2 gCO₂e specifically to eliminate legal liability on ambiguous terms.',
      impact: 'Lifted clause confidence from 84.0% to 98.5% with certified audit trace.',
      policyTriggered: 'CP-ESC-03: Dynamic Quality Threshold Escalation',
    },
  },
  {
    id: 'node-risk-synthesis',
    name: 'Risk Synthesis & Remediation',
    stage: 4,
    type: 'synthesis',
    status: 'scheduled',
    model: 'Frontier Model (Gemini 2.5 Pro)',
    modelTier: 'frontier',
    isCriticalPath: true,
    x: 900,
    y: 190,
    estimatedCarbonGrams: 12.4,
    estimatedLatencyMs: 980,
    qualityConfidence: 97.4,
    estimatedCostUsd: 0.0065,
    deadlineMs: 1200,
    slackMs: 160,
    dependencies: ['node-quality-gate', 'node-risk-escalation'],
    decision: {
      decision: 'Targeted frontier model allocation for final synthesis',
      why: 'Because early stages preserved 59.6% carbon, scheduler safely deployed Gemini 2.5 Pro for deep executive reasoning.',
      tradeOff: 'Higher carbon (12.4 gCO₂e) budgeted because output generates customer-facing audit findings.',
      impact: 'Maximized analytical depth within total 50.0 gCO₂e budget ceiling.',
      policyTriggered: 'CP-BUD-03: Whole-Workflow Budget Allocation',
    },
  },
  {
    id: 'node-ledger-dispatch',
    name: 'Audit Ledger & Dispatch',
    stage: 5,
    type: 'action',
    status: 'pending',
    model: 'Deterministic Action Engine',
    modelTier: 'small',
    isCriticalPath: true,
    x: 1180,
    y: 190,
    estimatedCarbonGrams: 0.3,
    estimatedLatencyMs: 110,
    qualityConfidence: 100.0,
    estimatedCostUsd: 0.00008,
    deadlineMs: 600,
    slackMs: 80,
    dependencies: ['node-risk-synthesis'],
    decision: {
      decision: 'Deterministic code execution with zero LLM overhead',
      why: 'Cryptographic hash signing and ledger storage require pure code execution, not an LLM.',
      tradeOff: 'Zero natural language generation; deterministic speed.',
      impact: 'Near-zero carbon (0.3 gCO₂e) and 110ms execution.',
      policyTriggered: 'CP-ACT-01: Zero-Emission Tool Routing',
    },
  },
];

export const INITIAL_WORKFLOW_EDGES: DetailedWorkflowEdge[] = [
  { id: 'e1', source: 'node-doc-analysis', target: 'node-policy-retrieval', isCriticalPath: false },
  { id: 'e2', source: 'node-doc-analysis', target: 'node-contract-extract', isCriticalPath: true },
  { id: 'e3', source: 'node-doc-analysis', target: 'node-audit-batch', isCriticalPath: false },
  { id: 'e4', source: 'node-policy-retrieval', target: 'node-quality-gate', isCriticalPath: false },
  { id: 'e5', source: 'node-contract-extract', target: 'node-quality-gate', isCriticalPath: true },
  { id: 'e6', source: 'node-contract-extract', target: 'node-risk-escalation', isCriticalPath: false },
  { id: 'e7', source: 'node-quality-gate', target: 'node-risk-synthesis', isCriticalPath: true },
  { id: 'e8', source: 'node-risk-escalation', target: 'node-risk-synthesis', isCriticalPath: false },
  { id: 'e9', source: 'node-risk-synthesis', target: 'node-ledger-dispatch', isCriticalPath: true },
];

export const OPTIMIZATION_DECISIONS: OptimizationDecisionItem[] = [
  {
    id: 'opt-1',
    nodeId: 'node-doc-analysis',
    decision: 'Used smaller model',
    why: 'Quality requirement already satisfied (predicted confidence 96.0% exceeded 85.0% requirement).',
    tradeOff: 'Negligible variance in classification accuracy (+0.2% vs Gemini Pro), saving 78% energy.',
    impact: '-36.8 gCO₂e (-74% vs frontier baseline)',
    badge: 'Model Routing',
  },
  {
    id: 'opt-2',
    nodeId: 'node-audit-batch',
    decision: 'Delayed Task 4',
    why: 'Task has sufficient deadline slack (+1,400 ms on non-critical branch).',
    tradeOff: 'Deferred execution by 45s with zero impact on user SLA.',
    impact: 'Shifted compute into clean solar/wind grid window',
    badge: 'Slack Scheduling',
  },
  {
    id: 'opt-3',
    nodeId: 'node-quality-gate',
    decision: 'Quality gate passed',
    why: 'Confidence (94.2%) exceeded threshold, ensuring high grounding.',
    tradeOff: '240ms gate check prevented multi-step rework loops.',
    impact: 'Avoided frontier model escalation loop',
    badge: 'Verification',
  },
  {
    id: 'opt-4',
    nodeId: 'node-risk-escalation',
    decision: 'Selective escalation',
    why: 'Escalated only ambiguous clause #14 to frontier model, preserving budget on straightforward clauses.',
    tradeOff: '4.2 gCO₂e invested for certified legal compliance.',
    impact: 'Preserved 98.5% quality with minimal carbon cost',
    badge: 'Escalation',
  },
  {
    id: 'opt-5',
    nodeId: 'node-risk-synthesis',
    decision: 'Targeted frontier model allocation',
    why: 'Reserved carbon budget specifically for final executive risk synthesis.',
    tradeOff: 'Allocated 12.4 gCO₂e specifically for executive-ready findings.',
    impact: 'Maximized analytical depth within 50.0 gCO₂e budget ceiling',
    badge: 'Budget Allocation',
  },
];
