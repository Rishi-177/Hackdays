import React, { useEffect, useState } from 'react';
import { Sparkles, CheckCircle2, Loader2, ArrowRight } from 'lucide-react';

export interface OptimizationSimulationModalProps {
  isOpen: boolean;
  onComplete: () => void;
  onClose?: () => void;
}

const STEPS = [
  {
    id: 'analyzing',
    title: 'Analyzing workflow',
    subtitle: 'Extracting task dependencies, critical path, and historical token profiles',
    duration: 700,
  },
  {
    id: 'models',
    title: 'Evaluating models',
    subtitle: 'Benchmarking small vs frontier models against task quality thresholds',
    duration: 800,
  },
  {
    id: 'constraints',
    title: 'Evaluating constraints',
    subtitle: 'Checking 50.0 gCO₂e carbon budget, 2,500ms deadline, and regional grid solar peaks',
    duration: 850,
  },
  {
    id: 'plan',
    title: 'Selecting execution plan',
    subtitle: 'Dynamic routing: delaying non-critical tasks and reserving frontier tier for synthesis',
    duration: 750,
  },
  {
    id: 'optimized',
    title: 'Optimized',
    subtitle: 'Optimal DAG generated: -59.6% carbon, 1.52s wall-clock time, 94.6% quality preserved',
    duration: 600,
  },
];

export const OptimizationSimulationModal: React.FC<OptimizationSimulationModalProps> = ({
  isOpen,
  onComplete,
}) => {
  const [currentStepIndex, setCurrentStepIndex] = useState(0);
  const [isDone, setIsDone] = useState(false);

  useEffect(() => {
    if (!isOpen) {
      setCurrentStepIndex(0);
      setIsDone(false);
      return;
    }

    let isSubscribed = true;
    let timeoutId: NodeJS.Timeout;

    const runStep = (index: number) => {
      if (!isSubscribed) return;
      setCurrentStepIndex(index);

      if (index < STEPS.length - 1) {
        timeoutId = setTimeout(() => {
          runStep(index + 1);
        }, STEPS[index].duration);
      } else {
        // Final step: optimized
        timeoutId = setTimeout(() => {
          if (!isSubscribed) return;
          setIsDone(true);
          setTimeout(() => {
            if (isSubscribed) {
              onComplete();
            }
          }, 800);
        }, STEPS[index].duration);
      }
    };

    runStep(0);

    return () => {
      isSubscribed = false;
      clearTimeout(timeoutId);
    };
  }, [isOpen, onComplete]);

  if (!isOpen) return null;

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-[#0A0D0C]/40 backdrop-blur-xs animate-in fade-in duration-200"
      role="dialog"
      aria-modal="true"
    >
      <div className="w-full max-w-md bg-[#FFFFFF] rounded-2xl border border-[#DDE2DE] p-6 shadow-2xl space-y-6">
        {/* Header */}
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-[#E7F8F1] border border-[#C9EBDC] flex items-center justify-center text-[#007A52] shrink-0">
            {isDone ? (
              <CheckCircle2 className="w-5 h-5 text-[#00D98B]" />
            ) : (
              <Sparkles className="w-5 h-5 text-[#007A52] animate-pulse" />
            )}
          </div>
          <div>
            <h3 className="text-base font-bold text-[#0A0D0C]">
              {isDone ? 'Workflow Optimized' : 'Optimizing Workflow...'}
            </h3>
            <p className="text-xs text-[#68706B]">
              CarbonPilot dynamic whole-workflow scheduler
            </p>
          </div>
        </div>

        {/* Multi-step progress list */}
        <div className="space-y-3 py-1">
          {STEPS.map((step, idx) => {
            const isCompleted = idx < currentStepIndex || isDone;
            const isCurrent = idx === currentStepIndex && !isDone;
            const isUpcoming = idx > currentStepIndex && !isDone;

            return (
              <div
                key={step.id}
                className={`flex items-start gap-3 p-2.5 rounded-lg transition-all duration-200 border ${
                  isCurrent
                    ? 'bg-[#E7F8F1] border-[#00D98B] shadow-2xs'
                    : isCompleted
                    ? 'bg-[#FFFFFF] border-transparent text-[#0A0D0C]'
                    : 'bg-[#F7F8F5]/50 border-transparent text-[#8A918D]'
                }`}
              >
                {/* Step indicator */}
                <div className="mt-0.5 shrink-0">
                  {isCompleted ? (
                    <div className="w-4 h-4 rounded-full bg-[#00D98B] flex items-center justify-center text-[#0A0D0C]">
                      <CheckCircle2 className="w-3.5 h-3.5 text-[#0A0D0C]" />
                    </div>
                  ) : isCurrent ? (
                    <Loader2 className="w-4 h-4 text-[#007A52] animate-spin" />
                  ) : (
                    <div className="w-4 h-4 rounded-full border border-[#DDE2DE] bg-[#FFFFFF] flex items-center justify-center text-[10px] font-mono text-[#8A918D]">
                      {idx + 1}
                    </div>
                  )}
                </div>

                {/* Step content */}
                <div className="min-w-0 flex-1">
                  <div className="flex items-center gap-2">
                    <span
                      className={`text-xs font-semibold ${
                        isCurrent
                          ? 'text-[#007A52]'
                          : isCompleted
                          ? 'text-[#0A0D0C]'
                          : 'text-[#8A918D]'
                      }`}
                    >
                      {step.title}
                    </span>
                    {isCurrent && (
                      <span className="text-[10px] uppercase font-mono px-1.5 py-0.2 bg-[#00D98B]/20 text-[#007A52] rounded font-bold">
                        active
                      </span>
                    )}
                  </div>
                  <p className="text-[11px] text-[#68706B] leading-snug mt-0.5">
                    {step.subtitle}
                  </p>
                </div>
              </div>
            );
          })}
        </div>

        {/* Footer info strip */}
        <div className="pt-2 border-t border-[#DDE2DE] flex items-center justify-between text-xs text-[#8A918D]">
          <span>Whole-Workflow Engine</span>
          <span className="font-mono text-[11px] text-[#007A52] font-semibold flex items-center gap-1">
            <span>Evaluating constraints</span>
            <ArrowRight className="w-3 h-3" />
          </span>
        </div>
      </div>
    </div>
  );
};
