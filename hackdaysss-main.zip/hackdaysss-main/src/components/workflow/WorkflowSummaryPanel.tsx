import React from 'react';
import { OptimizationDecisionItem } from './workflowData';
import {
  CheckCircle2,
  Sparkles,
  ArrowDownRight,
  ShieldCheck,
  Zap,
} from 'lucide-react';

export interface WorkflowSummaryPanelProps {
  carbonGrams?: number;
  workflowTimeSeconds?: number;
  qualityPercent?: number;
  budgetGrams?: number;
  consumedBudgetGrams?: number;
  deadlineMs?: number;
  slackMs?: number;
  decisions: OptimizationDecisionItem[];
  onSelectDecisionNode?: (nodeId?: string) => void;
}

export const WorkflowSummaryPanel: React.FC<WorkflowSummaryPanelProps> = ({
  carbonGrams = 24.9,
  workflowTimeSeconds = 1.52,
  qualityPercent = 94.6,
  budgetGrams = 50.0,
  consumedBudgetGrams = 24.9,
  deadlineMs = 2500,
  slackMs = 980,
  decisions,
  onSelectDecisionNode,
}) => {
  const budgetRemainingGrams = Math.max(0, +(budgetGrams - consumedBudgetGrams).toFixed(1));

  return (
    <section className="space-y-5">
      {/* ==================================================
          1. 5 PRIMARY WORKFLOW SUMMARY METRICS
          Show: Carbon, Workflow Time, Quality, Budget, Deadline
          ================================================== */}
      <div className="space-y-2">
        <div className="flex items-center justify-between">
          <h3 className="text-sm font-bold text-[#0A0D0C] tracking-tight">
            Workflow Summary
          </h3>
          <span className="text-[11px] font-mono text-[#007A52] font-semibold bg-[#E7F8F1] px-2 py-0.5 rounded border border-[#C9EBDC]">
            -59.6% Carbon vs Baseline
          </span>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-3">
          {/* 1. Carbon */}
          <div className="rounded-xl border border-[#DDE2DE] bg-[#FFFFFF] p-3.5 shadow-xs hover:border-[#C9D0CB] transition-colors">
            <span className="text-[10px] font-mono font-semibold uppercase tracking-wider text-[#8A918D] block">
              Carbon
            </span>
            <div className="flex items-baseline gap-1 mt-1">
              <span className="font-mono text-xl sm:text-2xl font-bold text-[#0A0D0C] tracking-tight">
                {carbonGrams}
              </span>
              <span className="font-mono text-xs text-[#68706B]">gCO₂e</span>
            </div>
            <span className="text-[11px] text-[#007A52] font-medium block mt-0.5">
              -36.8 g saved
            </span>
          </div>

          {/* 2. Workflow Time */}
          <div className="rounded-xl border border-[#DDE2DE] bg-[#FFFFFF] p-3.5 shadow-xs hover:border-[#C9D0CB] transition-colors">
            <span className="text-[10px] font-mono font-semibold uppercase tracking-wider text-[#8A918D] block">
              Workflow Time
            </span>
            <div className="flex items-baseline gap-1 mt-1">
              <span className="font-mono text-xl sm:text-2xl font-bold text-[#0A0D0C] tracking-tight">
                {workflowTimeSeconds}
              </span>
              <span className="font-mono text-xs text-[#68706B]">s</span>
            </div>
            <span className="text-[11px] text-[#68706B] block mt-0.5">
              Critical path duration
            </span>
          </div>

          {/* 3. Quality */}
          <div className="rounded-xl border border-[#DDE2DE] bg-[#FFFFFF] p-3.5 shadow-xs hover:border-[#C9D0CB] transition-colors">
            <span className="text-[10px] font-mono font-semibold uppercase tracking-wider text-[#8A918D] block">
              Quality
            </span>
            <div className="flex items-baseline gap-1 mt-1">
              <span className="font-mono text-xl sm:text-2xl font-bold text-[#007A52] tracking-tight">
                {qualityPercent}%
              </span>
            </div>
            <span className="text-[11px] text-[#007A52] font-medium block mt-0.5">
              Target: ≥88% achieved
            </span>
          </div>

          {/* 4. Budget */}
          <div className="rounded-xl border border-[#DDE2DE] bg-[#FFFFFF] p-3.5 shadow-xs hover:border-[#C9D0CB] transition-colors">
            <span className="text-[10px] font-mono font-semibold uppercase tracking-wider text-[#8A918D] block">
              Budget
            </span>
            <div className="flex items-baseline gap-1 mt-1">
              <span className="font-mono text-xl sm:text-2xl font-bold text-[#0A0D0C] tracking-tight">
                {budgetRemainingGrams}
              </span>
              <span className="font-mono text-xs text-[#68706B]">g left</span>
            </div>
            <span className="text-[11px] text-[#68706B] block mt-0.5">
              of {budgetGrams} g cap (50%)
            </span>
          </div>

          {/* 5. Deadline */}
          <div className="rounded-xl border border-[#DDE2DE] bg-[#FFFFFF] p-3.5 shadow-xs hover:border-[#C9D0CB] transition-colors col-span-2 sm:col-span-1">
            <span className="text-[10px] font-mono font-semibold uppercase tracking-wider text-[#8A918D] block">
              Deadline
            </span>
            <div className="flex items-baseline gap-1 mt-1">
              <span className="font-mono text-xl sm:text-2xl font-bold text-[#0A0D0C] tracking-tight">
                +{slackMs}
              </span>
              <span className="font-mono text-xs text-[#68706B]">ms</span>
            </div>
            <span className="text-[11px] text-[#007A52] font-medium block mt-0.5">
              SLA: {deadlineMs} ms on track
            </span>
          </div>
        </div>
      </div>

      {/* ==================================================
          2. OPTIMIZATION DECISIONS
          Every major decision must explain:
          Decision
          Why
          Trade-off
          Impact
          ================================================== */}
      <div className="space-y-3 pt-1">
        <div>
          <h4 className="text-sm font-bold text-[#0A0D0C] tracking-tight">
            Optimization Decisions
          </h4>
          <p className="text-xs text-[#68706B] mt-0.5">
            Key scheduling choices made by CarbonPilot to optimize carbon, latency, and quality across the DAG.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
          {decisions.map((item) => (
            <div
              key={item.id}
              onClick={() => onSelectDecisionNode?.(item.nodeId)}
              className="rounded-xl border border-[#DDE2DE] bg-[#FFFFFF] p-4 space-y-3 shadow-xs hover:border-[#00D98B] hover:shadow-[0_2px_8px_rgba(0,217,139,0.06)] transition-all cursor-pointer group"
            >
              {/* Header: Badge & Decision */}
              <div className="flex items-start justify-between gap-2">
                <div className="min-w-0">
                  <span className="text-[10px] font-mono uppercase tracking-wider text-[#8A918D] font-semibold block mb-1">
                    {item.badge}
                  </span>
                  <h5 className="text-sm font-bold text-[#0A0D0C] group-hover:text-[#007A52] transition-colors leading-snug">
                    {item.decision}
                  </h5>
                </div>
                <div className="p-1.5 rounded-md bg-[#E7F8F1] text-[#007A52] shrink-0 mt-0.5">
                  <CheckCircle2 className="w-4 h-4" />
                </div>
              </div>

              {/* Why */}
              <div className="text-xs text-[#68706B] leading-relaxed">
                <span className="font-semibold text-[#0A0D0C]">Why: </span>
                {item.why}
              </div>

              {/* Trade-off */}
              <div className="text-xs text-[#68706B] leading-relaxed">
                <span className="font-semibold text-[#0A0D0C]">Trade-off: </span>
                {item.tradeOff}
              </div>

              {/* Impact */}
              <div className="pt-2 border-t border-[#DDE2DE] flex items-center justify-between text-xs">
                <span className="font-bold text-[#007A52]">Impact:</span>
                <span className="font-mono text-[11px] font-semibold text-[#007A52] bg-[#E7F8F1] px-2 py-0.5 rounded border border-[#C9EBDC] text-right truncate max-w-[210px]">
                  {item.impact}
                </span>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};
