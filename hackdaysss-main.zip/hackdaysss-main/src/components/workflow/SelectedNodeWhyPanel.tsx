import React from 'react';
import { DetailedWorkflowNode } from './workflowData';
import {
  X,
  Cpu,
  Clock,
  Leaf,
  ShieldCheck,
  CheckCircle2,
  AlertTriangle,
  ArrowRight,
  TrendingDown,
  Layers,
  Sparkles,
} from 'lucide-react';

export interface SelectedNodeWhyPanelProps {
  node: DetailedWorkflowNode | null;
  onClose: () => void;
  onSelectNodeById?: (nodeId: string) => void;
  allNodes?: DetailedWorkflowNode[];
}

export const SelectedNodeWhyPanel: React.FC<SelectedNodeWhyPanelProps> = ({
  node,
  onClose,
  onSelectNodeById,
  allNodes = [],
}) => {
  if (!node) {
    return (
      <div className="h-full flex flex-col items-center justify-center p-6 text-center text-[#8A918D] border-l border-[#DDE2DE] bg-[#FFFFFF]">
        <div className="w-12 h-12 rounded-xl bg-[#F7F8F5] border border-[#DDE2DE] flex items-center justify-center mb-3 text-[#68706B]">
          <Layers className="w-5 h-5" />
        </div>
        <h4 className="text-sm font-semibold text-[#0A0D0C] mb-1">
          No Task Selected
        </h4>
        <p className="text-xs text-[#68706B] max-w-[240px] leading-relaxed">
          Click any task node on the workflow DAG to inspect its model routing, carbon cost, and scheduling rationale.
        </p>
      </div>
    );
  }

  const getStatusBadge = () => {
    switch (node.status) {
      case 'completed':
        return {
          label: 'Completed',
          badgeClass: 'bg-[#E7F8F1] text-[#007A52] border-[#C9EBDC]',
          dotClass: 'bg-[#00D98B]',
        };
      case 'running':
        return {
          label: 'Running',
          badgeClass: 'bg-[#E7F8F1] text-[#007A52] border-[#C9EBDC]',
          dotClass: 'bg-[#00D98B] animate-ping',
        };
      case 'delayed':
        return {
          label: 'Delayed (Solar Window)',
          badgeClass: 'bg-[#FEF5E7] text-[#B9770E] border-[#FAD7A0]',
          dotClass: 'bg-[#F39C12]',
        };
      case 'escalated':
        return {
          label: 'Escalated (Frontier)',
          badgeClass: 'bg-[#FDEDEC] text-[#C0392B] border-[#F5B7B1]',
          dotClass: 'bg-[#E74C3C]',
        };
      case 'scheduled':
        return {
          label: 'Scheduled',
          badgeClass: 'bg-[#F7F8F5] text-[#68706B] border-[#DDE2DE]',
          dotClass: 'bg-[#68706B]',
        };
      default:
        return {
          label: 'Pending',
          badgeClass: 'bg-[#F7F8F5] text-[#8A918D] border-[#DDE2DE]',
          dotClass: 'bg-[#8A918D]',
        };
    }
  };

  const statusBadge = getStatusBadge();

  // Find dependency nodes
  const parentNodes = allNodes.filter((n) => node.dependencies.includes(n.id));
  const childNodes = allNodes.filter((n) => n.dependencies.includes(node.id));

  return (
    <aside className="w-full h-full flex flex-col bg-[#FFFFFF] border-l border-[#DDE2DE] overflow-y-auto">
      {/* Panel Header */}
      <div className="flex items-center justify-between p-4 border-b border-[#DDE2DE] bg-[#FFFFFF] sticky top-0 z-10">
        <div>
          <span className="text-[10px] font-mono text-[#8A918D] uppercase tracking-wider block">
            Selected Node Details
          </span>
          <h3 className="text-sm font-bold text-[#0A0D0C] truncate max-w-[220px]">
            {node.name}
          </h3>
        </div>
        <button
          onClick={onClose}
          className="p-1.5 rounded-md text-[#68706B] hover:text-[#0A0D0C] hover:bg-[#F7F8F5] border border-transparent hover:border-[#DDE2DE] transition-colors cursor-pointer"
          aria-label="Close side panel"
        >
          <X className="w-4 h-4" />
        </button>
      </div>

      <div className="p-4 space-y-5 flex-1">
        {/* Task, Model, Status Card */}
        <div className="rounded-xl border border-[#DDE2DE] bg-[#F7F8F5] p-3.5 space-y-2.5">
          <div className="flex items-center justify-between">
            <span
              className={`inline-flex items-center gap-1.5 px-2 py-0.5 rounded-full text-[11px] font-medium border ${statusBadge.badgeClass}`}
            >
              <span className={`w-1.5 h-1.5 rounded-full ${statusBadge.dotClass}`} />
              <span>{statusBadge.label}</span>
            </span>

            {node.isCriticalPath && (
              <span className="text-[10px] font-mono px-2 py-0.5 rounded font-semibold bg-[#FEF5E7] text-[#B9770E] border border-[#FAD7A0]">
                Critical Path
              </span>
            )}
          </div>

          <div>
            <span className="text-[11px] font-semibold text-[#8A918D] block">Task</span>
            <span className="text-sm font-bold text-[#0A0D0C] block mt-0.5">
              {node.name}
            </span>
          </div>

          <div className="pt-1 border-t border-[#DDE2DE]/60">
            <span className="text-[11px] font-semibold text-[#8A918D] block">Model</span>
            <div className="flex items-center gap-1.5 mt-0.5 text-xs font-mono text-[#0A0D0C]">
              <Cpu className="w-3.5 h-3.5 text-[#007A52]" />
              <span className="font-semibold">{node.model}</span>
            </div>
          </div>
        </div>

        {/* Task Metrics Grid */}
        <div className="space-y-2">
          <span className="text-[11px] font-mono uppercase tracking-wider text-[#8A918D] font-semibold block">
            Performance Metrics
          </span>

          <div className="grid grid-cols-2 gap-2 text-xs">
            {/* Carbon */}
            <div className="p-2.5 rounded-lg border border-[#DDE2DE] bg-[#FFFFFF] shadow-2xs">
              <span className="text-[11px] text-[#68706B] flex items-center gap-1">
                <Leaf className="w-3 h-3 text-[#007A52]" />
                Carbon
              </span>
              <span className="font-mono text-xs font-bold text-[#007A52] block mt-1">
                {node.estimatedCarbonGrams} gCO₂e
              </span>
            </div>

            {/* Latency */}
            <div className="p-2.5 rounded-lg border border-[#DDE2DE] bg-[#FFFFFF] shadow-2xs">
              <span className="text-[11px] text-[#68706B] flex items-center gap-1">
                <Clock className="w-3 h-3 text-[#0A0D0C]" />
                Latency
              </span>
              <span className="font-mono text-xs font-bold text-[#0A0D0C] block mt-1">
                {node.estimatedLatencyMs} ms
              </span>
            </div>

            {/* Quality */}
            <div className="p-2.5 rounded-lg border border-[#DDE2DE] bg-[#FFFFFF] shadow-2xs">
              <span className="text-[11px] text-[#68706B] flex items-center gap-1">
                <ShieldCheck className="w-3 h-3 text-[#007A52]" />
                Quality
              </span>
              <span className="font-mono text-xs font-bold text-[#0A0D0C] block mt-1">
                {node.qualityConfidence}%
              </span>
            </div>

            {/* Cost */}
            <div className="p-2.5 rounded-lg border border-[#DDE2DE] bg-[#FFFFFF] shadow-2xs">
              <span className="text-[11px] text-[#68706B] block">Cost</span>
              <span className="font-mono text-xs font-semibold text-[#0A0D0C] block mt-1">
                ${node.estimatedCostUsd.toFixed(5)}
              </span>
            </div>

            {/* Slack */}
            <div className="p-2.5 rounded-lg border border-[#DDE2DE] bg-[#FFFFFF] shadow-2xs col-span-2">
              <span className="text-[11px] text-[#68706B] block">Deadline Slack</span>
              <span className="font-mono text-xs font-semibold text-[#007A52] block mt-0.5">
                +{node.slackMs} ms (Deadline: {node.deadlineMs} ms)
              </span>
            </div>
          </div>
        </div>

        {/* ==================================================
            WHY PANEL: DECISION, WHY, TRADE-OFF, IMPACT
            Concise explanations strictly following requirements
            ================================================== */}
        <div className="rounded-xl border border-[#007A52]/30 bg-[#E7F8F1]/40 p-4 space-y-3.5 shadow-xs">
          <div className="flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 text-[#007A52] shrink-0" />
            <h4 className="text-xs font-bold uppercase tracking-wider text-[#007A52]">
              Why did CarbonPilot choose this?
            </h4>
          </div>

          {/* 1. Decision */}
          <div>
            <span className="text-[11px] font-bold text-[#0A0D0C] block">
              Decision
            </span>
            <p className="text-xs text-[#0A0D0C] mt-0.5 leading-relaxed font-medium">
              {node.decision.decision}
            </p>
          </div>

          {/* 2. Why */}
          <div>
            <span className="text-[11px] font-bold text-[#0A0D0C] block">
              Why
            </span>
            <p className="text-xs text-[#68706B] mt-0.5 leading-relaxed">
              {node.decision.why}
            </p>
          </div>

          {/* 3. Trade-off */}
          <div>
            <span className="text-[11px] font-bold text-[#0A0D0C] block">
              Trade-off
            </span>
            <p className="text-xs text-[#68706B] mt-0.5 leading-relaxed">
              {node.decision.tradeOff}
            </p>
          </div>

          {/* 4. Impact */}
          <div className="pt-2 border-t border-[#007A52]/20">
            <span className="text-[11px] font-bold text-[#007A52] block">
              Impact
            </span>
            <p className="text-xs font-mono font-semibold text-[#007A52] mt-0.5 bg-[#FFFFFF] px-2.5 py-1.5 rounded border border-[#C9EBDC]">
              {node.decision.impact}
            </p>
          </div>
        </div>

        {/* Dependencies Section */}
        <div className="space-y-2.5 pt-1">
          <span className="text-[11px] font-mono uppercase tracking-wider text-[#8A918D] font-semibold block">
            Dependencies
          </span>

          {/* Upstream Parents */}
          <div className="space-y-1">
            <span className="text-[10px] text-[#68706B] block">Depends on (Inputs):</span>
            {parentNodes.length === 0 ? (
              <span className="text-xs text-[#8A918D] italic block">
                None (Root Ingestion Task)
              </span>
            ) : (
              <div className="space-y-1.5">
                {parentNodes.map((parent) => (
                  <button
                    key={parent.id}
                    onClick={() => onSelectNodeById?.(parent.id)}
                    className="w-full flex items-center justify-between px-2.5 py-1.5 rounded-md border border-[#DDE2DE] bg-[#FFFFFF] hover:bg-[#F7F8F5] text-left transition-colors text-xs group cursor-pointer"
                  >
                    <span className="font-semibold text-[#0A0D0C] truncate max-w-[180px]">
                      {parent.name}
                    </span>
                    <ArrowRight className="w-3 h-3 text-[#8A918D] group-hover:text-[#007A52] shrink-0" />
                  </button>
                ))}
              </div>
            )}
          </div>

          {/* Downstream Children */}
          <div className="space-y-1 pt-1">
            <span className="text-[10px] text-[#68706B] block">Required by (Outputs):</span>
            {childNodes.length === 0 ? (
              <span className="text-xs text-[#8A918D] italic block">
                None (Terminal Action Task)
              </span>
            ) : (
              <div className="space-y-1.5">
                {childNodes.map((child) => (
                  <button
                    key={child.id}
                    onClick={() => onSelectNodeById?.(child.id)}
                    className="w-full flex items-center justify-between px-2.5 py-1.5 rounded-md border border-[#DDE2DE] bg-[#FFFFFF] hover:bg-[#F7F8F5] text-left transition-colors text-xs group cursor-pointer"
                  >
                    <span className="font-semibold text-[#0A0D0C] truncate max-w-[180px]">
                      {child.name}
                    </span>
                    <ArrowRight className="w-3 h-3 text-[#8A918D] group-hover:text-[#007A52] shrink-0" />
                  </button>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>
    </aside>
  );
};
