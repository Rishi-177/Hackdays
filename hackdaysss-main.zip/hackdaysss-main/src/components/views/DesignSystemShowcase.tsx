import React, { useState } from 'react';
import {
  Button,
  Card,
  CardHeader,
  CardTitle,
  CardDescription,
  CardContent,
  Badge,
  MetricCard,
  DecisionExplainer,
  StatusIndicator,
  Progress,
  Tabs,
  Select,
  Slider,
  Modal,
  Drawer,
  Alert,
  EmptyState,
  LoadingState,
  ErrorState,
  WorkflowNodeCard,
} from '../design-system';
import {
  Leaf,
  Clock,
  ShieldCheck,
  GitMerge,
  AlertTriangle,
} from 'lucide-react';
import { PRIMARY_WORKFLOW_NODES } from '../../services/mockData';
import { WorkflowNode } from '../../types';
import { DotShift } from '../ui/dot-shift';

export const DesignSystemShowcase: React.FC = () => {
  const [activeTab, setActiveTab] = useState('components');
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [isDrawerOpen, setIsDrawerOpen] = useState(false);
  const [sliderValue, setSliderValue] = useState(45);
  const [selectValue, setSelectValue] = useState('flash');
  const [progressValue] = useState(64);
  const [inspectNode, setInspectNode] = useState<WorkflowNode>(PRIMARY_WORKFLOW_NODES[0]);

  // DotShift Interactive Playground State
  const [dotSpeed, setDotSpeed] = useState(50); // maps to 0.5
  const [dotScale, setDotScale] = useState(60); // maps to 0.6
  const [dotSize, setDotSize] = useState(60);   // maps to 0.6
  const [dotBlur, setDotBlur] = useState(45);   // maps to 0.45
  const [dotColor, setDotColor] = useState('#00D98B');

  const showcaseTabs = [
    { id: 'components', label: 'Core Controls & Cards', count: 12 },
    { id: 'feedback', label: 'Feedback & States', count: 6 },
    { id: 'workflow', label: 'DAG & Explainability', count: 4 },
    { id: 'dotshift', label: 'React Bits Pro: Dot Shift', count: 1 },
  ];

  const selectOptions = [
    { value: 'flash', label: 'Gemini 2.5 Flash (Small Tier - 1.4 gCO₂e)' },
    { value: 'pro', label: 'Gemini 2.5 Pro (Frontier Tier - 12.4 gCO₂e)' },
    { value: 'claude', label: 'Claude 3.5 Haiku (Small Tier - 1.8 gCO₂e)' },
    { value: 'llama', label: 'Llama-3-8B Local (Zero Grid Emission)' },
  ];

  return (
    <div className="max-w-7xl mx-auto space-y-8 pb-16">
      {/* Design System Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 p-6 rounded-xl border border-[#DDE2DE] bg-[#FFFFFF] shadow-xs">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <Badge variant="carbon" size="sm">Design System Spec</Badge>
            <Badge variant="neutral" size="sm">Enterprise v0.1</Badge>
          </div>
          <h1 className="text-xl sm:text-2xl font-bold tracking-tight text-[#0A0D0C]">
            CarbonPilot Design System &amp; Primitives
          </h1>
          <p className="text-xs sm:text-sm text-[#68706B] max-w-2xl mt-1 leading-relaxed">
            Calm, high-contrast, technical enterprise tokens and reusable primitives ensuring consistent UI behavior across all future pages.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <Button
            variant="outline"
            size="sm"
            onClick={() => setIsModalOpen(true)}
          >
            Test Modal
          </Button>
          <Button
            variant="eco"
            size="sm"
            onClick={() => setIsDrawerOpen(true)}
          >
            Test Drawer
          </Button>
        </div>
      </div>

      {/* Navigation Tabs for Categories */}
      <Tabs
        tabs={showcaseTabs}
        activeTab={activeTab}
        onChange={setActiveTab}
        variant="underline"
      />

      {/* Tab 1: Core Controls & Cards */}
      {activeTab === 'components' && (
        <div className="space-y-8">
          {/* Typography & Spacing Scale */}
          <Card>
            <CardHeader>
              <CardTitle>1. Typography &amp; Scale</CardTitle>
              <CardDescription>
                Plus Jakarta Sans for high-legibility UI hierarchy paired with JetBrains Mono for metrics and tokens.
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs">
                <div className="p-3 rounded-lg bg-[#F7F8F5] border border-[#DDE2DE] space-y-1">
                  <span className="text-[10px] font-mono text-[#8A918D] uppercase">Heading 1 Display</span>
                  <p className="text-xl font-bold text-[#0A0D0C] font-sans">Whole-Workflow Optimizer</p>
                </div>
                <div className="p-3 rounded-lg bg-[#F7F8F5] border border-[#DDE2DE] space-y-1">
                  <span className="text-[10px] font-mono text-[#8A918D] uppercase">Monospace Metrics</span>
                  <p className="text-xl font-bold text-[#007A52] font-mono">24.9 gCO₂e • 1,520 ms</p>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Button Variants & Sizes */}
          <Card>
            <CardHeader>
              <CardTitle>2. Buttons &amp; Interactive Triggers</CardTitle>
              <CardDescription>
                Semantic variants with loading states, icon alignments, and focus rings.
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="flex flex-wrap items-center gap-3">
                <Button variant="primary">Primary Action</Button>
                <Button variant="eco" icon={Leaf}>Carbon Optimized</Button>
                <Button variant="secondary" icon={Clock}>Secondary</Button>
                <Button variant="outline" icon={GitMerge}>Outline</Button>
                <Button variant="ghost">Ghost Button</Button>
                <Button variant="danger" icon={AlertTriangle}>Abort Workflow</Button>
                <Button variant="primary" isLoading>Evaluating</Button>
              </div>

              <div className="flex items-center gap-3 mt-4 pt-4 border-t border-[#DDE2DE]">
                <Button size="sm" variant="eco">Small (sm)</Button>
                <Button size="md" variant="eco">Medium (md)</Button>
                <Button size="lg" variant="eco">Large (lg)</Button>
              </div>
            </CardContent>
          </Card>

          {/* Semantic Status Badges */}
          <Card>
            <CardHeader>
              <CardTitle>3. Semantic Badges &amp; Status Indicators</CardTitle>
              <CardDescription>
                High contrast status representations not relying on color alone.
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex flex-wrap items-center gap-2">
                <Badge variant="carbon" showDefaultIcon>24.9 gCO₂e Saved</Badge>
                <Badge variant="latency" showDefaultIcon>890ms Saved</Badge>
                <Badge variant="model" showDefaultIcon>Gemini 2.5 Flash</Badge>
                <Badge variant="success" showDefaultIcon>Quality Gate Passed</Badge>
                <Badge variant="warning" showDefaultIcon>Approaching 80% Budget</Badge>
                <Badge variant="error" showDefaultIcon>SLA Violation</Badge>
                <Badge variant="info" showDefaultIcon>Batch Slack Window</Badge>
                <Badge variant="neutral">Draft</Badge>
              </div>

              <div className="flex flex-wrap items-center gap-4 pt-3 border-t border-[#DDE2DE]">
                <StatusIndicator status="running" showPulse label="Workflow Running" />
                <StatusIndicator status="completed" label="Completed" />
                <StatusIndicator status="scheduled" label="Scheduled" />
                <StatusIndicator status="delayed" label="Delayed for Clean Grid" />
                <StatusIndicator status="escalated" label="Escalated" />
                <StatusIndicator status="failed" label="Failed" />
              </div>
            </CardContent>
          </Card>

          {/* Metric Cards */}
          <Card>
            <CardHeader>
              <CardTitle>4. Metric Cards</CardTitle>
              <CardDescription>
                Displays value, unit, and mandatory contextual explanation sentence.
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                <MetricCard
                  label="Workflow Carbon"
                  value="24.9"
                  unit="gCO₂e"
                  context="Estimated workflow carbon emissions"
                  status="optimal"
                  icon={Leaf}
                  trend={{ value: '-59.6%', direction: 'down-good' }}
                />
                <MetricCard
                  label="Critical Path Latency"
                  value="1,520"
                  unit="ms"
                  context="Aggregated parallel DAG duration"
                  status="optimal"
                  icon={Clock}
                  trend={{ value: '-890ms', direction: 'down-good' }}
                />
                <MetricCard
                  label="Average Confidence"
                  value="94.6"
                  unit="%"
                  context="Mean quality gate verification score"
                  status="neutral"
                  icon={ShieldCheck}
                  badge="Exceeds 88%"
                />
              </div>
            </CardContent>
          </Card>

          {/* Sliders & Dropdowns */}
          <Card>
            <CardHeader>
              <CardTitle>5. Sliders, Form Inputs &amp; Progress Bars</CardTitle>
              <CardDescription>
                Parametric inputs used in What-If Simulator and Carbon Budget tracking.
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-5">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <Slider
                  id="budget-slider"
                  label="Carbon Budget Cap"
                  value={sliderValue}
                  min={10}
                  max={100}
                  unit="gCO₂e"
                  onChange={setSliderValue}
                  helperText="Lower caps force agent downscaling to leaner models"
                />

                <Select
                  id="model-select"
                  label="Default Routing Model Strategy"
                  options={selectOptions}
                  value={selectValue}
                  onChange={setSelectValue}
                  helperText="Fallback model tier if confidence passes"
                />
              </div>

              <div className="pt-3 border-t border-[#DDE2DE] space-y-3">
                <Progress
                  value={progressValue}
                  max={100}
                  showLabel
                  label="Workflow Carbon Budget Consumed"
                  unit=" gCO₂e"
                  thresholdMarker={80}
                />
              </div>
            </CardContent>
          </Card>
        </div>
      )}

      {/* Tab 2: Feedback & States */}
      {activeTab === 'feedback' && (
        <div className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Alerts &amp; Semantic Notifications</CardTitle>
              <CardDescription>
                Informative, warning, error, and success banners.
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-3">
              <Alert variant="info" title="Scheduler Optimization Complete">
                Dynamic DAG schedule converged in 12ms. 3 of 6 nodes downscaled to Flash.
              </Alert>
              <Alert variant="success" title="Quality Gate Passed (96%)">
                Triage intent classification exceeded the 85% safety boundary without escalation.
              </Alert>
              <Alert variant="warning" title="Carbon Budget Warning (78% Consumed)">
                Workflow has consumed 39.0 gCO₂e of its 50.0 gCO₂e allocation.
              </Alert>
              <Alert variant="error" title="Deadline Breach Alert">
                Customer SLA deadline exceeded by 420ms due to external knowledge base latency.
              </Alert>
            </CardContent>
          </Card>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <EmptyState
              title="No Escalated Tasks"
              description="All agent nodes operated cleanly above their confidence safety margins."
              actionLabel="View Quality Rules"
              onAction={() => {}}
            />

            <LoadingState
              message="Optimizing DAG..."
              subtitle="Testing model routing combinations against carbon budget"
            />

            <ErrorState
              title="Regional Grid API Error"
              message="Could not retrieve real-time marginal emissions for US-East."
              onRetry={() => {}}
            />
          </div>
        </div>
      )}

      {/* Tab 3: DAG & Explainability */}
      {activeTab === 'workflow' && (
        <div className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Decision Explainer ("WHY DID THIS HAPPEN?")</CardTitle>
              <CardDescription>
                Every automated model routing or delay decision must be explainable.
              </CardDescription>
            </CardHeader>
            <CardContent>
              <DecisionExplainer
                reason={inspectNode.decisionReason}
                nodeName={inspectNode.name}
                modelName={inspectNode.model}
                carbonSavedGrams={inspectNode.estimatedCarbonGrams}
                latencySavedMs={inspectNode.slackMs}
              />
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Workflow DAG Node Cards</CardTitle>
              <CardDescription>
                Interactive graph cards displaying status, model tier, carbon, latency, and explainability links.
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="flex flex-wrap gap-4">
                {PRIMARY_WORKFLOW_NODES.slice(0, 3).map((node) => (
                  <WorkflowNodeCard
                    key={node.id}
                    node={node}
                    isSelected={inspectNode.id === node.id}
                    onSelect={(n) => {
                      setInspectNode(n);
                      setIsDrawerOpen(true);
                    }}
                  />
                ))}
              </div>
            </CardContent>
          </Card>
        </div>
      )}

      {/* Tab 4: React Bits Pro: Dot Shift Playground */}
      {activeTab === 'dotshift' && (
        <div className="space-y-6">
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <div>
                  <CardTitle>React Bits Pro — Dot Shift Component</CardTitle>
                  <CardDescription>
                    Shifting grid of animated dots with harmonic wave motion, cursor deflection, and configurable density and softness.
                  </CardDescription>
                </div>
                <Badge variant="carbon">@reactbits-starter/dot-shift-tw</Badge>
              </div>
            </CardHeader>
            <CardContent className="space-y-6">
              {/* Interactive Visual Canvas Container */}
              <div className="relative h-72 sm:h-96 w-full rounded-xl border border-[#DDE2DE] bg-[#F7F8F5] overflow-hidden flex items-center justify-center">
                <DotShift
                  speed={dotSpeed / 100}
                  scale={dotScale / 100}
                  dotSize={dotSize / 100}
                  dotBlur={dotBlur / 100}
                  baseColor={dotColor}
                  opacity={0.4}
                  interactive={true}
                  className="absolute inset-0 w-full h-full"
                />
                <div className="relative z-10 text-center pointer-events-none p-6 rounded-xl bg-[#FFFFFF]/85 backdrop-blur-xs border border-[#DDE2DE] max-w-md shadow-xs">
                  <span className="text-[10px] font-mono uppercase tracking-wider text-[#007A52] font-semibold">
                    Live Shifting Dot Grid
                  </span>
                  <h3 className="text-base font-bold text-[#0A0D0C] mt-1">
                    Harmonic Grid Wave Animation
                  </h3>
                  <p className="text-xs text-[#68706B] mt-1">
                    Move your cursor over this container to see organic particle deflection, or adjust parameters below.
                  </p>
                </div>
              </div>

              {/* Parametric Controls */}
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 p-4 rounded-xl bg-[#FFFFFF] border border-[#DDE2DE]">
                <Slider
                  id="param-speed"
                  label="Speed Multiplier"
                  value={dotSpeed}
                  min={10}
                  max={200}
                  unit="%"
                  onChange={setDotSpeed}
                  helperText={`${(dotSpeed / 100).toFixed(2)}x animation velocity`}
                />
                <Slider
                  id="param-scale"
                  label="Grid Scale"
                  value={dotScale}
                  min={20}
                  max={150}
                  unit="%"
                  onChange={setDotScale}
                  helperText={`${(dotScale / 100).toFixed(2)} density scale`}
                />
                <Slider
                  id="param-size"
                  label="Dot Size"
                  value={dotSize}
                  min={20}
                  max={150}
                  unit="%"
                  onChange={setDotSize}
                  helperText={`${(dotSize / 100).toFixed(2)}x dot radius`}
                />
                <Slider
                  id="param-blur"
                  label="Dot Softness / Blur"
                  value={dotBlur}
                  min={0}
                  max={100}
                  unit="%"
                  onChange={setDotBlur}
                  helperText={dotBlur < 10 ? 'Crisp sharp circles' : `${(dotBlur / 100).toFixed(2)} soft radial glow`}
                />
              </div>

              {/* Color Selection & Integration Snippets */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6 pt-2">
                <div className="space-y-3">
                  <span className="text-xs font-semibold text-[#0A0D0C]">Base Color Accent</span>
                  <div className="flex flex-wrap items-center gap-2">
                    {[
                      { name: 'Vivid Green (#00D98B)', hex: '#00D98B' },
                      { name: 'Deep Eco Green (#007A52)', hex: '#007A52' },
                      { name: 'Carbon Slate (#0A0D0C)', hex: '#0A0D0C' },
                      { name: 'React Bits Pink (#FF9FFC)', hex: '#FF9FFC' },
                    ].map((c) => (
                      <button
                        key={c.hex}
                        type="button"
                        onClick={() => setDotColor(c.hex)}
                        className={`inline-flex items-center gap-2 px-3 py-1.5 rounded-lg text-xs font-medium border transition-colors cursor-pointer ${
                          dotColor === c.hex
                            ? 'border-[#007A52] bg-[#E8F8F0] text-[#007A52] font-semibold'
                            : 'border-[#DDE2DE] bg-[#FFFFFF] text-[#68706B] hover:bg-[#F7F8F5]'
                        }`}
                      >
                        <span
                          className="w-3 h-3 rounded-full border border-black/10"
                          style={{ backgroundColor: c.hex }}
                        />
                        <span>{c.name}</span>
                      </button>
                    ))}
                  </div>
                </div>

                <div className="p-3.5 rounded-lg bg-[#F7F8F5] border border-[#DDE2DE] font-mono text-xs space-y-1.5">
                  <div className="text-[10px] uppercase text-[#68706B] font-sans font-semibold">
                    Configured Installation Command
                  </div>
                  <div className="text-[#0A0D0C] bg-[#FFFFFF] p-2 rounded border border-[#DDE2DE] overflow-x-auto">
                    <code>npx shadcn@latest add @reactbits-starter/dot-shift-tw</code>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      )}

      {/* Modal Demonstration */}
      <Modal
        isOpen={isModalOpen}
        onClose={() => setIsModalOpen(false)}
        title="Schedule Optimization Settings"
        description="Configure whole-workflow optimization heuristics and trade-off priorities"
        footer={
          <>
            <Button variant="outline" size="sm" onClick={() => setIsModalOpen(false)}>
              Cancel
            </Button>
            <Button variant="primary" size="sm" onClick={() => setIsModalOpen(false)}>
              Apply Constraints
            </Button>
          </>
        }
      >
        <div className="space-y-4 text-xs text-[#0A0D0C]">
          <p className="text-[#68706B]">
            This modal illustrates accessible keyboard trapping, escape handling, backdrop dimming, and clean form layout for CarbonPilot configuration dialogs.
          </p>
          <Slider
            label="Carbon Optimization Weight (Alpha)"
            value={sliderValue}
            min={0}
            max={100}
            unit="%"
            onChange={setSliderValue}
          />
        </div>
      </Modal>

      {/* Drawer Demonstration */}
      <Drawer
        isOpen={isDrawerOpen}
        onClose={() => setIsDrawerOpen(false)}
        title={inspectNode.name}
        subtitle="Automated Scheduling Rationale &amp; Telemetry"
        footer={
          <Button variant="secondary" size="sm" onClick={() => setIsDrawerOpen(false)}>
            Close Drawer
          </Button>
        }
      >
        <div className="space-y-4">
          <DecisionExplainer
            reason={inspectNode.decisionReason}
            nodeName={inspectNode.name}
            modelName={inspectNode.model}
            carbonSavedGrams={inspectNode.estimatedCarbonGrams}
            latencySavedMs={inspectNode.slackMs}
          />
        </div>
      </Drawer>
    </div>
  );
};
