/**
 * CarbonPilot — Baseline Comparison View (Step 6)
 * Head-to-head comparison between Unoptimized Static Frontier Baseline vs. CarbonPilot Dynamic Scheduler.
 *
 * Compare:
 * - Carbon
 * - Workflow Time
 * - Quality
 * - Cost
 * - Large Model Usage
 * - Delayed Tasks
 * - Escalations
 *
 * Key CarbonPilot Decisions explaining causes of differences.
 *
 * All values are simulated / estimated demo telemetry.
 */

import React from 'react';
import {
  Scale,
  Leaf,
  Clock,
  ShieldCheck,
  DollarSign,
  Cpu,
  Calendar,
  Zap,
  TrendingDown,
  TrendingUp,
  CheckCircle2,
  Sparkles,
  ArrowRight,
  HelpCircle,
  PlayCircle,
  LayoutDashboard,
} from 'lucide-react';

interface BaselineComparisonViewProps {
  onNavigateDemo?: () => void;
  onNavigateOverview?: () => void;
}

interface MetricRow {
  id: string;
  name: string;
  icon: React.ComponentType<{ className?: string }>;
  baselineValue: string;
  baselineSub: string;
  carbonPilotValue: string;
  carbonPilotSub: string;
  deltaText: string;
  deltaPercent: string;
  isFavorable: boolean;
  deltaType: 'decrease' | 'increase' | 'neutral';
  explanation: string;
}

export const BaselineComparisonView: React.FC<BaselineComparisonViewProps> = ({
  onNavigateDemo,
  onNavigateOverview,
}) => {
  const comparisonMetrics: MetricRow[] = [
    {
      id: 'carbon',
      name: 'Carbon Emissions',
      icon: Leaf,
      baselineValue: '61.7 gCO₂e',
      baselineSub: 'All 6 stages on Frontier Pro',
      carbonPilotValue: '24.9 gCO₂e',
      carbonPilotSub: 'Right-sized small models + solar shift',
      deltaText: '-36.8 gCO₂e',
      deltaPercent: '-59.6%',
      isFavorable: true,
      deltaType: 'decrease',
      explanation: 'Dynamic model selection and solar shifting eliminated 36.8 g of avoidable emissions.',
    },
    {
      id: 'workflow-time',
      name: 'Workflow Time',
      icon: Clock,
      baselineValue: '3,450 ms',
      baselineSub: 'Sequential heavy model inference',
      carbonPilotValue: '1,520 ms',
      carbonPilotSub: 'Parallelized fast critical path',
      deltaText: '-1,930 ms',
      deltaPercent: '-55.9%',
      isFavorable: true,
      deltaType: 'decrease',
      explanation: 'Small models run in ~190ms–640ms vs. heavy multi-second frontier execution passes.',
    },
    {
      id: 'quality',
      name: 'Quality Score',
      icon: ShieldCheck,
      baselineValue: '95.1%',
      baselineSub: 'Frontier brute-force evaluation',
      carbonPilotValue: '94.6%',
      carbonPilotSub: 'Small models + gated selective escalation',
      deltaText: '-0.5%',
      deltaPercent: '-0.5%',
      isFavorable: true,
      deltaType: 'neutral',
      explanation: 'Statistically negligible quality delta (-0.5%), preserving enterprise audit requirements.',
    },
    {
      id: 'cost',
      name: 'Inference Cost',
      icon: DollarSign,
      baselineValue: '$0.0248',
      baselineSub: '$24.80 per 1,000 runs',
      carbonPilotValue: '$0.0093',
      carbonPilotSub: '$9.30 per 1,000 runs',
      deltaText: '-$0.0155',
      deltaPercent: '-62.5%',
      isFavorable: true,
      deltaType: 'decrease',
      explanation: 'Replacing large model tokens with lightweight Flash inferences lowered API spend by 62.5%.',
    },
    {
      id: 'large-model-usage',
      name: 'Large Model Usage',
      icon: Cpu,
      baselineValue: '100%',
      baselineSub: '6 of 6 stages using Frontier Pro',
      carbonPilotValue: '16.7%',
      carbonPilotSub: '1 of 6 stages (Final Synthesis only)',
      deltaText: '-83.3% usage',
      deltaPercent: '-83.3%',
      isFavorable: true,
      deltaType: 'decrease',
      explanation: 'Frontier models reserved exclusively for high-ambiguity synthesis and clause escalation.',
    },
    {
      id: 'delayed-tasks',
      name: 'Delayed Tasks',
      icon: Calendar,
      baselineValue: '0 tasks',
      baselineSub: 'Immediate execution on local grid',
      carbonPilotValue: '1 task',
      carbonPilotSub: 'Task 4 deferred +45s (Solar peak)',
      deltaText: '+1 task deferred',
      deltaPercent: 'Clean Grid',
      isFavorable: true,
      deltaType: 'increase',
      explanation: 'Exploited non-critical path slack (+1,400ms) to shift audit batch into low-emission window.',
    },
    {
      id: 'escalations',
      name: 'Escalations',
      icon: Zap,
      baselineValue: '0 escalations',
      baselineSub: 'Static pipeline (no conditional logic)',
      carbonPilotValue: '1 escalation',
      carbonPilotSub: 'Ambiguous clause #14 escalated to Pro',
      deltaText: '1 selective',
      deltaPercent: 'Dynamic',
      isFavorable: true,
      deltaType: 'neutral',
      explanation: 'Quality gate dynamically escalated only the single high-risk contract clause to Pro.',
    },
  ];

  const decisions = [
    {
      id: 'dec-1',
      title: 'Dynamic Model Right-Sizing',
      badge: 'Primary Carbon Lever',
      description:
        'Document Analysis and Policy Retrieval were classified as structured classification tasks with high inherent model confidence (96%). CarbonPilot assigned lightweight Gemini Flash instead of frontier models, reducing stage emissions by 65% with zero quality loss.',
      statLabel: 'Emissions Saved',
      statValue: '-65% on Stages 1 & 2',
    },
    {
      id: 'dec-2',
      title: 'Quality-Gated Selective Escalation',
      badge: 'Accuracy Preservation',
      description:
        'Rather than executing the entire contract extraction through expensive frontier reasoning, the pipeline ran a fast verification pass. Only Clause #14 showed lower confidence (88.4%), triggering an isolated micro-escalation to Gemini Pro while keeping 90% of tokens on low-carbon models.',
      statLabel: 'Quality Preserved',
      statValue: '94.6% vs 95.1% Baseline',
    },
    {
      id: 'dec-3',
      title: 'Slack Exploitation & Solar Window Deferral',
      badge: 'Temporal Grid Optimization',
      description:
        'The compliance audit batch task sat off the critical path with +1,400 ms of slack before the hard SLA deadline. CarbonPilot scheduled a +45-second deferral into a forecast renewable energy window (180 gCO₂/kWh down from 340 gCO₂/kWh).',
      statLabel: 'Carbon Intensity Reduction',
      statValue: '-47% Grid Carbon Rate',
    },
    {
      id: 'dec-4',
      title: 'Deterministic Code Offload',
      badge: 'Zero-LLM Dispatch',
      description:
        'Final ledger recording, hash verification, and downstream dispatch were mapped to pure deterministic code routines instead of LLM token generation, cutting unnecessary compute overhead to near zero (0.3 gCO₂e).',
      statLabel: 'Stage Carbon',
      statValue: '0.3g (vs. 4.8g Baseline)',
    },
  ];

  return (
    <div className="max-w-7xl mx-auto space-y-6 pb-14">
      {/* Header */}
      <header className="pb-4 border-b border-[#DDE2DE]">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 mb-1">
          <div className="flex items-center gap-2">
            <div className="w-6 h-6 rounded-md bg-[#E7F8F1] border border-[#C9EBDC] flex items-center justify-center text-[#007A52]">
              <Scale className="w-3.5 h-3.5" />
            </div>
            <span className="text-[11px] font-mono text-[#007A52] font-semibold tracking-wide uppercase">
              Benchmarking
            </span>
          </div>

          {/* SIMULATED / ESTIMATED DISCLAIMER */}
          <div className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-[11px] font-mono font-bold bg-[#FEF5E7] text-[#B9770E] border border-[#FAD7A0] w-fit">
            <Sparkles className="w-3.5 h-3.5" />
            <span>Demo / Simulated / Estimated Telemetry • Synthetic Benchmark</span>
          </div>
        </div>

        <h1 className="text-xl sm:text-2xl font-bold text-[#0A0D0C] tracking-tight">
          Baseline vs. CarbonPilot
        </h1>
        <p className="text-xs sm:text-sm text-[#68706B] mt-1 max-w-3xl leading-relaxed">
          Side-by-side empirical comparison evaluating an unoptimized static pipeline (deploying frontier models across all stages immediately) against CarbonPilot&apos;s dynamic DAG scheduling, right-sizing, and clean grid shifting.
        </p>
      </header>

      {/* ==================================================
          SIDE-BY-SIDE SUMMARY HERO
          ================================================== */}
      <section className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {/* Baseline Card */}
        <div className="rounded-2xl border border-[#DDE2DE] bg-[#FFFFFF] p-5 shadow-xs space-y-3">
          <div className="flex items-center justify-between pb-2 border-b border-[#DDE2DE]">
            <div>
              <span className="text-[10px] font-mono uppercase tracking-wider text-[#8A918D] font-bold block">
                Standard Industry Practice
              </span>
              <h2 className="text-base font-bold text-[#0A0D0C]">
                Unoptimized Baseline
              </h2>
            </div>
            <span className="px-2 py-0.5 rounded text-[11px] font-mono font-semibold bg-[#F7F8F5] text-[#68706B] border border-[#DDE2DE]">
              Static Frontier
            </span>
          </div>
          <p className="text-xs text-[#68706B] leading-relaxed">
            Every pipeline node invokes flagship Gemini 2.5 Pro frontier models. Tasks run immediately upon arrival without regard to marginal grid carbon intensity or critical path slack.
          </p>
          <div className="grid grid-cols-2 gap-2 pt-1">
            <div className="p-2.5 rounded-xl bg-[#F7F8F5] border border-[#DDE2DE]">
              <span className="text-[10px] font-mono text-[#8A918D] uppercase block">Total Carbon</span>
              <span className="text-lg font-bold font-mono text-[#0A0D0C]">61.7 gCO₂e</span>
            </div>
            <div className="p-2.5 rounded-xl bg-[#F7F8F5] border border-[#DDE2DE]">
              <span className="text-[10px] font-mono text-[#8A918D] uppercase block">Wall Clock Time</span>
              <span className="text-lg font-bold font-mono text-[#0A0D0C]">3,450 ms</span>
            </div>
          </div>
        </div>

        {/* CarbonPilot Card */}
        <div className="rounded-2xl border border-[#C9EBDC] bg-[#E7F8F1]/40 p-5 shadow-xs space-y-3 relative overflow-hidden">
          <div className="flex items-center justify-between pb-2 border-b border-[#C9EBDC]">
            <div>
              <span className="text-[10px] font-mono uppercase tracking-wider text-[#007A52] font-bold block">
                Intelligent Scheduling
              </span>
              <h2 className="text-base font-bold text-[#0A0D0C] flex items-center gap-1.5">
                <span>CarbonPilot Optimizer</span>
                <CheckCircle2 className="w-4 h-4 text-[#007A52]" />
              </h2>
            </div>
            <span className="px-2 py-0.5 rounded text-[11px] font-mono font-semibold bg-[#00D98B]/20 text-[#007A52] border border-[#00D98B]/40">
              Active Optimization
            </span>
          </div>
          <p className="text-xs text-[#68706B] leading-relaxed">
            Small models deployed by default with quality-gated frontier escalation. Non-critical tasks deferred into renewable grid peaks. Deterministic code offload.
          </p>
          <div className="grid grid-cols-2 gap-2 pt-1">
            <div className="p-2.5 rounded-xl bg-[#FFFFFF] border border-[#C9EBDC]">
              <span className="text-[10px] font-mono text-[#007A52] font-semibold uppercase block">Total Carbon</span>
              <span className="text-lg font-bold font-mono text-[#007A52]">24.9 gCO₂e</span>
              <span className="text-[10px] font-mono text-[#007A52] block font-semibold">-59.6% reduction</span>
            </div>
            <div className="p-2.5 rounded-xl bg-[#FFFFFF] border border-[#C9EBDC]">
              <span className="text-[10px] font-mono text-[#007A52] font-semibold uppercase block">Critical Path Time</span>
              <span className="text-lg font-bold font-mono text-[#0A0D0C]">1,520 ms</span>
              <span className="text-[10px] font-mono text-[#007A52] block font-semibold">-55.9% faster</span>
            </div>
          </div>
        </div>
      </section>

      {/* ==================================================
          DETAILED COMPARISON TABLE
          Compare:
          Carbon
          Workflow Time
          Quality
          Cost
          Large Model Usage
          Delayed Tasks
          Escalations
          ================================================== */}
      <section className="rounded-2xl border border-[#DDE2DE] bg-[#FFFFFF] shadow-xs overflow-hidden">
        <div className="p-4 sm:p-5 border-b border-[#DDE2DE] flex flex-col sm:flex-row sm:items-center justify-between gap-2">
          <div>
            <h2 className="text-sm sm:text-base font-bold text-[#0A0D0C]">
              Direct Head-to-Head Comparison
            </h2>
            <p className="text-xs text-[#68706B]">
              Core system telemetry contrasting unoptimized baseline against CarbonPilot scheduler
            </p>
          </div>
          <div className="text-xs font-mono text-[#8A918D]">
            All 7 Benchmark Metrics
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="border-b border-[#DDE2DE] bg-[#F7F8F5] text-[11px] font-mono uppercase tracking-wider text-[#8A918D]">
                <th className="py-3 px-4 sm:px-6">Metric</th>
                <th className="py-3 px-4">Baseline (Unoptimized)</th>
                <th className="py-3 px-4">CarbonPilot</th>
                <th className="py-3 px-4">Delta</th>
                <th className="py-3 px-4 sm:px-6 hidden lg:table-cell">Scheduler Mechanism</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#DDE2DE] text-xs">
              {comparisonMetrics.map((m) => {
                const Icon = m.icon;
                return (
                  <tr key={m.id} className="hover:bg-[#F7F8F5]/60 transition-colors">
                    {/* Metric Name */}
                    <td className="py-3.5 px-4 sm:px-6">
                      <div className="flex items-center gap-2.5">
                        <div className="w-7 h-7 rounded-lg bg-[#F7F8F5] border border-[#DDE2DE] flex items-center justify-center text-[#0A0D0C] shrink-0">
                          <Icon className="w-3.5 h-3.5" />
                        </div>
                        <div>
                          <span className="font-bold text-[#0A0D0C] block">
                            {m.name}
                          </span>
                        </div>
                      </div>
                    </td>

                    {/* Baseline */}
                    <td className="py-3.5 px-4">
                      <div className="font-mono font-bold text-[#0A0D0C]">
                        {m.baselineValue}
                      </div>
                      <div className="text-[11px] text-[#8A918D]">
                        {m.baselineSub}
                      </div>
                    </td>

                    {/* CarbonPilot */}
                    <td className="py-3.5 px-4">
                      <div className="font-mono font-bold text-[#007A52]">
                        {m.carbonPilotValue}
                      </div>
                      <div className="text-[11px] text-[#68706B]">
                        {m.carbonPilotSub}
                      </div>
                    </td>

                    {/* Delta */}
                    <td className="py-3.5 px-4">
                      <div className="inline-flex items-center gap-1 px-2 py-0.5 rounded-md font-mono font-bold text-xs bg-[#E7F8F1] text-[#007A52] border border-[#C9EBDC]">
                        {m.deltaType === 'decrease' && <TrendingDown className="w-3 h-3" />}
                        {m.deltaType === 'increase' && <TrendingUp className="w-3 h-3" />}
                        <span>{m.deltaText}</span>
                      </div>
                      <div className="text-[10px] font-mono text-[#8A918D] mt-0.5">
                        {m.deltaPercent}
                      </div>
                    </td>

                    {/* Mechanism */}
                    <td className="py-3.5 px-4 sm:px-6 hidden lg:table-cell text-[#68706B] text-[11px] max-w-xs leading-relaxed">
                      {m.explanation}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </section>

      {/* ==================================================
          "KEY CARBONPILOT DECISIONS"
          Explain what caused the differences.
          ================================================== */}
      <section className="rounded-2xl border border-[#DDE2DE] bg-[#FFFFFF] p-5 sm:p-6 shadow-xs space-y-4">
        <div className="flex items-center justify-between pb-2 border-b border-[#DDE2DE]">
          <div className="flex items-center gap-2">
            <div className="w-6 h-6 rounded-md bg-[#E7F8F1] border border-[#C9EBDC] flex items-center justify-center text-[#007A52]">
              <Sparkles className="w-3.5 h-3.5" />
            </div>
            <div>
              <h2 className="text-base sm:text-lg font-bold text-[#0A0D0C] tracking-tight">
                Key CarbonPilot Decisions
              </h2>
              <p className="text-xs text-[#68706B]">
                Causal factors explaining why CarbonPilot achieves 59.6% carbon reduction at quality parity
              </p>
            </div>
          </div>
          <span className="text-xs font-mono font-semibold text-[#007A52] bg-[#E7F8F1] px-2.5 py-1 rounded border border-[#C9EBDC] hidden sm:block">
            4 Core Architectural Decisions
          </span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 pt-1">
          {decisions.map((dec, idx) => (
            <div
              key={dec.id}
              className="p-4 rounded-xl border border-[#DDE2DE] bg-[#F7F8F5] space-y-2.5 hover:border-[#00D98B] transition-colors"
            >
              <div className="flex items-center justify-between gap-2">
                <div className="flex items-center gap-2">
                  <span className="w-5 h-5 rounded-full bg-[#FFFFFF] border border-[#DDE2DE] text-[11px] font-mono font-bold text-[#0A0D0C] flex items-center justify-center">
                    {idx + 1}
                  </span>
                  <h3 className="text-xs sm:text-sm font-bold text-[#0A0D0C]">
                    {dec.title}
                  </h3>
                </div>
                <span className="text-[10px] font-mono font-semibold text-[#007A52] bg-[#E7F8F1] px-2 py-0.5 rounded border border-[#C9EBDC] shrink-0">
                  {dec.badge}
                </span>
              </div>

              <p className="text-xs text-[#68706B] leading-relaxed">
                {dec.description}
              </p>

              <div className="pt-2 border-t border-[#DDE2DE] flex items-center justify-between text-[11px] font-mono">
                <span className="text-[#8A918D]">{dec.statLabel}:</span>
                <span className="font-bold text-[#007A52]">{dec.statValue}</span>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* ==================================================
          NAVIGATION CTA
          ================================================== */}
      <section className="rounded-2xl border border-[#DDE2DE] bg-[#FFFFFF] p-5 shadow-xs flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h3 className="text-sm font-bold text-[#0A0D0C]">
            Experience the Step-by-Step Execution
          </h3>
          <p className="text-xs text-[#68706B] mt-0.5">
            Take the interactive 3-minute guided walkthrough through each stage of the CarbonPilot decision sequence.
          </p>
        </div>

        <div className="flex items-center gap-2.5 shrink-0">
          {onNavigateOverview && (
            <button
              onClick={onNavigateOverview}
              className="px-3.5 py-2 rounded-xl border border-[#DDE2DE] text-xs font-semibold text-[#0A0D0C] hover:bg-[#F7F8F5] transition-colors cursor-pointer flex items-center gap-1.5"
            >
              <LayoutDashboard className="w-3.5 h-3.5 text-[#68706B]" />
              <span>Overview</span>
            </button>
          )}

          {onNavigateDemo && (
            <button
              onClick={onNavigateDemo}
              className="px-4 py-2 rounded-xl bg-[#007A52] hover:bg-[#005F3F] text-white text-xs font-semibold shadow-xs transition-colors cursor-pointer flex items-center gap-1.5"
            >
              <PlayCircle className="w-3.5 h-3.5 text-white" />
              <span>Start Guided Demo Mode</span>
              <ArrowRight className="w-3.5 h-3.5 text-white" />
            </button>
          )}
        </div>
      </section>
    </div>
  );
};
