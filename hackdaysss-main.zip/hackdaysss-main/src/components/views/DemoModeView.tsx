/**
 * CarbonPilot — Demo Mode (Step 6)
 * Guided 3-minute interactive demonstration.
 *
 * Sequence:
 * 1. Workflow
 * 2. Model Selection
 * 3. Quality Gate
 * 4. Carbon Budget
 * 5. Deadline Slack
 * 6. Final Result
 *
 * Controls:
 * - Next
 * - Back
 * - Restart Demo
 *
 * At every stage explain:
 * - What happened?
 * - Why?
 * - What was the trade-off?
 *
 * Final screen:
 * - Workflow Complete
 * - Carbon
 * - Time
 * - Quality
 * - Budget
 * - Slack
 * - Compare with Baseline
 *
 * All values are simulated / estimated demo telemetry.
 */

import React, { useState } from 'react';
import {
  Sparkles,
  ArrowRight,
  ArrowLeft,
  RotateCcw,
  GitMerge,
  Cpu,
  ShieldCheck,
  Leaf,
  Clock,
  CheckCircle2,
  Scale,
  Sun,
  Zap,
  Info,
  Layers,
  AlertCircle,
  TrendingDown,
  LayoutDashboard,
} from 'lucide-react';

interface DemoModeViewProps {
  onNavigateComparison?: () => void;
  onNavigateWorkflow?: () => void;
}

type DemoStageId = 'workflow' | 'model_selection' | 'quality_gate' | 'carbon_budget' | 'deadline_slack' | 'final_result';

interface DemoStageConfig {
  id: DemoStageId;
  stepNumber: number;
  label: string;
  title: string;
  subtitle: string;
  icon: React.ComponentType<{ className?: string }>;
  whatHappened: string;
  why: string;
  tradeOff: string;
}

const DEMO_STAGES: DemoStageConfig[] = [
  {
    id: 'workflow',
    stepNumber: 1,
    label: 'Workflow',
    title: 'Stage 1: Workflow Architecture & DAG Decomposition',
    subtitle: 'Deconstructing document processing into discrete, schedulable dependencies',
    icon: GitMerge,
    whatHappened:
      'CarbonPilot analyzed the incoming document compliance request and mapped it into a Directed Acyclic Graph (DAG) consisting of 6 decoupled tasks: Triage, Context Retrieval, Multimodal Extraction, Compliance Audit, Quality Verification, and Synthesis.',
    why: 'Monolithic prompts force every step into an oversized context window on a single expensive model. Decomposing the pipeline into a DAG allows CarbonPilot to assign individual models, optimize dependencies, and exploit slack on independent branches.',
    tradeOff:
      'Orchestration introduces microsecond DAG state-tracking overhead (~4 ms), but in return enables granular model right-sizing and selective solar-peak deferrals across every subtask.',
  },
  {
    id: 'model_selection',
    stepNumber: 2,
    label: 'Model Selection',
    title: 'Stage 2: Model Selection & Right-Sizing',
    subtitle: 'Assigning lightweight models by default based on task complexity profiling',
    icon: Cpu,
    whatHappened:
      'Document Triage and Table Extraction tasks were evaluated for syntactic complexity. Because confidence for classification was predicted at 96%, CarbonPilot selected Gemini 2.5 Flash (Small) instead of default Gemini 2.5 Pro (Frontier).',
    why: 'Routine extraction, schema classification, and metadata filtering do not require frontier reasoning parameters. Running small models cuts stage energy consumption by over 65% while delivering sub-200ms latency.',
    tradeOff:
      'Small models exhibit slightly higher variance on rare legal edge cases. Rather than overpaying upfront with large models, CarbonPilot mitigates this risk through downstream quality verification gates.',
  },
  {
    id: 'quality_gate',
    stepNumber: 3,
    label: 'Quality Gate',
    title: 'Stage 3: Quality Gate & Selective Escalation',
    subtitle: 'Conditional verification triggers frontier escalation only for ambiguous clauses',
    icon: ShieldCheck,
    whatHappened:
      'A fast verification check evaluated extraction confidence against a 90.0% accuracy threshold. General clauses scored 94.2% (Passed). However, ambiguous indemnity Clause #14 scored 88.4%, triggering an isolated micro-escalation to Gemini 2.5 Pro for that clause alone.',
    why: 'Brute-forcing an entire 20-page agreement through frontier models burns ~15.2 gCO₂e. Isolating only the ambiguous clause saves 72% of frontier tokens while still guaranteeing 100% legal audit compliance.',
    tradeOff:
      'Running the quality gate adds a fast verification check (+240 ms), but prevents either blind hallucination propagation or whole-pipeline model overprovisioning.',
  },
  {
    id: 'carbon_budget',
    stepNumber: 4,
    label: 'Carbon Budget',
    title: 'Stage 4: Carbon Budget Enforcement',
    subtitle: 'Tracking emissions against organizational caps to guarantee budget feasibility',
    icon: Leaf,
    whatHappened:
      'The pipeline monitored cumulative emissions against a 50.0 gCO₂e budget ceiling. When final synthesis considered a speculative multi-pass chain-of-thought review (+28 gCO₂e), the scheduler rejected it for risk of budget breach and selected an optimal single-pass frontier synthesis (12.4 gCO₂e).',
    why: 'Sustainable AI requires hard governance ceilings. By checking cumulative burn at each node transition, CarbonPilot ensures corporate sustainability policies are programmatically enforced rather than treated as afterthoughts.',
    tradeOff:
      'The synthesis output focuses on actionable risk remediation items rather than generating a 14-page speculative appendix, preserving compliance within budget without sacrificing core insights.',
  },
  {
    id: 'deadline_slack',
    stepNumber: 5,
    label: 'Deadline Slack',
    title: 'Stage 5: Deadline Slack & Clean Grid Deferral',
    subtitle: 'Exploiting non-critical path time buffers to shift batch compute into solar peaks',
    icon: Clock,
    whatHappened:
      'Critical path analysis calculated a 1,520 ms delivery time against a 2,500 ms SLA deadline, providing +980 ms of slack. Task 4 (Compliance Audit Batch) had +1,400 ms of local branch slack. CarbonPilot deferred Task 4 by +45 seconds into a forecast renewable energy window (180 vs. 340 gCO₂/kWh).',
    why: 'Data center grid emissions fluctuate continuously based on regional solar and wind availability. Scheduling non-urgent background batch work during renewable peaks cuts marginal emissions by 47% at zero hardware cost.',
    tradeOff:
      'Audit batch ledger syncing completes 45 seconds later in background storage, but user-facing contract risk synthesis is delivered to the operator in 1.52 seconds, safely inside the SLA deadline.',
  },
  {
    id: 'final_result',
    stepNumber: 6,
    label: 'Final Result',
    title: 'Stage 6: Execution Complete & System Telemetry',
    subtitle: 'Global optimization outcome satisfying carbon, latency, quality, and cost constraints',
    icon: CheckCircle2,
    whatHappened:
      'All 6 pipeline stages finished execution. The workflow achieved a 59.6% carbon reduction with zero SLA deadline violations and preserved 99.5% quality parity with unoptimized baselines.',
    why: 'By combining model right-sizing, quality-gated micro-escalations, hard carbon budget checks, and slack-aware solar deferrals, CarbonPilot successfully unlocked optimal multi-constraint execution.',
    tradeOff:
      'Zero trade-off penalties on the critical path: user response time was actually 55.9% faster (1,520 ms vs. 3,450 ms) because small models executed significantly faster than static frontier giants.',
  },
];

export const DemoModeView: React.FC<DemoModeViewProps> = ({
  onNavigateComparison,
  onNavigateWorkflow,
}) => {
  const [currentStageIndex, setCurrentStageIndex] = useState<number>(0);

  const currentStage = DEMO_STAGES[currentStageIndex];
  const isFirstStage = currentStageIndex === 0;
  const isLastStage = currentStageIndex === DEMO_STAGES.length - 1;

  const handleNext = () => {
    if (!isLastStage) {
      setCurrentStageIndex((prev) => prev + 1);
    } else if (onNavigateComparison) {
      onNavigateComparison();
    }
  };

  const handleBack = () => {
    if (!isFirstStage) {
      setCurrentStageIndex((prev) => prev - 1);
    }
  };

  const handleRestart = () => {
    setCurrentStageIndex(0);
  };

  return (
    <div className="max-w-7xl mx-auto space-y-6 pb-14">
      {/* Header */}
      <header className="pb-4 border-b border-[#DDE2DE]">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 mb-1">
          <div className="flex items-center gap-2">
            <div className="w-6 h-6 rounded-md bg-[#E7F8F1] border border-[#C9EBDC] flex items-center justify-center text-[#007A52]">
              <Sparkles className="w-3.5 h-3.5" />
            </div>
            <span className="text-[11px] font-mono text-[#007A52] font-semibold tracking-wide uppercase">
              Guided Walkthrough
            </span>
          </div>

          {/* SIMULATED / ESTIMATED DISCLAIMER */}
          <div className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-[11px] font-mono font-bold bg-[#FEF5E7] text-[#B9770E] border border-[#FAD7A0] w-fit">
            <Sparkles className="w-3.5 h-3.5" />
            <span>3-Minute Guided Demo • Simulated Telemetry</span>
          </div>
        </div>

        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div>
            <h1 className="text-xl sm:text-2xl font-bold text-[#0A0D0C] tracking-tight">
              CarbonPilot Interactive Demo
            </h1>
            <p className="text-xs sm:text-sm text-[#68706B] mt-0.5 max-w-2xl leading-relaxed">
              Step through the 6-stage lifecycle of how CarbonPilot optimizes real-world AI pipelines for minimum emissions without violating SLA deadlines or accuracy thresholds.
            </p>
          </div>

          {/* Step Progress Counter */}
          <div className="flex items-center gap-2 shrink-0">
            <span className="text-xs font-mono font-bold text-[#007A52] bg-[#E7F8F1] px-3 py-1 rounded-full border border-[#C9EBDC]">
              Step {currentStage.stepNumber} of 6
            </span>
          </div>
        </div>
      </header>

      {/* ==================================================
          SEQUENCE PROGRESS TABS:
          1. Workflow
          2. Model Selection
          3. Quality Gate
          4. Carbon Budget
          5. Deadline Slack
          6. Final Result
          ================================================== */}
      <nav aria-label="Demo Sequence" className="rounded-xl border border-[#DDE2DE] bg-[#FFFFFF] p-2 shadow-xs">
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-1.5">
          {DEMO_STAGES.map((stage, idx) => {
            const Icon = stage.icon;
            const isActive = currentStageIndex === idx;
            const isCompleted = currentStageIndex > idx;

            return (
              <button
                key={stage.id}
                onClick={() => setCurrentStageIndex(idx)}
                className={`p-2.5 rounded-lg text-left transition-all cursor-pointer flex flex-col justify-between space-y-1 ${
                  isActive
                    ? 'bg-[#007A52] text-white shadow-xs font-semibold'
                    : isCompleted
                    ? 'bg-[#E7F8F1] text-[#007A52] hover:bg-[#C9EBDC]/50'
                    : 'bg-[#F7F8F5] text-[#68706B] hover:bg-[#DDE2DE]/50'
                }`}
              >
                <div className="flex items-center justify-between">
                  <span className="text-[10px] font-mono uppercase">
                    Step {stage.stepNumber}
                  </span>
                  {isCompleted ? (
                    <CheckCircle2 className="w-3.5 h-3.5 text-[#007A52]" />
                  ) : (
                    <Icon className={`w-3.5 h-3.5 ${isActive ? 'text-white' : 'text-[#8A918D]'}`} />
                  )}
                </div>
                <span className="text-xs font-bold truncate block">
                  {stage.label}
                </span>
              </button>
            );
          })}
        </div>
      </nav>

      {/* ==================================================
          STAGE CONTENT:
          Stage 1 to 5:
          - What happened?
          - Why?
          - What was the trade-off?
          - Stage Visual Representation
          ================================================== */}
      {currentStage.id !== 'final_result' ? (
        <div className="space-y-6">
          {/* Stage Header Banner */}
          <div className="rounded-2xl border border-[#DDE2DE] bg-[#FFFFFF] p-5 sm:p-6 shadow-xs space-y-1">
            <div className="flex items-center gap-2">
              <span className="text-xs font-mono uppercase text-[#007A52] font-semibold tracking-wider">
                Demonstration Sequence • Stage {currentStage.stepNumber} of 6
              </span>
            </div>
            <h2 className="text-lg sm:text-xl font-bold text-[#0A0D0C] tracking-tight">
              {currentStage.title}
            </h2>
            <p className="text-xs sm:text-sm text-[#68706B]">
              {currentStage.subtitle}
            </p>
          </div>

          {/* The 3 Required Explanations:
              1. What happened?
              2. Why?
              3. What was the trade-off? */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {/* 1. What happened? */}
            <div className="rounded-2xl border border-[#DDE2DE] bg-[#FFFFFF] p-5 shadow-xs space-y-2">
              <div className="flex items-center gap-2 pb-2 border-b border-[#DDE2DE]">
                <div className="w-6 h-6 rounded-md bg-[#E7F8F1] border border-[#C9EBDC] flex items-center justify-center text-[#007A52]">
                  <Info className="w-3.5 h-3.5" />
                </div>
                <span className="text-xs font-mono uppercase tracking-wider text-[#007A52] font-bold">
                  What happened?
                </span>
              </div>
              <p className="text-xs sm:text-sm text-[#0A0D0C] leading-relaxed pt-1">
                {currentStage.whatHappened}
              </p>
            </div>

            {/* 2. Why? */}
            <div className="rounded-2xl border border-[#DDE2DE] bg-[#FFFFFF] p-5 shadow-xs space-y-2">
              <div className="flex items-center gap-2 pb-2 border-b border-[#DDE2DE]">
                <div className="w-6 h-6 rounded-md bg-[#F7F8F5] border border-[#DDE2DE] flex items-center justify-center text-[#0A0D0C]">
                  <Sparkles className="w-3.5 h-3.5 text-[#007A52]" />
                </div>
                <span className="text-xs font-mono uppercase tracking-wider text-[#0A0D0C] font-bold">
                  Why?
                </span>
              </div>
              <p className="text-xs sm:text-sm text-[#68706B] leading-relaxed pt-1">
                {currentStage.why}
              </p>
            </div>

            {/* 3. What was the trade-off? */}
            <div className="rounded-2xl border border-[#DDE2DE] bg-[#FFFFFF] p-5 shadow-xs space-y-2">
              <div className="flex items-center gap-2 pb-2 border-b border-[#DDE2DE]">
                <div className="w-6 h-6 rounded-md bg-[#FEF5E7] border border-[#FAD7A0] flex items-center justify-center text-[#B9770E]">
                  <Scale className="w-3.5 h-3.5" />
                </div>
                <span className="text-xs font-mono uppercase tracking-wider text-[#B9770E] font-bold">
                  What was the trade-off?
                </span>
              </div>
              <p className="text-xs sm:text-sm text-[#68706B] leading-relaxed pt-1">
                {currentStage.tradeOff}
              </p>
            </div>
          </div>

          {/* ==================================================
              STAGE-SPECIFIC INTERACTIVE VISUAL DEMO
              ================================================== */}
          <div className="rounded-2xl border border-[#DDE2DE] bg-[#FFFFFF] p-5 sm:p-6 shadow-xs space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-[#DDE2DE]">
              <span className="text-xs font-mono uppercase text-[#8A918D] font-bold">
                Stage {currentStage.stepNumber} Live Telemetry Inspection
              </span>
              <span className="text-[11px] font-mono text-[#007A52] font-semibold bg-[#E7F8F1] px-2 py-0.5 rounded border border-[#C9EBDC]">
                Active Phase Demonstration
              </span>
            </div>

            {/* Stage 1 Visual: DAG Pipeline View */}
            {currentStage.id === 'workflow' && (
              <div className="space-y-3">
                <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-2.5">
                  {[
                    { name: '1. Triage', tier: 'Small (Flash)', time: '190ms', carbon: '1.4g', isCrit: true },
                    { name: '2. Retrieval', tier: 'Vector Index', time: '320ms', carbon: '2.1g', isCrit: false },
                    { name: '3. Extraction', tier: 'Small (Flash)', time: '640ms', carbon: '6.8g', isCrit: true },
                    { name: '4. Audit Batch', tier: 'Solar Shifted', time: '420ms', carbon: '0.3g', isCrit: false },
                    { name: '5. Quality Gate', tier: 'Verifier', time: '240ms', carbon: '1.9g', isCrit: true },
                    { name: '6. Risk Synthesis', tier: 'Frontier Pro', time: '980ms', carbon: '12.4g', isCrit: true },
                  ].map((n, i) => (
                    <div key={i} className={`p-3 rounded-xl border ${n.isCrit ? 'border-[#00D98B] bg-[#E7F8F1]/40' : 'border-[#DDE2DE] bg-[#F7F8F5]'}`}>
                      <div className="text-xs font-bold text-[#0A0D0C] truncate">{n.name}</div>
                      <div className="text-[11px] font-mono text-[#007A52] font-semibold mt-0.5">{n.tier}</div>
                      <div className="text-[10px] font-mono text-[#8A918D] mt-2 flex justify-between">
                        <span>{n.time}</span>
                        <span>{n.carbon}</span>
                      </div>
                    </div>
                  ))}
                </div>
                <div className="p-3 rounded-xl bg-[#F7F8F5] border border-[#DDE2DE] text-xs text-[#68706B] flex items-center justify-between">
                  <span>Critical Path: <strong>Triage → Extraction → Quality Gate → Synthesis</strong></span>
                  <span className="font-mono font-bold text-[#0A0D0C]">Wall Clock Time: 1,520 ms</span>
                </div>
              </div>
            )}

            {/* Stage 2 Visual: Model Selection (Flash vs Pro) */}
            {currentStage.id === 'model_selection' && (
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="p-4 rounded-xl border border-[#00D98B] bg-[#E7F8F1]/50 space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-mono font-bold text-[#007A52] uppercase">Assigned Model</span>
                    <span className="px-2 py-0.5 text-[10px] font-mono font-bold rounded bg-[#00D98B] text-white">Selected</span>
                  </div>
                  <h4 className="text-sm font-bold text-[#0A0D0C]">Gemini 2.5 Flash (Small Tier)</h4>
                  <p className="text-xs text-[#68706B]">
                    High throughput, sub-200ms TTFT. Ideal for classification, schema enforcement, and table extraction.
                  </p>
                  <div className="pt-2 border-t border-[#C9EBDC] grid grid-cols-3 text-center text-xs font-mono">
                    <div>
                      <span className="text-[10px] text-[#8A918D] block">Carbon</span>
                      <span className="font-bold text-[#007A52]">1.4 gCO₂e</span>
                    </div>
                    <div>
                      <span className="text-[10px] text-[#8A918D] block">Latency</span>
                      <span className="font-bold text-[#0A0D0C]">190 ms</span>
                    </div>
                    <div>
                      <span className="text-[10px] text-[#8A918D] block">Confidence</span>
                      <span className="font-bold text-[#007A52]">96.0%</span>
                    </div>
                  </div>
                </div>

                <div className="p-4 rounded-xl border border-[#DDE2DE] bg-[#F7F8F5] space-y-2 opacity-80">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-mono font-bold text-[#8A918D] uppercase">Alternative Model</span>
                    <span className="px-2 py-0.5 text-[10px] font-mono rounded bg-[#DDE2DE] text-[#68706B]">Avoided</span>
                  </div>
                  <h4 className="text-sm font-bold text-[#0A0D0C]">Gemini 2.5 Pro (Frontier Tier)</h4>
                  <p className="text-xs text-[#68706B]">
                    Deep reasoning frontier model. Overkill for extraction triage; burns 3.4x more carbon for +1.2% delta.
                  </p>
                  <div className="pt-2 border-t border-[#DDE2DE] grid grid-cols-3 text-center text-xs font-mono">
                    <div>
                      <span className="text-[10px] text-[#8A918D] block">Carbon</span>
                      <span className="font-bold text-[#C0392B]">4.8 gCO₂e</span>
                    </div>
                    <div>
                      <span className="text-[10px] text-[#8A918D] block">Latency</span>
                      <span className="font-bold text-[#0A0D0C]">780 ms</span>
                    </div>
                    <div>
                      <span className="text-[10px] text-[#8A918D] block">Confidence</span>
                      <span className="font-bold text-[#0A0D0C]">97.2%</span>
                    </div>
                  </div>
                </div>
              </div>
            )}

            {/* Stage 3 Visual: Quality Gate Inspection */}
            {currentStage.id === 'quality_gate' && (
              <div className="space-y-3">
                <div className="p-4 rounded-xl border border-[#DDE2DE] bg-[#F7F8F5] space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-bold text-[#0A0D0C]">Quality Verification Gate Status</span>
                    <span className="text-xs font-mono font-bold text-[#007A52] bg-[#E7F8F1] px-2 py-0.5 rounded border border-[#C9EBDC]">
                      Target Threshold: 90.0%
                    </span>
                  </div>
                  <div className="space-y-2">
                    <div className="flex items-center justify-between text-xs">
                      <span className="text-[#0A0D0C] flex items-center gap-1.5">
                        <CheckCircle2 className="w-3.5 h-3.5 text-[#007A52]" />
                        <span>Clauses 1–13 (Standard Terms, Termination, Governing Law)</span>
                      </span>
                      <span className="font-mono font-bold text-[#007A52]">94.2% Confidence (Passed)</span>
                    </div>
                    <div className="flex items-center justify-between text-xs p-2 rounded-lg bg-[#FDEDEC] border border-[#F5B7B1]">
                      <span className="text-[#C0392B] flex items-center gap-1.5 font-semibold">
                        <AlertCircle className="w-3.5 h-3.5 text-[#C0392B]" />
                        <span>Clause #14 (Uncapped Cross-Border Indemnity)</span>
                      </span>
                      <span className="font-mono font-bold text-[#C0392B]">88.4% → Escalated to Gemini Pro</span>
                    </div>
                  </div>
                </div>
                <p className="text-xs text-[#68706B] italic">
                  Result: 90% of prompt tokens stayed on low-carbon small models; only the ambiguous clause triggered frontier escalation.
                </p>
              </div>
            )}

            {/* Stage 4 Visual: Carbon Budget Meter */}
            {currentStage.id === 'carbon_budget' && (
              <div className="p-4 rounded-xl border border-[#DDE2DE] bg-[#F7F8F5] space-y-3">
                <div className="flex items-center justify-between">
                  <div>
                    <span className="text-xs font-bold text-[#0A0D0C] block">Pipeline Carbon Budget</span>
                    <span className="text-[11px] text-[#68706B]">Allocated Ceiling: 50.0 gCO₂e</span>
                  </div>
                  <span className="text-xs font-mono font-bold text-[#007A52] bg-[#E7F8F1] px-2.5 py-1 rounded border border-[#C9EBDC]">
                    FEASIBLE &amp; SAFE (49.8% Consumed)
                  </span>
                </div>
                {/* Progress bar */}
                <div className="space-y-1">
                  <div className="h-3 w-full bg-[#DDE2DE] rounded-full overflow-hidden">
                    <div className="h-full bg-[#007A52] rounded-full" style={{ width: '49.8%' }} />
                  </div>
                  <div className="flex justify-between text-[11px] font-mono text-[#8A918D]">
                    <span>Consumed: 24.9 gCO₂e</span>
                    <span className="text-[#007A52] font-semibold">Remaining Headroom: 25.1 gCO₂e</span>
                    <span>Cap: 50.0 gCO₂e</span>
                  </div>
                </div>
              </div>
            )}

            {/* Stage 5 Visual: Deadline Slack Timeline */}
            {currentStage.id === 'deadline_slack' && (
              <div className="p-4 rounded-xl border border-[#DDE2DE] bg-[#F7F8F5] space-y-3">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold text-[#0A0D0C]">Critical Path vs. Hard SLA Deadline</span>
                  <span className="text-xs font-mono font-bold text-[#007A52] bg-[#E7F8F1] px-2.5 py-1 rounded border border-[#C9EBDC]">
                    +980 ms Slack Buffer
                  </span>
                </div>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-1">
                  <div className="p-3 rounded-xl bg-[#FFFFFF] border border-[#DDE2DE] space-y-1">
                    <span className="text-[10px] font-mono text-[#8A918D] uppercase block">Critical Path Delivery</span>
                    <span className="text-base font-bold font-mono text-[#0A0D0C]">1,520 ms</span>
                    <span className="text-[11px] text-[#007A52] block font-semibold">Under 2,500 ms SLA</span>
                  </div>
                  <div className="p-3 rounded-xl bg-[#FFFFFF] border border-[#C9EBDC] space-y-1">
                    <span className="text-[10px] font-mono text-[#007A52] uppercase block font-semibold">Task 4 Solar Window Deferral</span>
                    <span className="text-base font-bold font-mono text-[#007A52]">+45s Delay</span>
                    <span className="text-[11px] text-[#68706B] block">Grid rate drops: 340 → 180 gCO₂/kWh</span>
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>
      ) : (
        /* ==================================================
            FINAL SCREEN (STAGE 6):
            - Workflow Complete
            - Carbon
            - Time
            - Quality
            - Budget
            - Slack
            - Compare with Baseline
            ================================================== */
        <div className="space-y-6">
          {/* Workflow Complete Banner */}
          <div className="rounded-2xl border border-[#C9EBDC] bg-[#E7F8F1]/60 p-6 sm:p-8 text-center space-y-3 shadow-xs">
            <div className="w-12 h-12 rounded-2xl bg-[#007A52] text-white flex items-center justify-center mx-auto shadow-xs">
              <CheckCircle2 className="w-6 h-6" />
            </div>
            <div>
              <span className="text-xs font-mono uppercase tracking-wider text-[#007A52] font-bold block">
                Guided Demonstration Finished
              </span>
              <h2 className="text-2xl sm:text-3xl font-bold text-[#0A0D0C] tracking-tight mt-1">
                Workflow Complete
              </h2>
              <p className="text-xs sm:text-sm text-[#68706B] max-w-xl mx-auto mt-1 leading-relaxed">
                CarbonPilot has successfully optimized the full DAG execution lifecycle. Every constraint—carbon ceiling, deadline SLA, and quality threshold—was strictly satisfied.
              </p>
            </div>
          </div>

          {/* ==================================================
              THE 5 MANDATORY METRICS:
              Carbon
              Time
              Quality
              Budget
              Slack
              ================================================== */}
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-3">
            {/* 1. Carbon */}
            <div className="rounded-xl border border-[#DDE2DE] bg-[#FFFFFF] p-4 shadow-xs space-y-1">
              <div className="flex items-center gap-1.5 text-xs font-semibold text-[#0A0D0C]">
                <Leaf className="w-3.5 h-3.5 text-[#007A52]" />
                <span>Carbon</span>
              </div>
              <div className="text-xl sm:text-2xl font-bold font-mono text-[#007A52] pt-1">
                24.9 <span className="text-xs font-normal text-[#68706B]">gCO₂e</span>
              </div>
              <span className="text-[11px] font-mono text-[#007A52] block font-semibold">
                -59.6% vs. Baseline
              </span>
            </div>

            {/* 2. Time */}
            <div className="rounded-xl border border-[#DDE2DE] bg-[#FFFFFF] p-4 shadow-xs space-y-1">
              <div className="flex items-center gap-1.5 text-xs font-semibold text-[#0A0D0C]">
                <Clock className="w-3.5 h-3.5 text-[#B9770E]" />
                <span>Time</span>
              </div>
              <div className="text-xl sm:text-2xl font-bold font-mono text-[#0A0D0C] pt-1">
                1,520 <span className="text-xs font-normal text-[#68706B]">ms</span>
              </div>
              <span className="text-[11px] font-mono text-[#007A52] block font-semibold">
                -55.9% faster
              </span>
            </div>

            {/* 3. Quality */}
            <div className="rounded-xl border border-[#DDE2DE] bg-[#FFFFFF] p-4 shadow-xs space-y-1">
              <div className="flex items-center gap-1.5 text-xs font-semibold text-[#0A0D0C]">
                <ShieldCheck className="w-3.5 h-3.5 text-[#007A52]" />
                <span>Quality</span>
              </div>
              <div className="text-xl sm:text-2xl font-bold font-mono text-[#0A0D0C] pt-1">
                94.6%
              </div>
              <span className="text-[11px] font-mono text-[#68706B] block">
                99.5% parity preserved
              </span>
            </div>

            {/* 4. Budget */}
            <div className="rounded-xl border border-[#DDE2DE] bg-[#FFFFFF] p-4 shadow-xs space-y-1">
              <div className="flex items-center gap-1.5 text-xs font-semibold text-[#0A0D0C]">
                <Leaf className="w-3.5 h-3.5 text-[#007A52]" />
                <span>Budget</span>
              </div>
              <div className="text-xl sm:text-2xl font-bold font-mono text-[#0A0D0C] pt-1">
                50.0 <span className="text-xs font-normal text-[#68706B]">g Cap</span>
              </div>
              <span className="text-[11px] font-mono text-[#007A52] block font-semibold">
                25.1g Headroom
              </span>
            </div>

            {/* 5. Slack */}
            <div className="rounded-xl border border-[#DDE2DE] bg-[#FFFFFF] p-4 shadow-xs space-y-1">
              <div className="flex items-center gap-1.5 text-xs font-semibold text-[#0A0D0C]">
                <Clock className="w-3.5 h-3.5 text-[#007A52]" />
                <span>Slack</span>
              </div>
              <div className="text-xl sm:text-2xl font-bold font-mono text-[#007A52] pt-1">
                +980 <span className="text-xs font-normal text-[#68706B]">ms</span>
              </div>
              <span className="text-[11px] font-mono text-[#007A52] block font-semibold">
                Zero SLA breaches
              </span>
            </div>
          </div>

          {/* ==================================================
              COMPARE WITH BASELINE ACTION CALLOUT
              ================================================== */}
          <div className="rounded-2xl border border-[#DDE2DE] bg-[#FFFFFF] p-6 sm:p-7 shadow-xs space-y-4">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div className="space-y-1">
                <span className="text-xs font-mono uppercase tracking-wider text-[#007A52] font-bold block">
                  Next Step: Empirical Validation
                </span>
                <h3 className="text-base sm:text-lg font-bold text-[#0A0D0C]">
                  Compare with Unoptimized Baseline
                </h3>
                <p className="text-xs sm:text-sm text-[#68706B] max-w-xl">
                  Inspect the head-to-head metrics comparing CarbonPilot against standard static frontier model pipelines across all 7 benchmark dimensions.
                </p>
              </div>

              <div className="flex items-center gap-3 shrink-0">
                <button
                  onClick={handleRestart}
                  className="px-4 py-2.5 rounded-xl border border-[#DDE2DE] text-xs font-semibold text-[#0A0D0C] hover:bg-[#F7F8F5] transition-colors cursor-pointer flex items-center gap-1.5"
                >
                  <RotateCcw className="w-3.5 h-3.5 text-[#68706B]" />
                  <span>Restart Demo</span>
                </button>

                {onNavigateComparison && (
                  <button
                    onClick={onNavigateComparison}
                    className="px-5 py-2.5 rounded-xl bg-[#007A52] hover:bg-[#005F3F] text-white text-xs font-semibold shadow-xs transition-colors cursor-pointer flex items-center gap-2"
                  >
                    <Scale className="w-4 h-4 text-white" />
                    <span>Compare with Baseline</span>
                    <ArrowRight className="w-4 h-4 text-white" />
                  </button>
                )}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ==================================================
          BOTTOM DEMO CONTROLS:
          Next
          Back
          Restart Demo
          ================================================== */}
      <footer className="rounded-2xl border border-[#DDE2DE] bg-[#FFFFFF] p-4 sm:p-5 shadow-xs flex items-center justify-between gap-3">
        <button
          onClick={handleRestart}
          className="px-3.5 py-2 rounded-xl border border-[#DDE2DE] text-xs font-semibold text-[#68706B] hover:text-[#0A0D0C] hover:bg-[#F7F8F5] transition-colors cursor-pointer flex items-center gap-1.5"
        >
          <RotateCcw className="w-3.5 h-3.5" />
          <span>Restart Demo</span>
        </button>

        <div className="flex items-center gap-2.5">
          <button
            onClick={handleBack}
            disabled={isFirstStage}
            className={`px-4 py-2 rounded-xl border text-xs font-semibold transition-colors flex items-center gap-1.5 ${
              isFirstStage
                ? 'border-[#DDE2DE] text-[#8A918D] opacity-40 cursor-not-allowed bg-[#F7F8F5]'
                : 'border-[#DDE2DE] text-[#0A0D0C] hover:bg-[#F7F8F5] cursor-pointer'
            }`}
          >
            <ArrowLeft className="w-3.5 h-3.5" />
            <span>Back</span>
          </button>

          <button
            onClick={handleNext}
            className="px-5 py-2 rounded-xl bg-[#007A52] hover:bg-[#005F3F] text-white text-xs font-semibold shadow-xs transition-colors cursor-pointer flex items-center gap-2"
          >
            {isLastStage ? (
              <>
                <Scale className="w-3.5 h-3.5" />
                <span>Compare with Baseline</span>
              </>
            ) : (
              <>
                <span>Next</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </>
            )}
          </button>
        </div>
      </footer>
    </div>
  );
};
