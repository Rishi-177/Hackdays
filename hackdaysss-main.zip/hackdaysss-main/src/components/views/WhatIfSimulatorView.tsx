/**
 * CarbonPilot — What-If Decision Engine (Step 5)
 * Allows users to adjust constraints (Carbon Sensitivity, Latency Priority,
 * Accuracy Requirement, Cost Sensitivity, Carbon Budget, Deadline)
 * and dynamically re-optimizes the entire workflow DAG with instant
 * CURRENT PLAN vs NEW PLAN metrics and explicit "What changed?" & "Why?" causal analysis.
 *
 * All values are clearly marked as simulated/demo values.
 */

import React, { useState, useMemo } from 'react';
import {
  Sliders,
  Leaf,
  Clock,
  ShieldCheck,
  DollarSign,
  AlertOctagon,
  ArrowRight,
  TrendingDown,
  TrendingUp,
  Zap,
  RotateCcw,
  CheckCircle2,
  XCircle,
  Sparkles,
  Layers,
  Cpu,
  Sun,
  Flame,
  Info,
  GitMerge,
  ChevronRight,
} from 'lucide-react';

export interface WhatIfConstraints {
  carbonSensitivity: number; // 0 - 100%
  latencyPriority: number; // 0 - 100%
  accuracyRequirement: number; // 75.0 - 99.0%
  costSensitivity: number; // 0 - 100%
  carbonBudget: number; // 15.0 - 80.0 gCO₂e
  deadline: number; // 1,000 - 4,000 ms
}

export type PresetType = 'balanced' | 'green' | 'speed' | 'accuracy' | 'tight_budget';

interface PresetConfig {
  id: PresetType;
  name: string;
  badge: string;
  description: string;
  constraints: WhatIfConstraints;
}

const PRESETS: PresetConfig[] = [
  {
    id: 'balanced',
    name: 'Balanced',
    badge: 'Enterprise Default',
    description: 'Balanced trade-offs across carbon efficiency, SLA speed, and legal accuracy.',
    constraints: {
      carbonSensitivity: 50,
      latencyPriority: 50,
      accuracyRequirement: 88.0,
      costSensitivity: 50,
      carbonBudget: 50.0,
      deadline: 2500,
    },
  },
  {
    id: 'green',
    name: 'Green Priority',
    badge: 'Max Solar & Right-Sizing',
    description: 'Prioritizes lowest possible emissions. Right-sizes all nodes to small models and defers parallel tasks into solar peaks.',
    constraints: {
      carbonSensitivity: 95,
      latencyPriority: 25,
      accuracyRequirement: 86.0,
      costSensitivity: 70,
      carbonBudget: 28.0,
      deadline: 3500,
    },
  },
  {
    id: 'speed',
    name: 'Speed Priority',
    badge: 'Instant SLA Fast-Track',
    description: 'Zero deferrals. Runs parallel high-speed tasks immediately on local grid to minimize wall-clock delivery time.',
    constraints: {
      carbonSensitivity: 20,
      latencyPriority: 95,
      accuracyRequirement: 88.0,
      costSensitivity: 30,
      carbonBudget: 65.0,
      deadline: 1400,
    },
  },
  {
    id: 'accuracy',
    name: 'Accuracy Priority',
    badge: 'Zero-Tolerance Audit',
    description: 'Raises quality threshold to 97%. Deploys frontier Gemini 2.5 Pro models across extraction, validation, and synthesis.',
    constraints: {
      carbonSensitivity: 35,
      latencyPriority: 40,
      accuracyRequirement: 97.0,
      costSensitivity: 25,
      carbonBudget: 60.0,
      deadline: 3000,
    },
  },
  {
    id: 'tight_budget',
    name: 'Tight Carbon Budget',
    badge: 'Strict 20g Ceiling',
    description: 'Enforces hard 20.0 gCO₂e ceiling. Automatically rejects expensive frontier synthesis and downgrades models to prevent budget breach.',
    constraints: {
      carbonSensitivity: 85,
      latencyPriority: 35,
      accuracyRequirement: 85.0,
      costSensitivity: 90,
      carbonBudget: 20.0,
      deadline: 2800,
    },
  },
];

// Baseline Current Plan Metrics (Standard CarbonPilot execution)
const CURRENT_PLAN_METRICS = {
  carbonGrams: 24.9,
  workflowTimeMs: 1520,
  qualityScore: 94.6,
  costUsd: 0.0058,
  budgetCeilingGrams: 50.0,
  slackMs: 980,
  deadlineMs: 2500,
};

export type SimulatedNodeStatus = 'normal' | 'rightsized' | 'solar_delayed' | 'escalated' | 'downgraded' | 'fast_tracked';

export interface SimulatedNode {
  id: string;
  name: string;
  stage: number;
  model: string;
  tier: 'small' | 'medium' | 'frontier';
  carbonGrams: number;
  latencyMs: number;
  quality: number;
  statusText: string;
  statusType: SimulatedNodeStatus;
  isCriticalPath: boolean;
  whyAdapted: string;
}

export interface CausalChangeItem {
  id: string;
  whatChanged: string;
  why: string;
  category: 'model' | 'scheduling' | 'escalation' | 'budget';
}

export const WhatIfSimulatorView: React.FC = () => {
  // Active Constraints State
  const [constraints, setConstraints] = useState<WhatIfConstraints>(PRESETS[0].constraints);
  const [activePreset, setActivePreset] = useState<PresetType | 'custom'>('balanced');
  const [selectedNodeId, setSelectedNodeId] = useState<string | null>('node-3');
  const [viewMode, setViewMode] = useState<'new' | 'compare'>('new');

  // Handle Preset Selection
  const applyPreset = (preset: PresetConfig) => {
    setActivePreset(preset.id);
    setConstraints({ ...preset.constraints });
  };

  // Handle Individual Slider Updates
  const updateConstraint = (key: keyof WhatIfConstraints, value: number) => {
    setConstraints((prev) => ({ ...prev, [key]: value }));
    setActivePreset('custom');
  };

  // Re-optimize the Entire Workflow DAG dynamically
  const { newPlanMetrics, simulatedNodes, causalChanges } = useMemo(() => {
    const {
      carbonSensitivity,
      latencyPriority,
      accuracyRequirement,
      costSensitivity,
      carbonBudget,
      deadline,
    } = constraints;

    const changes: CausalChangeItem[] = [];

    // -------------------------------------------------------------
    // TASK 1: Document Analysis (Stage 1)
    // -------------------------------------------------------------
    let t1Model = 'Gemini 2.5 Flash (Small)';
    let t1Tier: 'small' | 'medium' | 'frontier' = 'small';
    let t1Carbon = 1.4;
    let t1Latency = 190;
    let t1Quality = 96.0;
    let t1Status: SimulatedNodeStatus = 'normal';
    let t1StatusText = 'Right-Sized (Small)';
    let t1Why = 'Predicted confidence (96.0%) satisfies requirement without expensive frontier model.';

    if (accuracyRequirement > 97.0 && carbonSensitivity < 40) {
      t1Model = 'Gemini 2.5 Pro (Frontier)';
      t1Tier = 'frontier';
      t1Carbon = 3.8;
      t1Latency = 310;
      t1Quality = 98.6;
      t1Status = 'escalated';
      t1StatusText = 'Frontier Tier';
      t1Why = 'Upgraded to frontier model because accuracy requirement was pushed to ultra-strict 97%+.';
      changes.push({
        id: 'c-t1',
        whatChanged: 'Task 1 (Doc Analysis): Small Model → Frontier Model',
        why: 'Accuracy requirement increased to ' + accuracyRequirement.toFixed(1) + '%. Deployed frontier model for zero-tolerance triage.',
        category: 'escalation',
      });
    }

    // -------------------------------------------------------------
    // TASK 2: Contextual Policy Retrieval (Stage 2 Parallel)
    // -------------------------------------------------------------
    let t2Model = 'Flash Ranker (Vector Small)';
    let t2Tier: 'small' | 'medium' | 'frontier' = 'small';
    let t2Carbon = 2.1;
    let t2Latency = 320;
    let t2Quality = 92.5;
    let t2Status: SimulatedNodeStatus = 'normal';
    let t2StatusText = 'Vector Index Filtered';
    let t2Why = 'Pre-filters 14k policy chunks to reduce downstream prompt context tokens.';

    if (latencyPriority > 80) {
      t2Model = 'Instant Memory Cache';
      t2Carbon = 1.0;
      t2Latency = 120;
      t2Quality = 91.8;
      t2Status = 'fast_tracked';
      t2StatusText = 'Instant In-Memory Cache';
      t2Why = 'Fast-tracked via pre-computed in-memory cache to satisfy high latency priority.';
      changes.push({
        id: 'c-t2',
        whatChanged: 'Task 2 (Policy Retrieval): Vector Retrieval → In-Memory Cache',
        why: 'Latency priority set to ' + latencyPriority + '%. Switched to cached index reducing stage latency by -200ms.',
        category: 'scheduling',
      });
    }

    // -------------------------------------------------------------
    // TASK 3: Multimodal Contract Extraction (Stage 2 Critical Path)
    // -------------------------------------------------------------
    let t3Model = 'Gemini 2.5 Flash (Small)';
    let t3Tier: 'small' | 'medium' | 'frontier' = 'small';
    let t3Carbon = 6.8;
    let t3Latency = 640;
    let t3Quality = 89.2;
    let t3Status: SimulatedNodeStatus = 'normal';
    let t3StatusText = 'Flash Multimodal';
    let t3Why = 'Small model layout extraction satisfies baseline quality (89.2%) saving 65% emissions.';

    if (accuracyRequirement > 93.0) {
      t3Model = 'Gemini 2.5 Pro (Frontier)';
      t3Tier = 'frontier';
      t3Carbon = 15.2;
      t3Latency = 1040;
      t3Quality = 98.1;
      t3Status = 'escalated';
      t3StatusText = 'Frontier Pro Model';
      t3Why = 'Escalated to Gemini Pro because accuracy requirement exceeds small model capacity.';
      changes.push({
        id: 'c-t3-up',
        whatChanged: 'Task 3 (Contract Extraction): Small Model → Large Frontier Model',
        why: 'Accuracy requirement (' + accuracyRequirement.toFixed(1) + '%) exceeds Small Model confidence (89.2%). Escalated to eliminate risk.',
        category: 'escalation',
      });
    } else if (carbonSensitivity > 75 || carbonBudget < 28) {
      t3Model = 'Quantized Flash (Small)';
      t3Tier = 'small';
      t3Carbon = 3.6;
      t3Latency = 540;
      t3Quality = 86.8;
      t3Status = 'rightsized';
      t3StatusText = 'Quantized Flash';
      t3Why = 'Selected lightweight quantized small model to stay strictly within tight carbon ceiling.';
      changes.push({
        id: 'c-t3-down',
        whatChanged: 'Task 3 (Contract Extraction): Flash → Quantized Small Model',
        why: 'Carbon sensitivity increased (' + carbonSensitivity + '%). Switched to lightweight model because quality requirement (' + accuracyRequirement.toFixed(1) + '%) remains satisfied.',
        category: 'model',
      });
    }

    // -------------------------------------------------------------
    // TASK 4: Compliance Audit Batch (Stage 2 Parallel Deferrable)
    // -------------------------------------------------------------
    let t4Model = 'Batch Engine (Solar Shifted)';
    let t4Tier: 'small' | 'medium' | 'frontier' = 'small';
    let t4Carbon = 0.3;
    let t4Latency = 420;
    let t4Quality = 99.0;
    let t4Status: SimulatedNodeStatus = 'solar_delayed';
    let t4StatusText = 'Deferred +45s (Solar Peak)';
    let t4Why = 'Has +1,400ms slack; deferred into clean solar window dropping grid carbon from 340 to 180 gCO₂/kWh.';

    if (latencyPriority > 75 || deadline < 1600) {
      t4Model = 'Instant Engine (No Delay)';
      t4Carbon = 1.9;
      t4Latency = 340;
      t4Status = 'fast_tracked';
      t4StatusText = 'Immediate Execution (No Delay)';
      t4Why = 'Deferral eliminated: immediate execution required to meet tight deadline constraint.';
      changes.push({
        id: 'c-t4-instant',
        whatChanged: 'Task 4 (Audit Batch): Solar Deferral (+45s) → Immediate Execution (0s)',
        why: 'Latency priority increased to ' + latencyPriority + '% and deadline set to ' + deadline + 'ms. Delay eliminated to avoid critical path contention.',
        category: 'scheduling',
      });
    } else if (carbonSensitivity > 80) {
      t4Status = 'solar_delayed';
      t4Carbon = 0.18;
      t4StatusText = 'Max Clean Deferral (+60s)';
      t4Why = 'Maximum solar window deferral applied to capture lowest marginal grid emissions.';
      changes.push({
        id: 'c-t4-solar',
        whatChanged: 'Task 4 (Audit Batch): Extended Deferral to 60s Solar Window',
        why: 'High carbon sensitivity (' + carbonSensitivity + '%) triggered aggressive clean grid timing.',
        category: 'scheduling',
      });
    }

    // -------------------------------------------------------------
    // TASK 5: Quality Gate & Hallucination Guard (Stage 3 Gate)
    // -------------------------------------------------------------
    let t5Model = 'Cross-Verifier Guard';
    let t5Tier: 'small' | 'medium' | 'frontier' = 'small';
    let t5Carbon = 1.9;
    let t5Latency = 240;
    let t5Quality = 94.2;
    let t5Status: SimulatedNodeStatus = 'normal';
    let t5StatusText = 'Quality Gate Verified';
    let t5Why = 'Fast verification pass ensures factual grounding before expensive synthesis.';

    // -------------------------------------------------------------
    // TASK 6: High-Risk Clause Escalation (Stage 3 Parallel)
    // -------------------------------------------------------------
    let t6Model = 'Gemini 2.5 Pro (Frontier)';
    let t6Tier: 'small' | 'medium' | 'frontier' = 'frontier';
    let t6Carbon = 4.2;
    let t6Latency = 510;
    let t6Quality = 98.5;
    let t6Status: SimulatedNodeStatus = 'escalated';
    let t6StatusText = 'Selective Frontier Escalation';
    let t6Why = 'Only ambiguous clause #14 escalated to frontier tier, saving whole-prompt overhead.';

    if (carbonBudget < 25.0 || (carbonSensitivity > 85 && accuracyRequirement <= 86.0)) {
      t6Model = 'Deterministic Rule Verifier';
      t6Tier = 'small';
      t6Carbon = 0.9;
      t6Latency = 180;
      t6Quality = 88.0;
      t6Status = 'downgraded';
      t6StatusText = 'Deterministic Fallback (Small)';
      t6Why = 'Frontier escalation rejected to prevent breaching strict carbon budget ceiling.';
      changes.push({
        id: 'c-t6',
        whatChanged: 'Task 6 (Risk Escalation): Frontier Model → Deterministic Rule Verifier',
        why: 'Tighter carbon budget (' + carbonBudget.toFixed(1) + ' gCO₂e). Rejected expensive frontier option; downgraded to rules engine.',
        category: 'budget',
      });
    } else if (accuracyRequirement > 95.0) {
      t6Carbon = 5.8;
      t6Latency = 680;
      t6Quality = 99.4;
      t6Status = 'escalated';
      t6StatusText = 'Deep Multi-Turn Frontier Escalation';
      t6Why = 'Multi-turn cross-jurisdiction frontier reasoning invoked for maximum audit certification.';
    }

    // -------------------------------------------------------------
    // TASK 7: Risk Synthesis & Remediation (Stage 4 Critical Path)
    // -------------------------------------------------------------
    let t7Model = 'Gemini 2.5 Pro (Frontier)';
    let t7Tier: 'small' | 'medium' | 'frontier' = 'frontier';
    let t7Carbon = 12.4;
    let t7Latency = 980;
    let t7Quality = 97.4;
    let t7Status: SimulatedNodeStatus = 'normal';
    let t7StatusText = 'Frontier Synthesis';
    let t7Why = 'Deep contextual synthesis for executive report, safe within default 50g budget.';

    // Check if carbon budget or sensitivity forces downgrade of Task 7
    if (carbonBudget < 25.0 || (carbonSensitivity > 80 && costSensitivity > 75)) {
      t7Model = 'Gemini 2.5 Flash (Small)';
      t7Tier = 'small';
      t7Carbon = 3.2;
      t7Latency = 420;
      t7Quality = 91.5;
      t7Status = 'downgraded';
      t7StatusText = 'Flash Small Synthesis';
      t7Why = 'Downgraded from frontier to small model to prevent violating strict carbon budget ceiling.';
      changes.push({
        id: 'c-t7-down',
        whatChanged: 'Task 7 (Risk Synthesis): Frontier Model → Small Model (Gemini Flash)',
        why: 'Tighter carbon budget (' + carbonBudget.toFixed(1) + ' gCO₂e). Synthesis represents largest single-node spend; downgraded to small model to guarantee budget compliance.',
        category: 'budget',
      });
    } else if (latencyPriority > 85) {
      t7Latency = 610;
      t7Carbon = 8.8;
      t7Quality = 95.2;
      t7Status = 'fast_tracked';
      t7StatusText = 'Streamlined Fast Frontier';
      t7Why = 'Reduced token generation budget to compress synthesis latency for strict deadline.';
      changes.push({
        id: 'c-t7-fast',
        whatChanged: 'Task 7 (Risk Synthesis): Compressed Token Depth for Speed',
        why: 'High latency priority (' + latencyPriority + '%). Optimized generation tokens to compress latency by -370ms.',
        category: 'scheduling',
      });
    } else if (accuracyRequirement > 96.0) {
      t7Carbon = 16.5;
      t7Latency = 1260;
      t7Quality = 99.1;
      t7Status = 'escalated';
      t7StatusText = 'Ultra Frontier Multi-Pass';
      t7Why = 'Deep multi-agent review loop deployed to satisfy high accuracy threshold.';
      changes.push({
        id: 'c-t7-acc',
        whatChanged: 'Task 7 (Risk Synthesis): Pro → Ultra Multi-Pass Synthesis',
        why: 'Accuracy requirement increased to ' + accuracyRequirement.toFixed(1) + '%. Invoked exhaustive synthesis for zero legal ambiguity.',
        category: 'escalation',
      });
    }

    // -------------------------------------------------------------
    // TASK 8: Audit Ledger & Dispatch (Stage 5 Deterministic)
    // -------------------------------------------------------------
    const t8Model = 'Deterministic Action Engine';
    const t8Tier: 'small' | 'medium' | 'frontier' = 'small';
    const t8Carbon = 0.3;
    const t8Latency = 110;
    const t8Quality = 100.0;
    const t8Status = 'normal' as const;
    const t8StatusText = 'Deterministic Code Execution';
    const t8Why = 'Cryptographic signing executed with deterministic code; 0 LLM token overhead.';

    // Assemble simulated nodes
    const nodes: SimulatedNode[] = [
      {
        id: 'node-1',
        name: 'Task 1: Document Analysis',
        stage: 1,
        model: t1Model,
        tier: t1Tier,
        carbonGrams: t1Carbon,
        latencyMs: t1Latency,
        quality: t1Quality,
        statusType: t1Status,
        statusText: t1StatusText,
        isCriticalPath: true,
        whyAdapted: t1Why,
      },
      {
        id: 'node-2',
        name: 'Task 2: Policy Retrieval',
        stage: 2,
        model: t2Model,
        tier: t2Tier,
        carbonGrams: t2Carbon,
        latencyMs: t2Latency,
        quality: t2Quality,
        statusType: t2Status,
        statusText: t2StatusText,
        isCriticalPath: false,
        whyAdapted: t2Why,
      },
      {
        id: 'node-3',
        name: 'Task 3: Contract Extraction',
        stage: 2,
        model: t3Model,
        tier: t3Tier,
        carbonGrams: t3Carbon,
        latencyMs: t3Latency,
        quality: t3Quality,
        statusType: t3Status,
        statusText: t3StatusText,
        isCriticalPath: true,
        whyAdapted: t3Why,
      },
      {
        id: 'node-4',
        name: 'Task 4: Compliance Batch',
        stage: 2,
        model: t4Model,
        tier: t4Tier,
        carbonGrams: t4Carbon,
        latencyMs: t4Latency,
        quality: t4Quality,
        statusType: t4Status,
        statusText: t4StatusText,
        isCriticalPath: false,
        whyAdapted: t4Why,
      },
      {
        id: 'node-5',
        name: 'Task 5: Quality Gate',
        stage: 3,
        model: t5Model,
        tier: t5Tier,
        carbonGrams: t5Carbon,
        latencyMs: t5Latency,
        quality: t5Quality,
        statusType: t5Status,
        statusText: t5StatusText,
        isCriticalPath: true,
        whyAdapted: t5Why,
      },
      {
        id: 'node-6',
        name: 'Task 6: High-Risk Clause',
        stage: 3,
        model: t6Model,
        tier: t6Tier,
        carbonGrams: t6Carbon,
        latencyMs: t6Latency,
        quality: t6Quality,
        statusType: t6Status,
        statusText: t6StatusText,
        isCriticalPath: false,
        whyAdapted: t6Why,
      },
      {
        id: 'node-7',
        name: 'Task 7: Risk Synthesis',
        stage: 4,
        model: t7Model,
        tier: t7Tier,
        carbonGrams: t7Carbon,
        latencyMs: t7Latency,
        quality: t7Quality,
        statusType: t7Status,
        statusText: t7StatusText,
        isCriticalPath: true,
        whyAdapted: t7Why,
      },
      {
        id: 'node-8',
        name: 'Task 8: Audit Ledger',
        stage: 5,
        model: t8Model,
        tier: t8Tier,
        carbonGrams: t8Carbon,
        latencyMs: t8Latency,
        quality: t8Quality,
        statusType: t8Status,
        statusText: t8StatusText,
        isCriticalPath: true,
        whyAdapted: t8Why,
      },
    ];

    // Compute Totals
    const totalCarbon = Number(
      nodes.reduce((acc, n) => acc + n.carbonGrams, 0).toFixed(1)
    );

    // Critical Path: Stage 1 + Stage 2 Extraction + Stage 3 Gate + Stage 4 Synthesis + Stage 5 Ledger
    const criticalPathTime =
      t1Latency + t3Latency + t5Latency + t7Latency + t8Latency;

    // Quality: weighted average of generative & verification stages
    const totalQuality = Number(
      (
        (t1Quality * 0.15 +
          t2Quality * 0.1 +
          t3Quality * 0.3 +
          t5Quality * 0.1 +
          t6Quality * 0.1 +
          t7Quality * 0.25)
      ).toFixed(1)
    );

    // Cost estimation
    const totalCost = Number(
      (
        nodes.reduce((acc, n) => {
          if (n.tier === 'frontier') return acc + 0.0035;
          if (n.tier === 'medium') return acc + 0.0012;
          return acc + 0.0003;
        }, 0)
      ).toFixed(4)
    );

    const slack = deadline - criticalPathTime;

    // Fallback change notice if empty
    if (changes.length === 0) {
      changes.push({
        id: 'c-default',
        whatChanged: 'Workflow parameters balanced across small and frontier tiers',
        why: 'Current constraints align with the default enterprise baseline; all quality thresholds and budget ceilings satisfied.',
        category: 'model',
      });
    }

    return {
      newPlanMetrics: {
        carbonGrams: totalCarbon,
        workflowTimeMs: criticalPathTime,
        qualityScore: totalQuality,
        costUsd: totalCost,
        budgetCeilingGrams: carbonBudget,
        slackMs: slack,
        deadlineMs: deadline,
      },
      simulatedNodes: nodes,
      causalChanges: changes,
    };
  }, [constraints]);

  // Selected node details
  const activeNode = simulatedNodes.find((n) => n.id === selectedNodeId) || simulatedNodes[2];

  // Metric Deltas
  const carbonDelta = Number((newPlanMetrics.carbonGrams - CURRENT_PLAN_METRICS.carbonGrams).toFixed(1));
  const timeDelta = newPlanMetrics.workflowTimeMs - CURRENT_PLAN_METRICS.workflowTimeMs;
  const qualityDelta = Number((newPlanMetrics.qualityScore - CURRENT_PLAN_METRICS.qualityScore).toFixed(1));
  const costDelta = Number((newPlanMetrics.costUsd - CURRENT_PLAN_METRICS.costUsd).toFixed(4));
  const slackDelta = newPlanMetrics.slackMs - CURRENT_PLAN_METRICS.slackMs;
  const isBudgetExceeded = newPlanMetrics.carbonGrams > newPlanMetrics.budgetCeilingGrams;
  const isDeadlineBreached = newPlanMetrics.slackMs < 0;

  return (
    <div className="max-w-7xl mx-auto space-y-6 pb-14">
      {/* Header */}
      <header className="pb-4 border-b border-[#DDE2DE]">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 mb-1">
          <div className="flex items-center gap-2">
            <div className="w-6 h-6 rounded-md bg-[#E7F8F1] border border-[#C9EBDC] flex items-center justify-center text-[#007A52]">
              <Sliders className="w-3.5 h-3.5" />
            </div>
            <span className="text-[11px] font-mono text-[#007A52] font-semibold tracking-wide uppercase">
              Decision Engine
            </span>
          </div>

          {/* SIMULATED / DEMO BADGE (MANDATORY) */}
          <div className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-[11px] font-mono font-bold bg-[#FEF5E7] text-[#B9770E] border border-[#FAD7A0] w-fit">
            <Sparkles className="w-3.5 h-3.5" />
            <span>Simulated / Demo Mode Active • Synthetic Telemetry</span>
          </div>
        </div>

        <h1 className="text-xl sm:text-2xl font-bold text-[#0A0D0C] tracking-tight">
          What-If Decision Engine
        </h1>
        <p className="text-xs sm:text-sm text-[#68706B] mt-1 max-w-3xl leading-relaxed">
          Change any operational constraint below. CarbonPilot instantly recalculates global dependencies, re-evaluates model right-sizing, adjusts clean solar deferrals, and generates an end-to-end re-optimized execution plan.
        </p>
      </header>

      {/* ==================================================
          PRESETS BAR:
          Balanced
          Green Priority
          Speed Priority
          Accuracy Priority
          Tight Carbon Budget
          ================================================== */}
      <section className="rounded-xl border border-[#DDE2DE] bg-[#FFFFFF] p-4 shadow-xs space-y-3">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
          <div>
            <span className="text-xs font-bold text-[#0A0D0C] block">Interactive Strategy Presets</span>
            <span className="text-[11px] text-[#68706B]">Select a preset to demonstrate visibly distinct workflow configurations</span>
          </div>
          {activePreset === 'custom' && (
            <span className="text-xs font-mono text-[#007A52] font-semibold bg-[#E7F8F1] px-2 py-0.5 rounded border border-[#C9EBDC] w-fit">
              Custom Tuning Mode
            </span>
          )}
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-2.5">
          {PRESETS.map((preset) => {
            const isSelected = activePreset === preset.id;
            return (
              <button
                key={preset.id}
                onClick={() => applyPreset(preset)}
                className={`p-3 rounded-xl border text-left transition-all cursor-pointer flex flex-col justify-between space-y-1.5 ${
                  isSelected
                    ? 'border-[#00D98B] bg-[#E7F8F1]/60 shadow-xs ring-1 ring-[#00D98B]'
                    : 'border-[#DDE2DE] bg-[#FFFFFF] hover:bg-[#F7F8F5] hover:border-[#8A918D]'
                }`}
              >
                <div>
                  <div className="flex items-center justify-between gap-1">
                    <span className="text-xs font-bold text-[#0A0D0C] block">
                      {preset.name}
                    </span>
                    {isSelected && (
                      <CheckCircle2 className="w-3.5 h-3.5 text-[#007A52] shrink-0" />
                    )}
                  </div>
                  <span className="text-[10px] font-mono text-[#007A52] font-semibold block mt-0.5">
                    {preset.badge}
                  </span>
                </div>
                <p className="text-[10px] text-[#68706B] line-clamp-2 leading-tight">
                  {preset.description}
                </p>
              </button>
            );
          })}
        </div>
      </section>

      {/* ==================================================
          CONTROLS:
          Carbon Sensitivity
          Latency Priority
          Accuracy Requirement
          Cost Sensitivity
          Carbon Budget
          Deadline
          ================================================== */}
      <section className="rounded-2xl border border-[#DDE2DE] bg-[#FFFFFF] p-5 sm:p-6 shadow-xs space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-3 border-b border-[#DDE2DE]">
          <div className="flex items-center gap-2">
            <Sliders className="w-4 h-4 text-[#007A52]" />
            <h2 className="text-sm sm:text-base font-bold text-[#0A0D0C] tracking-tight">
              Workflow Constraint Controls
            </h2>
          </div>
          <button
            onClick={() => applyPreset(PRESETS[0])}
            className="text-xs font-mono text-[#007A52] hover:underline flex items-center gap-1 cursor-pointer w-fit"
          >
            <RotateCcw className="w-3 h-3" />
            <span>Reset to Balanced Defaults</span>
          </button>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5 pt-1">
          {/* 1. Carbon Sensitivity */}
          <div className="p-3.5 rounded-xl border border-[#DDE2DE] bg-[#F7F8F5] space-y-2">
            <div className="flex items-center justify-between">
              <label className="text-xs font-semibold text-[#0A0D0C] flex items-center gap-1.5">
                <Leaf className="w-3.5 h-3.5 text-[#007A52]" />
                <span>Carbon Sensitivity</span>
              </label>
              <span className="text-xs font-mono font-bold text-[#007A52] bg-[#E7F8F1] px-2 py-0.5 rounded border border-[#C9EBDC]">
                {constraints.carbonSensitivity}%
              </span>
            </div>
            <input
              type="range"
              min={0}
              max={100}
              step={5}
              value={constraints.carbonSensitivity}
              onChange={(e) => updateConstraint('carbonSensitivity', parseInt(e.target.value))}
              className="w-full h-1.5 bg-[#DDE2DE] rounded-lg appearance-none cursor-pointer accent-[#007A52]"
            />
            <div className="flex justify-between text-[10px] font-mono text-[#8A918D]">
              <span>0% (Ignore)</span>
              <span>50% (Standard)</span>
              <span className="text-[#007A52] font-semibold">100% (Aggressive)</span>
            </div>
          </div>

          {/* 2. Latency Priority */}
          <div className="p-3.5 rounded-xl border border-[#DDE2DE] bg-[#F7F8F5] space-y-2">
            <div className="flex items-center justify-between">
              <label className="text-xs font-semibold text-[#0A0D0C] flex items-center gap-1.5">
                <Clock className="w-3.5 h-3.5 text-[#B9770E]" />
                <span>Latency Priority</span>
              </label>
              <span className="text-xs font-mono font-bold text-[#0A0D0C] bg-[#FFFFFF] px-2 py-0.5 rounded border border-[#DDE2DE]">
                {constraints.latencyPriority}%
              </span>
            </div>
            <input
              type="range"
              min={0}
              max={100}
              step={5}
              value={constraints.latencyPriority}
              onChange={(e) => updateConstraint('latencyPriority', parseInt(e.target.value))}
              className="w-full h-1.5 bg-[#DDE2DE] rounded-lg appearance-none cursor-pointer accent-[#0A0D0C]"
            />
            <div className="flex justify-between text-[10px] font-mono text-[#8A918D]">
              <span>0% (Flexible)</span>
              <span>50% (Standard)</span>
              <span className="text-[#B9770E] font-semibold">100% (Fastest)</span>
            </div>
          </div>

          {/* 3. Accuracy Requirement */}
          <div className="p-3.5 rounded-xl border border-[#DDE2DE] bg-[#F7F8F5] space-y-2">
            <div className="flex items-center justify-between">
              <label className="text-xs font-semibold text-[#0A0D0C] flex items-center gap-1.5">
                <ShieldCheck className="w-3.5 h-3.5 text-[#007A52]" />
                <span>Accuracy Requirement</span>
              </label>
              <span className="text-xs font-mono font-bold text-[#007A52] bg-[#E7F8F1] px-2 py-0.5 rounded border border-[#C9EBDC]">
                {constraints.accuracyRequirement.toFixed(1)}%
              </span>
            </div>
            <input
              type="range"
              min={75.0}
              max={99.0}
              step={0.5}
              value={constraints.accuracyRequirement}
              onChange={(e) => updateConstraint('accuracyRequirement', parseFloat(e.target.value))}
              className="w-full h-1.5 bg-[#DDE2DE] rounded-lg appearance-none cursor-pointer accent-[#00D98B]"
            />
            <div className="flex justify-between text-[10px] font-mono text-[#8A918D]">
              <span>75.0% (Relaxed)</span>
              <span>88.0% (Standard SLA)</span>
              <span className="text-[#007A52] font-semibold">99.0% (Strict)</span>
            </div>
          </div>

          {/* 4. Cost Sensitivity */}
          <div className="p-3.5 rounded-xl border border-[#DDE2DE] bg-[#F7F8F5] space-y-2">
            <div className="flex items-center justify-between">
              <label className="text-xs font-semibold text-[#0A0D0C] flex items-center gap-1.5">
                <DollarSign className="w-3.5 h-3.5 text-[#007A52]" />
                <span>Cost Sensitivity</span>
              </label>
              <span className="text-xs font-mono font-bold text-[#0A0D0C] bg-[#FFFFFF] px-2 py-0.5 rounded border border-[#DDE2DE]">
                {constraints.costSensitivity}%
              </span>
            </div>
            <input
              type="range"
              min={0}
              max={100}
              step={5}
              value={constraints.costSensitivity}
              onChange={(e) => updateConstraint('costSensitivity', parseInt(e.target.value))}
              className="w-full h-1.5 bg-[#DDE2DE] rounded-lg appearance-none cursor-pointer accent-[#0A0D0C]"
            />
            <div className="flex justify-between text-[10px] font-mono text-[#8A918D]">
              <span>0% (Unconstrained)</span>
              <span>50% (Standard)</span>
              <span className="text-[#007A52] font-semibold">100% (Strict Budget)</span>
            </div>
          </div>

          {/* 5. Carbon Budget Ceiling */}
          <div className="p-3.5 rounded-xl border border-[#DDE2DE] bg-[#F7F8F5] space-y-2">
            <div className="flex items-center justify-between">
              <label className="text-xs font-semibold text-[#0A0D0C] flex items-center gap-1.5">
                <Leaf className="w-3.5 h-3.5 text-[#007A52]" />
                <span>Carbon Budget Ceiling</span>
              </label>
              <span className="text-xs font-mono font-bold text-[#0A0D0C] bg-[#FFFFFF] px-2 py-0.5 rounded border border-[#DDE2DE]">
                {constraints.carbonBudget.toFixed(1)} gCO₂e
              </span>
            </div>
            <input
              type="range"
              min={15.0}
              max={80.0}
              step={2.5}
              value={constraints.carbonBudget}
              onChange={(e) => updateConstraint('carbonBudget', parseFloat(e.target.value))}
              className="w-full h-1.5 bg-[#DDE2DE] rounded-lg appearance-none cursor-pointer accent-[#007A52]"
            />
            <div className="flex justify-between text-[10px] font-mono text-[#8A918D]">
              <span className="text-[#007A52] font-semibold">15.0g (Strict)</span>
              <span>50.0g (Standard)</span>
              <span>80.0g (Relaxed)</span>
            </div>
          </div>

          {/* 6. Deadline */}
          <div className="p-3.5 rounded-xl border border-[#DDE2DE] bg-[#F7F8F5] space-y-2">
            <div className="flex items-center justify-between">
              <label className="text-xs font-semibold text-[#0A0D0C] flex items-center gap-1.5">
                <Clock className="w-3.5 h-3.5 text-[#B9770E]" />
                <span>Deadline SLA</span>
              </label>
              <span className="text-xs font-mono font-bold text-[#0A0D0C] bg-[#FFFFFF] px-2 py-0.5 rounded border border-[#DDE2DE]">
                {constraints.deadline} ms
              </span>
            </div>
            <input
              type="range"
              min={1000}
              max={4000}
              step={100}
              value={constraints.deadline}
              onChange={(e) => updateConstraint('deadline', parseInt(e.target.value))}
              className="w-full h-1.5 bg-[#DDE2DE] rounded-lg appearance-none cursor-pointer accent-[#B9770E]"
            />
            <div className="flex justify-between text-[10px] font-mono text-[#8A918D]">
              <span className="text-[#C0392B] font-semibold">1,000ms (Tight)</span>
              <span>2,500ms (Default)</span>
              <span>4,000ms (Generous)</span>
            </div>
          </div>
        </div>
      </section>

      {/* ==================================================
          RESULT:
          CURRENT PLAN vs NEW PLAN
          Metrics:
          Carbon
          Workflow Time
          Quality
          Cost
          Budget
          Slack
          ================================================== */}
      <section className="space-y-3">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
          <div>
            <h2 className="text-base sm:text-lg font-bold text-[#0A0D0C] tracking-tight">
              Optimization Impact: Current Plan vs. New Plan
            </h2>
            <p className="text-xs text-[#68706B]">
              Real-time simulated metric recalculations resulting from active constraints
            </p>
          </div>

          {/* Status Indicator */}
          <div className="flex items-center gap-2">
            {isBudgetExceeded ? (
              <span className="px-2.5 py-1 rounded-md text-xs font-mono font-bold bg-[#FDEDEC] text-[#C0392B] border border-[#F5B7B1] flex items-center gap-1">
                <AlertOctagon className="w-3.5 h-3.5" />
                Budget Exceeded (+{(newPlanMetrics.carbonGrams - newPlanMetrics.budgetCeilingGrams).toFixed(1)}g)
              </span>
            ) : isDeadlineBreached ? (
              <span className="px-2.5 py-1 rounded-md text-xs font-mono font-bold bg-[#FDEDEC] text-[#C0392B] border border-[#F5B7B1] flex items-center gap-1">
                <AlertOctagon className="w-3.5 h-3.5" />
                SLA Deadline Breached ({newPlanMetrics.slackMs}ms)
              </span>
            ) : (
              <span className="px-2.5 py-1 rounded-md text-xs font-mono font-bold bg-[#E7F8F1] text-[#007A52] border border-[#C9EBDC] flex items-center gap-1">
                <CheckCircle2 className="w-3.5 h-3.5" />
                Plan Feasible &amp; Compliant
              </span>
            )}
          </div>
        </div>

        {/* 6 Key Comparison Metric Cards */}
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3">
          {/* 1. Carbon */}
          <div className="rounded-xl border border-[#DDE2DE] bg-[#FFFFFF] p-3.5 shadow-xs space-y-1.5">
            <span className="text-[11px] font-mono text-[#8A918D] uppercase tracking-wider block">
              Carbon
            </span>
            <div className="space-y-0.5">
              <div className="text-lg sm:text-xl font-bold font-mono text-[#0A0D0C]">
                {newPlanMetrics.carbonGrams.toFixed(1)} <span className="text-xs font-normal text-[#68706B]">gCO₂e</span>
              </div>
              <div className="text-[11px] font-mono text-[#8A918D] flex items-center justify-between">
                <span>Current: {CURRENT_PLAN_METRICS.carbonGrams.toFixed(1)}g</span>
              </div>
            </div>
            <div className={`text-[11px] font-mono font-bold flex items-center gap-1 pt-1 border-t border-[#DDE2DE] ${
              carbonDelta < 0 ? 'text-[#007A52]' : carbonDelta > 0 ? 'text-[#C0392B]' : 'text-[#68706B]'
            }`}>
              {carbonDelta < 0 ? <TrendingDown className="w-3.5 h-3.5" /> : carbonDelta > 0 ? <TrendingUp className="w-3.5 h-3.5" /> : null}
              <span>{carbonDelta <= 0 ? `${carbonDelta} gCO₂e` : `+${carbonDelta} gCO₂e`}</span>
            </div>
          </div>

          {/* 2. Workflow Time */}
          <div className="rounded-xl border border-[#DDE2DE] bg-[#FFFFFF] p-3.5 shadow-xs space-y-1.5">
            <span className="text-[11px] font-mono text-[#8A918D] uppercase tracking-wider block">
              Workflow Time
            </span>
            <div className="space-y-0.5">
              <div className="text-lg sm:text-xl font-bold font-mono text-[#0A0D0C]">
                {newPlanMetrics.workflowTimeMs} <span className="text-xs font-normal text-[#68706B]">ms</span>
              </div>
              <div className="text-[11px] font-mono text-[#8A918D] flex items-center justify-between">
                <span>Current: {CURRENT_PLAN_METRICS.workflowTimeMs}ms</span>
              </div>
            </div>
            <div className={`text-[11px] font-mono font-bold flex items-center gap-1 pt-1 border-t border-[#DDE2DE] ${
              timeDelta < 0 ? 'text-[#007A52]' : timeDelta > 0 ? 'text-[#B9770E]' : 'text-[#68706B]'
            }`}>
              {timeDelta < 0 ? <TrendingDown className="w-3.5 h-3.5" /> : timeDelta > 0 ? <TrendingUp className="w-3.5 h-3.5" /> : null}
              <span>{timeDelta <= 0 ? `${timeDelta} ms` : `+${timeDelta} ms`}</span>
            </div>
          </div>

          {/* 3. Quality */}
          <div className="rounded-xl border border-[#DDE2DE] bg-[#FFFFFF] p-3.5 shadow-xs space-y-1.5">
            <span className="text-[11px] font-mono text-[#8A918D] uppercase tracking-wider block">
              Quality
            </span>
            <div className="space-y-0.5">
              <div className="text-lg sm:text-xl font-bold font-mono text-[#0A0D0C]">
                {newPlanMetrics.qualityScore.toFixed(1)}%
              </div>
              <div className="text-[11px] font-mono text-[#8A918D] flex items-center justify-between">
                <span>Current: {CURRENT_PLAN_METRICS.qualityScore.toFixed(1)}%</span>
              </div>
            </div>
            <div className={`text-[11px] font-mono font-bold flex items-center gap-1 pt-1 border-t border-[#DDE2DE] ${
              qualityDelta >= 0 ? 'text-[#007A52]' : 'text-[#C0392B]'
            }`}>
              {qualityDelta >= 0 ? <TrendingUp className="w-3.5 h-3.5" /> : <TrendingDown className="w-3.5 h-3.5" />}
              <span>{qualityDelta >= 0 ? `+${qualityDelta}%` : `${qualityDelta}%`}</span>
            </div>
          </div>

          {/* 4. Cost */}
          <div className="rounded-xl border border-[#DDE2DE] bg-[#FFFFFF] p-3.5 shadow-xs space-y-1.5">
            <span className="text-[11px] font-mono text-[#8A918D] uppercase tracking-wider block">
              Cost
            </span>
            <div className="space-y-0.5">
              <div className="text-lg sm:text-xl font-bold font-mono text-[#0A0D0C]">
                ${newPlanMetrics.costUsd.toFixed(4)}
              </div>
              <div className="text-[11px] font-mono text-[#8A918D] flex items-center justify-between">
                <span>Current: ${CURRENT_PLAN_METRICS.costUsd.toFixed(4)}</span>
              </div>
            </div>
            <div className={`text-[11px] font-mono font-bold flex items-center gap-1 pt-1 border-t border-[#DDE2DE] ${
              costDelta <= 0 ? 'text-[#007A52]' : 'text-[#B9770E]'
            }`}>
              <span>{costDelta <= 0 ? `-$${Math.abs(costDelta).toFixed(4)}` : `+$${costDelta.toFixed(4)}`}</span>
            </div>
          </div>

          {/* 5. Budget */}
          <div className={`rounded-xl border p-3.5 shadow-xs space-y-1.5 ${
            isBudgetExceeded ? 'border-[#F5B7B1] bg-[#FDEDEC]' : 'border-[#DDE2DE] bg-[#FFFFFF]'
          }`}>
            <span className="text-[11px] font-mono text-[#8A918D] uppercase tracking-wider block">
              Budget
            </span>
            <div className="space-y-0.5">
              <div className="text-lg sm:text-xl font-bold font-mono text-[#0A0D0C]">
                {newPlanMetrics.budgetCeilingGrams.toFixed(1)} <span className="text-xs font-normal text-[#68706B]">gCO₂e</span>
              </div>
              <div className="text-[11px] font-mono text-[#8A918D] flex items-center justify-between">
                <span>Used: {newPlanMetrics.carbonGrams.toFixed(1)}g</span>
              </div>
            </div>
            <div className={`text-[11px] font-mono font-bold pt-1 border-t ${
              isBudgetExceeded ? 'border-[#F5B7B1] text-[#C0392B]' : 'border-[#DDE2DE] text-[#007A52]'
            }`}>
              {isBudgetExceeded ? 'EXCEEDED' : `Headroom: ${(newPlanMetrics.budgetCeilingGrams - newPlanMetrics.carbonGrams).toFixed(1)}g`}
            </div>
          </div>

          {/* 6. Slack */}
          <div className={`rounded-xl border p-3.5 shadow-xs space-y-1.5 ${
            isDeadlineBreached ? 'border-[#F5B7B1] bg-[#FDEDEC]' : 'border-[#DDE2DE] bg-[#FFFFFF]'
          }`}>
            <span className="text-[11px] font-mono text-[#8A918D] uppercase tracking-wider block">
              Slack
            </span>
            <div className="space-y-0.5">
              <div className={`text-lg sm:text-xl font-bold font-mono ${
                newPlanMetrics.slackMs >= 0 ? 'text-[#007A52]' : 'text-[#C0392B]'
              }`}>
                {newPlanMetrics.slackMs >= 0 ? `+${newPlanMetrics.slackMs}` : newPlanMetrics.slackMs} <span className="text-xs font-normal text-[#68706B]">ms</span>
              </div>
              <div className="text-[11px] font-mono text-[#8A918D] flex items-center justify-between">
                <span>Deadline: {newPlanMetrics.deadlineMs}ms</span>
              </div>
            </div>
            <div className={`text-[11px] font-mono font-bold pt-1 border-t ${
              isDeadlineBreached ? 'border-[#F5B7B1] text-[#C0392B]' : 'border-[#DDE2DE] text-[#007A52]'
            }`}>
              {isDeadlineBreached ? 'BREACH RISK' : `${slackDelta >= 0 ? `+${slackDelta}ms buffer` : `${slackDelta}ms buffer`}`}
            </div>
          </div>
        </div>
      </section>

      {/* ==================================================
          WHY DID IT CHANGE?
          Always display:
          "What changed?"
          and
          "Why?"
          ================================================== */}
      <section className="rounded-2xl border border-[#DDE2DE] bg-[#FFFFFF] p-5 sm:p-6 shadow-xs space-y-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-6 h-6 rounded-md bg-[#E7F8F1] border border-[#C9EBDC] flex items-center justify-center text-[#007A52]">
              <Sparkles className="w-3.5 h-3.5" />
            </div>
            <div>
              <h2 className="text-base sm:text-lg font-bold text-[#0A0D0C] tracking-tight">
                Explainable Decision Telemetry: What Changed &amp; Why?
              </h2>
              <p className="text-xs text-[#68706B]">
                Causal trace connecting active constraint adjustments directly to DAG routing decisions
              </p>
            </div>
          </div>
          <span className="text-xs font-mono font-semibold text-[#007A52] bg-[#E7F8F1] px-2.5 py-1 rounded border border-[#C9EBDC] hidden sm:block">
            {causalChanges.length} Adaptations Active
          </span>
        </div>

        {/* List of Causal Change Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-3.5 pt-1">
          {causalChanges.map((item, idx) => (
            <div
              key={item.id}
              className="rounded-xl border border-[#DDE2DE] bg-[#F7F8F5] p-4 space-y-2 hover:border-[#00D98B] transition-colors"
            >
              {/* "What changed?" */}
              <div>
                <span className="text-[10px] font-mono uppercase tracking-wider text-[#8A918D] font-bold block">
                  What changed?
                </span>
                <h3 className="text-xs sm:text-sm font-bold text-[#0A0D0C] mt-0.5">
                  {item.whatChanged}
                </h3>
              </div>

              {/* "Why?" */}
              <div className="pt-2 border-t border-[#DDE2DE]">
                <span className="text-[10px] font-mono uppercase tracking-wider text-[#007A52] font-bold block">
                  Why?
                </span>
                <p className="text-xs text-[#68706B] leading-relaxed mt-0.5">
                  &ldquo;{item.why}&rdquo;
                </p>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* ==================================================
          WORKFLOW DAG:
          The DAG must change when the controls change.
          Examples:
          Higher carbon sensitivity: Smaller models, More deferral
          Higher latency priority: Less deferral, Faster execution
          Higher accuracy: More escalation, More capable models
          Tighter carbon budget: Reject expensive options, Change model selections, Delay eligible tasks
          ================================================== */}
      <section className="space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
          <div>
            <h2 className="text-base sm:text-lg font-bold text-[#0A0D0C] tracking-tight">
              Dynamically Re-Optimized Workflow DAG
            </h2>
            <p className="text-xs text-[#68706B]">
              Every node model tier, deferral status, and critical path latency dynamically reacts to active constraints
            </p>
          </div>

          <div className="flex items-center gap-2 text-xs font-mono">
            <span className="text-[#8A918D]">Click any node to inspect rationale</span>
          </div>
        </div>

        {/* Visual Pipeline DAG Flow Representation */}
        <div className="rounded-2xl border border-[#DDE2DE] bg-[#FFFFFF] p-5 sm:p-6 shadow-xs space-y-6">
          {/* Stage Progression Bar */}
          <div className="grid grid-cols-5 text-center text-[11px] font-mono text-[#8A918D] pb-3 border-b border-[#DDE2DE]">
            <div>Stage 1: Intake</div>
            <div>Stage 2: Parallel Extraction</div>
            <div>Stage 3: Quality Gate</div>
            <div>Stage 4: Executive Synthesis</div>
            <div>Stage 5: Deterministic Ledger</div>
          </div>

          {/* Interactive DAG Nodes Flow */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            {simulatedNodes.map((node) => {
              const isSelected = selectedNodeId === node.id;
              return (
                <div
                  key={node.id}
                  onClick={() => setSelectedNodeId(node.id)}
                  className={`rounded-xl border p-4 transition-all cursor-pointer flex flex-col justify-between space-y-3 ${
                    isSelected
                      ? 'border-[#00D98B] bg-[#E7F8F1]/20 shadow-md ring-2 ring-[#00D98B]'
                      : 'border-[#DDE2DE] bg-[#FFFFFF] hover:border-[#8A918D] hover:bg-[#F7F8F5]'
                  }`}
                >
                  {/* Node Header */}
                  <div>
                    <div className="flex items-center justify-between gap-1 mb-1">
                      <span className="text-[10px] font-mono text-[#8A918D] uppercase">
                        Stage {node.stage}
                      </span>
                      <span className={`text-[10px] font-mono px-2 py-0.5 rounded font-bold ${
                        node.statusType === 'solar_delayed'
                          ? 'bg-[#E7F8F1] text-[#007A52] border border-[#C9EBDC]'
                          : node.statusType === 'escalated'
                          ? 'bg-[#FDEDEC] text-[#C0392B] border border-[#F5B7B1]'
                          : node.statusType === 'rightsized' || node.statusType === 'downgraded'
                          ? 'bg-[#E7F8F1] text-[#007A52] border border-[#C9EBDC]'
                          : node.statusType === 'fast_tracked'
                          ? 'bg-[#FEF5E7] text-[#B9770E] border border-[#FAD7A0]'
                          : 'bg-[#F7F8F5] text-[#68706B] border border-[#DDE2DE]'
                      }`}>
                        {node.statusText}
                      </span>
                    </div>

                    <h3 className="text-xs sm:text-sm font-bold text-[#0A0D0C] leading-snug">
                      {node.name}
                    </h3>

                    <div className="text-[11px] font-mono text-[#68706B] mt-1 truncate" title={node.model}>
                      {node.model}
                    </div>
                  </div>

                  {/* Metrics & Rationale */}
                  <div className="pt-2 border-t border-[#DDE2DE] space-y-1 text-xs font-mono">
                    <div className="flex justify-between text-[#68706B]">
                      <span>Footprint:</span>
                      <strong className={node.carbonGrams > 10 ? 'text-[#B9770E]' : 'text-[#007A52]'}>
                        {node.carbonGrams.toFixed(1)} gCO₂e
                      </strong>
                    </div>
                    <div className="flex justify-between text-[#68706B]">
                      <span>Latency:</span>
                      <span className="text-[#0A0D0C]">{node.latencyMs} ms</span>
                    </div>
                    <div className="flex justify-between text-[#68706B]">
                      <span>Quality:</span>
                      <span className="text-[#007A52] font-semibold">{node.quality.toFixed(1)}%</span>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>

          {/* Detailed Selected Node Why Drawer */}
          {activeNode && (
            <div className="p-4 rounded-xl border border-[#00D98B] bg-[#E7F8F1]/40 space-y-2">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                <div className="flex items-center gap-2">
                  <div className="w-6 h-6 rounded-md bg-[#00D98B] flex items-center justify-center text-[#0A0D0C]">
                    <Cpu className="w-3.5 h-3.5" />
                  </div>
                  <h4 className="text-xs sm:text-sm font-bold text-[#0A0D0C]">
                    Active Node Inspection: {activeNode.name}
                  </h4>
                </div>
                <span className="text-xs font-mono text-[#007A52] font-bold">
                  {activeNode.statusText}
                </span>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 pt-2 text-xs font-mono">
                <div className="bg-[#FFFFFF] p-2.5 rounded-lg border border-[#DDE2DE]">
                  <span className="text-[10px] text-[#8A918D] block uppercase">Model Selected</span>
                  <span className="font-bold text-[#0A0D0C] text-[11px]">{activeNode.model}</span>
                </div>
                <div className="bg-[#FFFFFF] p-2.5 rounded-lg border border-[#DDE2DE]">
                  <span className="text-[10px] text-[#8A918D] block uppercase">Node Carbon &amp; Speed</span>
                  <span className="font-bold text-[#007A52] text-[11px]">{activeNode.carbonGrams} gCO₂e • {activeNode.latencyMs}ms</span>
                </div>
                <div className="bg-[#FFFFFF] p-2.5 rounded-lg border border-[#DDE2DE]">
                  <span className="text-[10px] text-[#8A918D] block uppercase">Grounding Quality</span>
                  <span className="font-bold text-[#007A52] text-[11px]">{activeNode.quality}% Confirmed</span>
                </div>
              </div>

              <div className="pt-2 text-xs">
                <span className="font-bold text-[#0A0D0C]">Scheduler Optimization Rationale: </span>
                <span className="text-[#68706B]">{activeNode.whyAdapted}</span>
              </div>
            </div>
          )}
        </div>
      </section>
    </div>
  );
};
