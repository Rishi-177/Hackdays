/**
 * CarbonPilot — Carbon Budget Decision Page
 * Enforces per-workflow carbon ceilings, real-time emissions accounting,
 * and multi-plan candidate evaluation (Allowed vs Rejected).
 */

import React, { useState } from 'react';
import {
  Leaf,
  CheckCircle2,
  XCircle,
  AlertOctagon,
  Sliders,
  TrendingDown,
  Cpu,
  Clock,
  ShieldCheck,
  Zap,
  RotateCcw,
  Sparkles,
} from 'lucide-react';

interface ExecutionChoice {
  id: string;
  name: string;
  strategy: string;
  projectedCarbonGrams: number;
  latencyMs: number;
  qualityScore: number;
  modelMix: string;
  rejectionReason?: string;
  details: string;
}

export const CarbonBudgetView: React.FC = () => {
  // Configurable Budget Ceiling
  const [budgetCeiling, setBudgetCeiling] = useState<number>(50.0);
  
  // Current Workflow State
  const usedCarbon = 24.9;
  const remainingBudget = Math.max(0, Number((budgetCeiling - usedCarbon).toFixed(1)));
  const projectedUsage = 23.8; // Adaptive optimized plan

  // Candidate Execution Plans
  const candidatePlans: ExecutionChoice[] = [
    {
      id: 'plan-adaptive',
      name: 'Plan A: CarbonPilot Adaptive Scheduler (Recommended)',
      strategy: 'Selective small model routing with solar peak batch deferral',
      projectedCarbonGrams: 23.8,
      latencyMs: 1480,
      qualityScore: 95.1,
      modelMix: '75% Gemini Flash • 15% Gemini Pro • 10% Batch',
      details: 'Evaluates global DAG constraints; delays Task 4 into clean solar window and invokes Pro model only on ambiguous clauses.',
    },
    {
      id: 'plan-solar-shift',
      name: 'Plan B: Aggressive Solar-Shifted Plan',
      strategy: 'Maximum clean-grid deferral of all non-critical parallel branches',
      projectedCarbonGrams: 18.4,
      latencyMs: 1820,
      qualityScore: 93.4,
      modelMix: '85% Gemini Flash • 5% Gemini Pro • 10% Batch',
      details: 'Defers 2 non-critical branches into regional solar peak; lowest carbon footprint while staying within deadline.',
    },
    {
      id: 'plan-balanced',
      name: 'Plan C: Balanced Fast-Track Pipeline',
      strategy: 'Moderate frontier allocation for expedited critical path execution',
      projectedCarbonGrams: 31.6,
      latencyMs: 1210,
      qualityScore: 96.0,
      modelMix: '50% Gemini Flash • 50% Gemini Pro',
      details: 'Executes parallel contract extraction with frontier models to minimize critical path latency.',
    },
    {
      id: 'plan-naive-frontier',
      name: 'Plan D: Naive All-Frontier Pipeline (Industry Standard)',
      strategy: 'Unconstrained Gemini 2.5 Pro on every task node without right-sizing',
      projectedCarbonGrams: 61.7,
      latencyMs: 3400,
      qualityScore: 96.2,
      modelMix: '100% Gemini 2.5 Pro (Frontier)',
      details: 'Runs high-parameter frontier LLM on all stages including routine regex and deterministic JSON extraction.',
    },
    {
      id: 'plan-multi-agent-debate',
      name: 'Plan E: Multi-Agent Consensus Debate',
      strategy: '3-round debate loop across 4 autonomous agents for consensus verification',
      projectedCarbonGrams: 78.4,
      latencyMs: 5120,
      qualityScore: 96.5,
      modelMix: 'Multi-agent Gemini Pro debate instances',
      details: 'Iterative 3-round agent-to-agent debate loop generating 14,000+ redundant intermediate critique tokens.',
    },
    {
      id: 'plan-uncached-rerank',
      name: 'Plan F: Redundant Uncached Embeddings & Reranking',
      strategy: 'No semantic cache; live recalculation of embeddings across 18 document chunks',
      projectedCarbonGrams: 54.2,
      latencyMs: 2900,
      qualityScore: 94.8,
      modelMix: '60% Gemini Pro • 40% Embedding Models',
      details: 'Disables shared embedding cache; performs live vector re-encoding on static SEC exhibit tables.',
    },
  ];

  // Helper to evaluate allowed vs rejected against current remaining budget
  const evaluatePlan = (plan: ExecutionChoice) => {
    // If the plan's projected carbon exceeds the total budget OR exceeds the remaining budget:
    const isAllowed = plan.projectedCarbonGrams <= budgetCeiling;
    let reason: string | undefined;

    if (!isAllowed) {
      if (plan.projectedCarbonGrams > budgetCeiling) {
        reason = `Rejected because projected workflow carbon exceeds remaining budget. Projected ${plan.projectedCarbonGrams.toFixed(1)} gCO₂e exceeds budget ceiling of ${budgetCeiling.toFixed(1)} gCO₂e by +${(plan.projectedCarbonGrams - budgetCeiling).toFixed(1)} gCO₂e.`;
      } else {
        reason = `Rejected because projected workflow carbon exceeds remaining budget.`;
      }
    }

    return {
      ...plan,
      isAllowed,
      rejectionReason: reason,
    };
  };

  const evaluatedPlans = candidatePlans.map(evaluatePlan);
  const allowedCount = evaluatedPlans.filter((p) => p.isAllowed).length;
  const rejectedCount = evaluatedPlans.filter((p) => !p.isAllowed).length;

  const usedPct = Math.min(100, Math.round((usedCarbon / budgetCeiling) * 100));
  const remainingPct = Math.max(0, Math.round((remainingBudget / budgetCeiling) * 100));

  return (
    <div className="max-w-7xl mx-auto space-y-6 pb-12">
      {/* Page Header */}
      <header className="pb-4 border-b border-[#DDE2DE]">
        <div className="flex items-center gap-2 mb-1">
          <div className="w-6 h-6 rounded-md bg-[#E7F8F1] border border-[#C9EBDC] flex items-center justify-center text-[#007A52]">
            <Leaf className="w-3.5 h-3.5" />
          </div>
          <span className="text-[11px] font-mono text-[#007A52] font-semibold tracking-wide uppercase">
            Budget Enforcement
          </span>
        </div>
        <h1 className="text-xl sm:text-2xl font-bold text-[#0A0D0C] tracking-tight">
          Carbon Budget Management
        </h1>
        <p className="text-xs sm:text-sm text-[#68706B] mt-1 max-w-3xl leading-relaxed">
          Enforces hard carbon ceilings across the complete agent workflow. Before dispatching any plan, CarbonPilot projects cumulative emissions and automatically rejects plans that violate the remaining carbon budget.
        </p>
      </header>

      {/* ==================================================
          PRIMARY METRICS:
          Budget
          Used
          Remaining
          Projected Usage
          ================================================== */}
      <section className="grid grid-cols-2 lg:grid-cols-4 gap-3.5">
        {/* 1. Budget */}
        <div className="rounded-xl border border-[#DDE2DE] bg-[#FFFFFF] p-4 sm:p-5 shadow-xs space-y-1.5">
          <div className="flex items-center justify-between text-[11px] font-mono text-[#8A918D] uppercase tracking-wider">
            <span>Budget</span>
            <Leaf className="w-3.5 h-3.5 text-[#007A52]" />
          </div>
          <div className="text-2xl sm:text-3xl font-bold font-mono text-[#0A0D0C] tracking-tight">
            {budgetCeiling.toFixed(1)} <span className="text-xs sm:text-sm font-sans font-normal text-[#68706B]">gCO₂e</span>
          </div>
          <p className="text-xs text-[#68706B]">
            Hard carbon ceiling per workflow execution
          </p>
        </div>

        {/* 2. Used */}
        <div className="rounded-xl border border-[#DDE2DE] bg-[#FFFFFF] p-4 sm:p-5 shadow-xs space-y-1.5">
          <div className="flex items-center justify-between text-[11px] font-mono text-[#8A918D] uppercase tracking-wider">
            <span>Used</span>
            <span className="w-2 h-2 rounded-full bg-[#00D98B]" />
          </div>
          <div className="text-2xl sm:text-3xl font-bold font-mono text-[#0A0D0C] tracking-tight">
            {usedCarbon.toFixed(1)} <span className="text-xs sm:text-sm font-sans font-normal text-[#68706B]">gCO₂e</span>
          </div>
          <p className="text-xs text-[#68706B]">
            Consumed by completed stages ({usedPct}% of cap)
          </p>
        </div>

        {/* 3. Remaining */}
        <div className="rounded-xl border border-[#DDE2DE] bg-[#FFFFFF] p-4 sm:p-5 shadow-xs space-y-1.5">
          <div className="flex items-center justify-between text-[11px] font-mono text-[#8A918D] uppercase tracking-wider">
            <span>Remaining</span>
            <span className="text-xs font-mono text-[#007A52] font-semibold">{remainingPct}%</span>
          </div>
          <div className="text-2xl sm:text-3xl font-bold font-mono text-[#007A52] tracking-tight">
            {remainingBudget.toFixed(1)} <span className="text-xs sm:text-sm font-sans font-normal text-[#68706B]">gCO₂e</span>
          </div>
          <p className="text-xs text-[#68706B]">
            Available headroom for pending stages
          </p>
        </div>

        {/* 4. Projected Usage */}
        <div className="rounded-xl border border-[#DDE2DE] bg-[#FFFFFF] p-4 sm:p-5 shadow-xs space-y-1.5">
          <div className="flex items-center justify-between text-[11px] font-mono text-[#8A918D] uppercase tracking-wider">
            <span>Projected Usage</span>
            <Sparkles className="w-3.5 h-3.5 text-[#00D98B]" />
          </div>
          <div className="text-2xl sm:text-3xl font-bold font-mono text-[#0A0D0C] tracking-tight">
            {projectedUsage.toFixed(1)} <span className="text-xs sm:text-sm font-sans font-normal text-[#68706B]">gCO₂e</span>
          </div>
          <p className="text-xs text-[#007A52] font-medium">
            Safe • -61.4% vs unconstrained baseline
          </p>
        </div>
      </section>

      {/* Visual Budget Allocation Bar */}
      <div className="rounded-xl border border-[#DDE2DE] bg-[#FFFFFF] p-4 sm:p-5 shadow-xs space-y-3">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
          <div>
            <h3 className="text-sm font-bold text-[#0A0D0C]">
              Budget Consumption Breakdown
            </h3>
            <p className="text-xs text-[#68706B]">
              Real-time consumption status against the {budgetCeiling.toFixed(1)} gCO₂e cap
            </p>
          </div>
          <span className="text-xs font-mono px-2.5 py-1 rounded bg-[#E7F8F1] border border-[#C9EBDC] text-[#007A52] font-semibold w-fit">
            Status: Within Budget
          </span>
        </div>

        {/* Stacked Progress Bar */}
        <div className="w-full h-4 bg-[#F7F8F5] rounded-full overflow-hidden border border-[#DDE2DE] flex">
          <div
            className="h-full bg-[#007A52] transition-all duration-300"
            style={{ width: `${Math.min(usedPct, 100)}%` }}
            title={`Used: ${usedCarbon} gCO₂e (${usedPct}%)`}
          />
          <div
            className="h-full bg-[#00D98B]/30 border-l border-[#007A52]/20 transition-all duration-300"
            style={{ width: `${Math.min(remainingPct, 100 - usedPct)}%` }}
            title={`Remaining: ${remainingBudget} gCO₂e (${remainingPct}%)`}
          />
        </div>

        <div className="flex flex-wrap items-center justify-between gap-4 text-xs font-mono pt-1 text-[#68706B]">
          <div className="flex items-center gap-2">
            <span className="w-3 h-3 rounded-xs bg-[#007A52]" />
            <span>Used: <strong className="text-[#0A0D0C]">{usedCarbon} gCO₂e</strong></span>
          </div>
          <div className="flex items-center gap-2">
            <span className="w-3 h-3 rounded-xs bg-[#00D98B]/30 border border-[#00D98B]" />
            <span>Remaining Headroom: <strong className="text-[#007A52]">{remainingBudget} gCO₂e</strong></span>
          </div>
          <div className="flex items-center gap-2">
            <span className="w-3 h-3 rounded-xs bg-[#F7F8F5] border border-[#DDE2DE]" />
            <span>Budget Ceiling: <strong className="text-[#0A0D0C]">{budgetCeiling.toFixed(1)} gCO₂e</strong></span>
          </div>
        </div>
      </div>

      {/* Interactive Budget Ceiling Slider */}
      <div className="rounded-xl border border-[#DDE2DE] bg-[#F7F8F5] p-4 sm:p-5 shadow-xs space-y-3">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
          <div className="flex items-center gap-2">
            <Sliders className="w-4 h-4 text-[#007A52]" />
            <h3 className="text-sm font-bold text-[#0A0D0C]">
              Simulate Budget Ceiling Adjustments
            </h3>
          </div>
          <div className="flex items-center gap-2">
            <span className="text-xs text-[#68706B]">Budget Cap:</span>
            <span className="text-xs font-mono font-bold text-[#0A0D0C] bg-[#FFFFFF] px-2.5 py-0.5 rounded border border-[#DDE2DE]">
              {budgetCeiling.toFixed(1)} gCO₂e
            </span>
            <button
              onClick={() => setBudgetCeiling(50.0)}
              className="text-xs font-mono text-[#007A52] hover:underline cursor-pointer flex items-center gap-1 ml-2"
              title="Reset default 50.0 gCO₂e"
            >
              <RotateCcw className="w-3 h-3" />
              <span>Reset</span>
            </button>
          </div>
        </div>

        <input
          type="range"
          min={20}
          max={90}
          step={2.5}
          value={budgetCeiling}
          onChange={(e) => setBudgetCeiling(parseFloat(e.target.value))}
          className="w-full h-2 bg-[#DDE2DE] rounded-lg appearance-none cursor-pointer accent-[#007A52]"
        />

        <div className="flex justify-between text-[11px] font-mono text-[#8A918D]">
          <span>20.0 gCO₂e (Strict Cap)</span>
          <span>50.0 gCO₂e (Default Enterprise SLA)</span>
          <span>90.0 gCO₂e (Unconstrained)</span>
        </div>
      </div>

      {/* ==================================================
          POSSIBLE EXECUTION CHOICES
          Clearly mark:
          Allowed
          or
          Rejected
          Every rejection must have a reason.
          ================================================== */}
      <section className="space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
          <div>
            <h2 className="text-base sm:text-lg font-bold text-[#0A0D0C] tracking-tight">
              Possible Execution Choices &amp; Feasibility Evaluation
            </h2>
            <p className="text-xs text-[#68706B]">
              Every candidate plan is audited against the active carbon budget ceiling. Rejections are strictly documented with causal reasons.
            </p>
          </div>
          <div className="flex items-center gap-2 text-xs font-mono">
            <span className="px-2 py-0.5 rounded bg-[#E7F8F1] text-[#007A52] border border-[#C9EBDC] font-semibold">
              {allowedCount} Allowed
            </span>
            <span className="px-2 py-0.5 rounded bg-[#FDEDEC] text-[#C0392B] border border-[#F5B7B1] font-semibold">
              {rejectedCount} Rejected
            </span>
          </div>
        </div>

        {/* Execution Choices Cards List */}
        <div className="space-y-3.5">
          {evaluatedPlans.map((plan) => (
            <div
              key={plan.id}
              className={`rounded-xl border p-4 sm:p-5 transition-all shadow-xs ${
                plan.isAllowed
                  ? 'border-[#DDE2DE] bg-[#FFFFFF] hover:border-[#00D98B]'
                  : 'border-[#F5B7B1] bg-[#FFFBFB]'
              }`}
            >
              <div className="flex flex-col md:flex-row md:items-start justify-between gap-3">
                {/* Plan Info */}
                <div className="space-y-1.5 flex-1">
                  <div className="flex flex-wrap items-center gap-2">
                    <h3 className="text-sm sm:text-base font-bold text-[#0A0D0C]">
                      {plan.name}
                    </h3>

                    {/* STATUS BADGE: ALLOWED OR REJECTED */}
                    {plan.isAllowed ? (
                      <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-xs font-mono font-bold bg-[#E7F8F1] text-[#007A52] border border-[#C9EBDC]">
                        <CheckCircle2 className="w-3.5 h-3.5" />
                        Allowed
                      </span>
                    ) : (
                      <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-xs font-mono font-bold bg-[#FDEDEC] text-[#C0392B] border border-[#F5B7B1]">
                        <XCircle className="w-3.5 h-3.5" />
                        Rejected
                      </span>
                    )}
                  </div>

                  <p className="text-xs text-[#68706B]">
                    {plan.strategy}
                  </p>
                  <p className="text-xs text-[#0A0D0C] leading-relaxed pt-0.5">
                    {plan.details}
                  </p>

                  {/* REJECTION REASON (IF REJECTED) */}
                  {!plan.isAllowed && plan.rejectionReason && (
                    <div className="mt-2.5 p-3 rounded-lg bg-[#FDEDEC] border border-[#F5B7B1] text-xs space-y-1">
                      <div className="flex items-center gap-1.5 font-bold text-[#C0392B]">
                        <AlertOctagon className="w-4 h-4 shrink-0" />
                        <span>Rejection Reason</span>
                      </div>
                      <p className="text-[#C0392B] text-[11px] leading-relaxed font-mono">
                        &ldquo;{plan.rejectionReason}&rdquo;
                      </p>
                    </div>
                  )}
                </div>

                {/* Metrics Breakdown Column */}
                <div className="flex md:flex-col items-center md:items-end justify-between md:justify-start gap-2 pt-2 md:pt-0 border-t md:border-t-0 border-[#DDE2DE] shrink-0 text-right font-mono text-xs">
                  <div>
                    <span className="text-[10px] text-[#8A918D] block uppercase">Projected Carbon</span>
                    <span className={`text-base font-bold ${
                      plan.isAllowed ? 'text-[#007A52]' : 'text-[#C0392B]'
                    }`}>
                      {plan.projectedCarbonGrams.toFixed(1)} gCO₂e
                    </span>
                  </div>

                  <div className="flex items-center gap-3 text-[11px] text-[#68706B]">
                    <span>{plan.latencyMs} ms</span>
                    <span>•</span>
                    <span>{plan.qualityScore}% Quality</span>
                  </div>

                  <div className="text-[10px] text-[#8A918D] max-w-[200px] truncate">
                    {plan.modelMix}
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </section>
    </div>
  );
};
