/**
 * CarbonPilot — Deadline & Slack Decision Page
 * Visual timeline demonstrating Now → Tasks → Deadline,
 * identifying critical vs deferrable tasks, and proving that
 * tasks can be delayed into clean solar windows without breaking deadlines.
 */

import React, { useState } from 'react';
import {
  Clock,
  CheckCircle2,
  Calendar,
  Sun,
  Flame,
  Zap,
  ArrowRight,
  TrendingDown,
  Info,
  ShieldCheck,
  AlertCircle,
  Play,
  RotateCcw,
} from 'lucide-react';

export const DeadlineSlackView: React.FC = () => {
  // Configurable workflow parameters
  const deadlineMs = 2500;
  const criticalPathDurationMs = 1520;
  const totalSlackMs = deadlineMs - criticalPathDurationMs; // 980 ms

  // Interactive delay demonstration for Task 4 (Compliance Audit Batch)
  // Non-critical branch slack for Task 4 is 1,480 ms (within pipeline)
  // Solar grid delay can be 0s, 15s, 30s, 45s (recommended), or 60s
  const [delaySeconds, setDelaySeconds] = useState<number>(45);

  // Grid emissions calculation
  // Base fossil intensity: 340 gCO₂/kWh
  // Solar clean intensity: 180 gCO₂/kWh at 45s
  const baseGridIntensity = 340;
  const solarGridIntensity = Math.round(
    baseGridIntensity - (delaySeconds / 45) * (340 - 180)
  );

  const task4BaseCarbon = 11.9; // gCO₂e
  const task4OptimizedCarbon = Number(
    (task4BaseCarbon * (solarGridIntensity / baseGridIntensity)).toFixed(1)
  );
  const carbonSavedGrams = Number((task4BaseCarbon - task4OptimizedCarbon).toFixed(1));
  const carbonSavedPct = Math.round((carbonSavedGrams / task4BaseCarbon) * 100);

  // Critical path impact: As long as delay is within slack, impact on deadline is 0 ms!
  const deadlineImpactMs = 0;
  const isDeadlineSafe = criticalPathDurationMs <= deadlineMs;

  return (
    <div className="max-w-7xl mx-auto space-y-6 pb-12">
      {/* Header */}
      <header className="pb-4 border-b border-[#DDE2DE]">
        <div className="flex items-center gap-2 mb-1">
          <div className="w-6 h-6 rounded-md bg-[#E7F8F1] border border-[#C9EBDC] flex items-center justify-center text-[#007A52]">
            <Clock className="w-3.5 h-3.5" />
          </div>
          <span className="text-[11px] font-mono text-[#007A52] font-semibold tracking-wide uppercase">
            Temporal Scheduling
          </span>
        </div>
        <h1 className="text-xl sm:text-2xl font-bold text-[#0A0D0C] tracking-tight">
          Deadline &amp; Slack Management
        </h1>
        <p className="text-xs sm:text-sm text-[#68706B] mt-1 max-w-3xl leading-relaxed">
          Critical path analysis determines exactly which tasks determine end-to-end latency and which have positive deadline slack. Deferrable tasks can be shifted into clean regional solar windows with zero penalty to SLA delivery.
        </p>
      </header>

      {/* ==================================================
          SHOW:
          Deadline
          Predicted Completion
          Slack
          ================================================== */}
      <section className="grid grid-cols-1 sm:grid-cols-3 gap-3.5">
        {/* 1. Deadline */}
        <div className="rounded-xl border border-[#DDE2DE] bg-[#FFFFFF] p-4 sm:p-5 shadow-xs space-y-1.5">
          <div className="flex items-center justify-between text-[11px] font-mono text-[#8A918D] uppercase tracking-wider">
            <span>Deadline</span>
            <Clock className="w-3.5 h-3.5 text-[#007A52]" />
          </div>
          <div className="text-2xl sm:text-3xl font-bold font-mono text-[#0A0D0C] tracking-tight">
            {deadlineMs} <span className="text-xs sm:text-sm font-sans font-normal text-[#68706B]">ms</span>
          </div>
          <p className="text-xs text-[#68706B]">
            Maximum allowable SLA latency budget
          </p>
        </div>

        {/* 2. Predicted Completion */}
        <div className="rounded-xl border border-[#DDE2DE] bg-[#FFFFFF] p-4 sm:p-5 shadow-xs space-y-1.5">
          <div className="flex items-center justify-between text-[11px] font-mono text-[#8A918D] uppercase tracking-wider">
            <span>Predicted Completion</span>
            <CheckCircle2 className="w-3.5 h-3.5 text-[#00D98B]" />
          </div>
          <div className="text-2xl sm:text-3xl font-bold font-mono text-[#0A0D0C] tracking-tight">
            {criticalPathDurationMs} <span className="text-xs sm:text-sm font-sans font-normal text-[#68706B]">ms</span>
          </div>
          <p className="text-xs text-[#007A52] font-medium">
            1.52s wall-clock time along critical path
          </p>
        </div>

        {/* 3. Slack */}
        <div className="rounded-xl border border-[#DDE2DE] bg-[#FFFFFF] p-4 sm:p-5 shadow-xs space-y-1.5">
          <div className="flex items-center justify-between text-[11px] font-mono text-[#8A918D] uppercase tracking-wider">
            <span>Slack</span>
            <span className="w-2 h-2 rounded-full bg-[#00D98B]" />
          </div>
          <div className="text-2xl sm:text-3xl font-bold font-mono text-[#007A52] tracking-tight">
            +{totalSlackMs} <span className="text-xs sm:text-sm font-sans font-normal text-[#68706B]">ms</span>
          </div>
          <p className="text-xs text-[#68706B]">
            Buffer safety margin before SLA breach
          </p>
        </div>
      </section>

      {/* ==================================================
          VISUAL TIMELINE:
          Now → Tasks → Deadline
          ================================================== */}
      <section className="rounded-xl border border-[#DDE2DE] bg-[#FFFFFF] p-5 sm:p-6 shadow-xs space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
          <div>
            <h2 className="text-base sm:text-lg font-bold text-[#0A0D0C] tracking-tight">
              Visual Execution Timeline
            </h2>
            <p className="text-xs text-[#68706B]">
              Timeline mapping: Now (0 ms) → Tasks Execution → Deadline SLA (2,500 ms)
            </p>
          </div>
          <div className="flex items-center gap-2 text-xs font-mono text-[#68706B]">
            <span className="w-2.5 h-2.5 rounded-xs bg-[#B9770E]" /> Critical Path
            <span className="w-2.5 h-2.5 rounded-xs bg-[#00D98B]" /> Deferrable Slack
          </div>
        </div>

        {/* Linear Timeline Bar Container */}
        <div className="space-y-2 pt-2">
          {/* Axis Labels */}
          <div className="flex justify-between text-[11px] font-mono text-[#8A918D] px-1">
            <span className="font-bold text-[#0A0D0C]">Now (0 ms)</span>
            <span>Task Execution (0 – 1,520 ms)</span>
            <span className="text-[#007A52] font-semibold">Predicted: 1,520 ms</span>
            <span className="font-bold text-[#C0392B]">Deadline SLA: 2,500 ms</span>
          </div>

          {/* Timeline Bar Surface */}
          <div className="relative w-full h-10 bg-[#F7F8F5] rounded-xl border border-[#DDE2DE] overflow-hidden flex items-center shadow-inner">
            {/* Stage 1: Doc Triage (0-320ms) */}
            <div
              style={{ width: `${(320 / deadlineMs) * 100}%` }}
              className="h-full bg-[#0A0D0C] text-[#FFFFFF] text-[10px] font-mono flex items-center justify-center border-r border-[#FFFFFF]/20 truncate px-1"
              title="Stage 1: Document Triage (320 ms)"
            >
              Stage 1 (320ms)
            </div>

            {/* Stage 2: Contract Extraction (320-800ms, 480ms) */}
            <div
              style={{ width: `${(480 / deadlineMs) * 100}%` }}
              className="h-full bg-[#B9770E] text-[#FFFFFF] text-[10px] font-mono flex items-center justify-center border-r border-[#FFFFFF]/20 truncate px-1"
              title="Stage 2: Contract Extraction (480 ms) • Critical Path"
            >
              Extraction (480ms)
            </div>

            {/* Stage 3: Quality Gate (800-980ms, 180ms) */}
            <div
              style={{ width: `${(180 / deadlineMs) * 100}%` }}
              className="h-full bg-[#007A52] text-[#FFFFFF] text-[10px] font-mono flex items-center justify-center border-r border-[#FFFFFF]/20 truncate px-1"
              title="Stage 3: Quality Gate (180 ms)"
            >
              Gate (180ms)
            </div>

            {/* Stage 4: Risk Synthesis (980-1360ms, 380ms) */}
            <div
              style={{ width: `${(380 / deadlineMs) * 100}%` }}
              className="h-full bg-[#B9770E] text-[#FFFFFF] text-[10px] font-mono flex items-center justify-center border-r border-[#FFFFFF]/20 truncate px-1"
              title="Stage 4: Risk Synthesis (380 ms) • Critical Path"
            >
              Synthesis (380ms)
            </div>

            {/* Stage 5: Audit Ledger (1360-1520ms, 160ms) */}
            <div
              style={{ width: `${(160 / deadlineMs) * 100}%` }}
              className="h-full bg-[#0A0D0C] text-[#FFFFFF] text-[10px] font-mono flex items-center justify-center border-r border-[#FFFFFF]/20 truncate px-1"
              title="Stage 5: Audit Ledger (160 ms)"
            >
              Ledger (160ms)
            </div>

            {/* SLACK WINDOW: 1,520 ms to 2,500 ms (+980 ms) */}
            <div
              style={{ width: `${(980 / deadlineMs) * 100}%` }}
              className="h-full bg-[#E7F8F1] text-[#007A52] text-xs font-mono font-bold flex items-center justify-center border-l-2 border-dashed border-[#00D98B] px-2 truncate"
              title="Available Deadline Slack: +980 ms buffer"
            >
              +980 ms Slack Window
            </div>
          </div>

          {/* Markers below timeline */}
          <div className="flex justify-between text-[10px] font-mono text-[#8A918D] pt-0.5">
            <span>Start</span>
            <span>0.5s</span>
            <span>1.0s</span>
            <span className="text-[#007A52] font-semibold">▲ 1.52s (Done)</span>
            <span>2.0s</span>
            <span className="text-[#C0392B] font-semibold">▲ 2.50s (SLA Limit)</span>
          </div>
        </div>
      </section>

      {/* ==================================================
          IDENTIFY:
          Critical tasks
          Deferrable tasks
          ================================================== */}
      <section className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {/* CRITICAL TASKS */}
        <div className="rounded-xl border border-[#DDE2DE] bg-[#FFFFFF] p-4 sm:p-5 shadow-xs space-y-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <div className="w-6 h-6 rounded-md bg-[#FEF5E7] border border-[#FAD7A0] flex items-center justify-center text-[#B9770E]">
                <Flame className="w-3.5 h-3.5" />
              </div>
              <h3 className="text-sm font-bold text-[#0A0D0C]">
                Critical Tasks (Zero Slack)
              </h3>
            </div>
            <span className="text-[10px] font-mono px-2 py-0.5 rounded font-bold bg-[#FEF5E7] text-[#B9770E] border border-[#FAD7A0]">
              Bottleneck Path
            </span>
          </div>

          <p className="text-xs text-[#68706B]">
            Tasks on the critical path determine total workflow duration. Any delay here directly increases wall-clock time.
          </p>

          <div className="space-y-2 pt-1">
            <div className="p-2.5 rounded-lg border border-[#DDE2DE] bg-[#F7F8F5] flex items-center justify-between text-xs">
              <div>
                <span className="font-bold text-[#0A0D0C] block">Multimodal Contract Extraction</span>
                <span className="text-[11px] text-[#68706B]">Stage 2 • 480 ms</span>
              </div>
              <span className="font-mono text-[11px] font-bold text-[#B9770E] bg-[#FFFFFF] px-2 py-0.5 rounded border border-[#DDE2DE]">
                0 ms Slack
              </span>
            </div>

            <div className="p-2.5 rounded-lg border border-[#DDE2DE] bg-[#F7F8F5] flex items-center justify-between text-xs">
              <div>
                <span className="font-bold text-[#0A0D0C] block">Risk Synthesis &amp; Remediation</span>
                <span className="text-[11px] text-[#68706B]">Stage 4 • 380 ms</span>
              </div>
              <span className="font-mono text-[11px] font-bold text-[#B9770E] bg-[#FFFFFF] px-2 py-0.5 rounded border border-[#DDE2DE]">
                0 ms Slack
              </span>
            </div>

            <div className="p-2.5 rounded-lg border border-[#DDE2DE] bg-[#F7F8F5] flex items-center justify-between text-xs">
              <div>
                <span className="font-bold text-[#0A0D0C] block">Document Triage &amp; Intake</span>
                <span className="text-[11px] text-[#68706B]">Stage 1 • 320 ms</span>
              </div>
              <span className="font-mono text-[11px] font-bold text-[#B9770E] bg-[#FFFFFF] px-2 py-0.5 rounded border border-[#DDE2DE]">
                0 ms Slack
              </span>
            </div>
          </div>
        </div>

        {/* DEFERRABLE TASKS */}
        <div className="rounded-xl border border-[#DDE2DE] bg-[#FFFFFF] p-4 sm:p-5 shadow-xs space-y-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <div className="w-6 h-6 rounded-md bg-[#E7F8F1] border border-[#C9EBDC] flex items-center justify-center text-[#007A52]">
                <Sun className="w-3.5 h-3.5 text-[#00D98B]" />
              </div>
              <h3 className="text-sm font-bold text-[#0A0D0C]">
                Deferrable Tasks (Positive Slack)
              </h3>
            </div>
            <span className="text-[10px] font-mono px-2 py-0.5 rounded font-bold bg-[#E7F8F1] text-[#007A52] border border-[#C9EBDC]">
              Clean Window Eligible
            </span>
          </div>

          <p className="text-xs text-[#68706B]">
            Parallel branches with surplus deadline slack. Can be shifted into clean regional solar/wind windows with zero penalty.
          </p>

          <div className="space-y-2 pt-1">
            <div className="p-2.5 rounded-lg border border-[#C9EBDC] bg-[#E7F8F1]/40 flex items-center justify-between text-xs">
              <div>
                <span className="font-bold text-[#0A0D0C] block">Task 4: Compliance Audit Batch</span>
                <span className="text-[11px] text-[#68706B]">Stage 2 Parallel • 350 ms runtime</span>
              </div>
              <span className="font-mono text-[11px] font-bold text-[#007A52] bg-[#FFFFFF] px-2 py-0.5 rounded border border-[#C9EBDC]">
                +1,480 ms Slack
              </span>
            </div>

            <div className="p-2.5 rounded-lg border border-[#DDE2DE] bg-[#F7F8F5] flex items-center justify-between text-xs">
              <div>
                <span className="font-bold text-[#0A0D0C] block">Contextual Policy Retrieval</span>
                <span className="text-[11px] text-[#68706B]">Stage 2 Parallel • 210 ms runtime</span>
              </div>
              <span className="font-mono text-[11px] font-bold text-[#007A52] bg-[#FFFFFF] px-2 py-0.5 rounded border border-[#DDE2DE]">
                +270 ms Slack
              </span>
            </div>

            <div className="p-2.5 rounded-lg border border-[#DDE2DE] bg-[#F7F8F5] flex items-center justify-between text-xs">
              <div>
                <span className="font-bold text-[#0A0D0C] block">Audit Ledger Certification</span>
                <span className="text-[11px] text-[#68706B]">Stage 5 Async Push • 160 ms runtime</span>
              </div>
              <span className="font-mono text-[11px] font-bold text-[#007A52] bg-[#FFFFFF] px-2 py-0.5 rounded border border-[#DDE2DE]">
                +980 ms Slack
              </span>
            </div>
          </div>
        </div>
      </section>

      {/* ==================================================
          DEMONSTRATE:
          Task can be delayed without breaking deadline.
          Show:
          Before
          After
          Carbon impact
          Deadline impact
          ================================================== */}
      <section className="rounded-2xl border border-[#DDE2DE] bg-[#FFFFFF] p-5 sm:p-7 shadow-xs space-y-5">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div>
            <div className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-xs font-mono font-bold bg-[#E7F8F1] text-[#007A52] border border-[#C9EBDC] mb-1">
              <Sun className="w-3.5 h-3.5" />
              <span>Demonstration Proof</span>
            </div>
            <h2 className="text-lg sm:text-xl font-bold text-[#0A0D0C] tracking-tight">
              Task can be delayed without breaking deadline
            </h2>
            <p className="text-xs sm:text-sm text-[#68706B] mt-0.5">
              Testing deferral of <strong>Task 4: Compliance Audit Batch</strong> into regional solar intensity window
            </p>
          </div>

          {/* Quick Preset Buttons */}
          <div className="flex items-center gap-2">
            <button
              onClick={() => setDelaySeconds(0)}
              className={`px-2.5 py-1 rounded-md text-xs font-mono border transition-colors cursor-pointer ${
                delaySeconds === 0
                  ? 'bg-[#0A0D0C] text-[#FFFFFF] border-[#0A0D0C]'
                  : 'bg-[#FFFFFF] text-[#68706B] border-[#DDE2DE] hover:bg-[#F7F8F5]'
              }`}
            >
              0s (Immediate)
            </button>
            <button
              onClick={() => setDelaySeconds(45)}
              className={`px-2.5 py-1 rounded-md text-xs font-mono border transition-colors cursor-pointer ${
                delaySeconds === 45
                  ? 'bg-[#00D98B] text-[#0A0D0C] font-semibold border-[#00D98B]'
                  : 'bg-[#FFFFFF] text-[#68706B] border-[#DDE2DE] hover:bg-[#F7F8F5]'
              }`}
            >
              45s (Solar Peak)
            </button>
          </div>
        </div>

        {/* Delay Slider */}
        <div className="p-4 rounded-xl border border-[#DDE2DE] bg-[#F7F8F5] space-y-2">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-[#0A0D0C]">
              Adjust Delay for Task 4:
            </span>
            <span className="text-xs font-mono font-bold text-[#007A52] bg-[#FFFFFF] px-2 py-0.5 rounded border border-[#DDE2DE]">
              +{delaySeconds} seconds deferral
            </span>
          </div>
          <input
            type="range"
            min={0}
            max={60}
            step={5}
            value={delaySeconds}
            onChange={(e) => setDelaySeconds(parseInt(e.target.value))}
            className="w-full h-2 bg-[#DDE2DE] rounded-lg appearance-none cursor-pointer accent-[#007A52]"
          />
          <div className="flex justify-between text-[10px] font-mono text-[#8A918D]">
            <span>0s (Fossil Grid: 340 gCO₂/kWh)</span>
            <span className="text-[#007A52] font-semibold">45s (Solar Grid: 180 gCO₂/kWh)</span>
            <span>60s (Solar Window Peak)</span>
          </div>
        </div>

        {/* BEFORE VS AFTER CARDS */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
          {/* BEFORE CARD */}
          <div className="rounded-xl border border-[#DDE2DE] bg-[#FFFFFF] p-4 sm:p-5 space-y-3">
            <div className="flex items-center justify-between pb-2 border-b border-[#DDE2DE]">
              <span className="text-xs font-mono uppercase tracking-wider font-bold text-[#8A918D]">
                Before (Immediate Execution)
              </span>
              <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-[#F7F8F5] text-[#68706B] border border-[#DDE2DE]">
                No Deferral
              </span>
            </div>

            <div className="space-y-2 text-xs">
              <div className="flex justify-between py-1 border-b border-[#F7F8F5]">
                <span className="text-[#68706B]">Execution Timing:</span>
                <span className="font-mono font-semibold text-[#0A0D0C]">Immediate (t = 320 ms)</span>
              </div>
              <div className="flex justify-between py-1 border-b border-[#F7F8F5]">
                <span className="text-[#68706B]">Regional Grid Intensity:</span>
                <span className="font-mono text-[#C0392B] font-semibold">{baseGridIntensity} gCO₂/kWh</span>
              </div>
              <div className="flex justify-between py-1 border-b border-[#F7F8F5]">
                <span className="text-[#68706B]">Task 4 Carbon:</span>
                <span className="font-mono font-bold text-[#0A0D0C]">{task4BaseCarbon} gCO₂e</span>
              </div>
              <div className="flex justify-between py-1 border-b border-[#F7F8F5]">
                <span className="text-[#68706B]">Workflow Latency:</span>
                <span className="font-mono text-[#0A0D0C]">1,520 ms</span>
              </div>
              <div className="flex justify-between py-1">
                <span className="text-[#68706B]">Deadline SLA:</span>
                <span className="font-mono text-[#007A52] font-semibold">Met (980 ms slack)</span>
              </div>
            </div>

            <p className="text-[11px] text-[#8A918D] italic pt-1">
              Naive execution runs during dirty grid window despite having 1,480ms surplus slack.
            </p>
          </div>

          {/* AFTER CARD */}
          <div className="rounded-xl border-2 border-[#00D98B] bg-[#FFFFFF] p-4 sm:p-5 space-y-3 shadow-xs">
            <div className="flex items-center justify-between pb-2 border-b border-[#C9EBDC]">
              <span className="text-xs font-mono uppercase tracking-wider font-bold text-[#007A52]">
                After (Solar-Shifted Deferral)
              </span>
              <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-[#E7F8F1] text-[#007A52] border border-[#C9EBDC] font-semibold">
                Shifted +{delaySeconds}s
              </span>
            </div>

            <div className="space-y-2 text-xs">
              <div className="flex justify-between py-1 border-b border-[#F7F8F5]">
                <span className="text-[#68706B]">Execution Timing:</span>
                <span className="font-mono font-semibold text-[#007A52]">Deferred to Solar Window</span>
              </div>
              <div className="flex justify-between py-1 border-b border-[#F7F8F5]">
                <span className="text-[#68706B]">Regional Grid Intensity:</span>
                <span className="font-mono text-[#007A52] font-semibold">{solarGridIntensity} gCO₂/kWh</span>
              </div>
              <div className="flex justify-between py-1 border-b border-[#F7F8F5]">
                <span className="text-[#68706B]">Task 4 Carbon:</span>
                <span className="font-mono font-bold text-[#007A52]">{task4OptimizedCarbon} gCO₂e</span>
              </div>
              <div className="flex justify-between py-1 border-b border-[#F7F8F5]">
                <span className="text-[#68706B]">Workflow Latency:</span>
                <span className="font-mono font-bold text-[#0A0D0C]">1,520 ms (Zero Change)</span>
              </div>
              <div className="flex justify-between py-1">
                <span className="text-[#68706B]">Deadline SLA:</span>
                <span className="font-mono text-[#007A52] font-semibold">Met (980 ms slack intact)</span>
              </div>
            </div>

            <p className="text-[11px] text-[#007A52] font-medium pt-1">
              Exploits non-critical branch slack. Shift drops grid carbon without touching critical path!
            </p>
          </div>
        </div>

        {/* ==================================================
            SHOW:
            Carbon impact
            Deadline impact
            ================================================== */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-2 border-t border-[#DDE2DE]">
          {/* Carbon Impact Card */}
          <div className="rounded-xl border border-[#C9EBDC] bg-[#E7F8F1] p-4 space-y-1">
            <div className="flex items-center justify-between">
              <span className="text-xs font-mono text-[#007A52] uppercase font-bold tracking-wider">
                Carbon Impact
              </span>
              <span className="text-xs font-mono font-bold text-[#007A52] bg-[#FFFFFF] px-2 py-0.5 rounded border border-[#C9EBDC]">
                -{carbonSavedPct}%
              </span>
            </div>
            <div className="text-2xl font-bold font-mono text-[#007A52]">
              -{carbonSavedGrams} gCO₂e Saved
            </div>
            <p className="text-xs text-[#007A52]">
              Emission reduction achieved purely through temporal slack deferral into clean solar hours.
            </p>
          </div>

          {/* Deadline Impact Card */}
          <div className="rounded-xl border border-[#DDE2DE] bg-[#FFFFFF] p-4 space-y-1">
            <div className="flex items-center justify-between">
              <span className="text-xs font-mono text-[#8A918D] uppercase font-bold tracking-wider">
                Deadline Impact
              </span>
              <span className="text-xs font-mono font-bold text-[#007A52] bg-[#E7F8F1] px-2 py-0.5 rounded border border-[#C9EBDC]">
                Zero SLA Impact
              </span>
            </div>
            <div className="text-2xl font-bold font-mono text-[#0A0D0C]">
              {deadlineImpactMs} ms Delta
            </div>
            <p className="text-xs text-[#68706B]">
              Critical path completion time (1,520 ms) remains completely unchanged. Deadline strictly satisfied.
            </p>
          </div>
        </div>
      </section>
    </div>
  );
};
