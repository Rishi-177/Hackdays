/**
 * CarbonPilot — Quality & Escalation Decision Page
 * Visual pipeline demonstrating confidence verification gates,
 * small model right-sizing, and targeted frontier escalation.
 */

import React, { useState } from 'react';
import {
  ShieldCheck,
  CheckCircle2,
  AlertTriangle,
  ArrowDown,
  ArrowRight,
  Cpu,
  Leaf,
  Clock,
  Sparkles,
  Layers,
  FileText,
  Sliders,
  ChevronRight,
  Info,
} from 'lucide-react';

interface TaskScenario {
  id: string;
  name: string;
  category: string;
  inputDescription: string;
  smallModel: string;
  smallModelConfidence: number;
  frontierModel: string;
  frontierConfidence: number;
  smallCarbon: number; // in gCO₂e
  frontierCarbon: number; // in gCO₂e
  smallLatency: number; // in ms
  frontierLatency: number; // in ms
  outputAccept: string;
  outputEscalate: string;
  rationale: {
    accept: string;
    escalate: string;
  };
}

const PRESET_SCENARIOS: TaskScenario[] = [
  {
    id: 'routine-clause',
    name: 'Standard Indemnity Clause Extraction',
    category: 'Contract Analysis',
    inputDescription: 'Extract liability caps and mutual indemnification terms from Section 14.2 of vendor MSA.',
    smallModel: 'Gemini 2.5 Flash (Small Model)',
    smallModelConfidence: 94.2,
    frontierModel: 'Gemini 2.5 Pro (Frontier Model)',
    frontierConfidence: 98.6,
    smallCarbon: 2.1,
    frontierCarbon: 14.9,
    smallLatency: 280,
    frontierLatency: 1100,
    outputAccept: 'Verified mutual $5M aggregate liability cap parsed with structured JSON schema. Grounding verified against paragraph 2.',
    outputEscalate: 'Deep contextual re-evaluation with multi-clause cross-reference and jurisdiction precedence analysis.',
    rationale: {
      accept: 'Small model confidence (94.2%) exceeds required quality (88.0%). Output accepted directly without frontier overhead.',
      escalate: 'Threshold raised above 95.0%. Routed to frontier model for zero-tolerance legal liability verification.',
    },
  },
  {
    id: 'ambiguous-ip',
    name: 'Cross-Border IP Warranty Analysis',
    category: 'Risk Assessment',
    inputDescription: 'Evaluate non-compete enforceability across EU GDPR and California Labor Code 16600.',
    smallModel: 'Gemini 2.5 Flash (Small Model)',
    smallModelConfidence: 81.4,
    frontierModel: 'Gemini 2.5 Pro (Frontier Model)',
    frontierConfidence: 97.8,
    smallCarbon: 2.4,
    frontierCarbon: 16.2,
    smallLatency: 310,
    frontierLatency: 1240,
    outputAccept: 'Preliminary clause summary with flagged uncertainty markers.',
    outputEscalate: 'Full statutory synthesis by Gemini 2.5 Pro: Identified severability clause exception and drafted mitigating rider.',
    rationale: {
      accept: 'Accepted under low-threshold testing mode. Not recommended for production audit.',
      escalate: 'Small model confidence (81.4%) fell below required threshold (88.0%). Escalated to Frontier model to prevent non-compliance penalty.',
    },
  },
  {
    id: 'entity-extraction',
    name: 'Multi-Party Regulatory Entity Disambiguation',
    category: 'Entity Triage',
    inputDescription: 'Resolve parent-subsidiary beneficial ownership from 18 scanned schedule exhibits.',
    smallModel: 'Gemini 2.5 Flash (Small Model)',
    smallModelConfidence: 91.8,
    frontierModel: 'Gemini 2.5 Pro (Frontier Model)',
    frontierConfidence: 98.2,
    smallCarbon: 1.8,
    frontierCarbon: 13.5,
    smallLatency: 240,
    frontierLatency: 980,
    outputAccept: 'Extracted 14 entity nodes with LEI identifiers matching SEC EDGAR filings.',
    outputEscalate: 'Frontier model cross-checks corporate registry history across foreign jurisdiction databases.',
    rationale: {
      accept: 'Confidence score (91.8%) safely exceeds required bar. Clean structured entities validated.',
      escalate: 'Confidence did not clear strict threshold; escalated to frontier model for disambiguation.',
    },
  },
];

export const QualityEscalationView: React.FC = () => {
  const [selectedScenarioId, setSelectedScenarioId] = useState<string>('routine-clause');
  const [requiredThreshold, setRequiredThreshold] = useState<number>(88.0);
  const [customConfidence, setCustomConfidence] = useState<number | null>(null);

  const scenario = PRESET_SCENARIOS.find((s) => s.id === selectedScenarioId) || PRESET_SCENARIOS[0];
  const activeConfidence = customConfidence !== null ? customConfidence : scenario.smallModelConfidence;

  // Primary decision condition:
  // High confidence -> accept
  // Low confidence -> escalate
  const isAccepted = activeConfidence >= requiredThreshold;
  const decision = isAccepted ? 'ACCEPT' : 'ESCALATE';

  // Metrics computation based on decision
  const activeModel = isAccepted ? scenario.smallModel : scenario.frontierModel;
  const finalConfidence = isAccepted ? activeConfidence : scenario.frontierConfidence;

  // Carbon Impact:
  // If accepted, compare small model consumption against naive frontier baseline
  // If escalated, show targeted carbon spend for frontier model vs small model
  const carbonImpactGrams = isAccepted
    ? -(scenario.frontierCarbon - scenario.smallCarbon)
    : +(scenario.frontierCarbon - scenario.smallCarbon);
  
  const latencyImpactMs = isAccepted
    ? -(scenario.frontierLatency - scenario.smallLatency)
    : +(scenario.frontierLatency - scenario.smallLatency);

  return (
    <div className="max-w-7xl mx-auto space-y-6 pb-12">
      {/* Header */}
      <header className="pb-4 border-b border-[#DDE2DE]">
        <div className="flex items-center gap-2 mb-1">
          <div className="w-6 h-6 rounded-md bg-[#E7F8F1] border border-[#C9EBDC] flex items-center justify-center text-[#007A52]">
            <ShieldCheck className="w-3.5 h-3.5" />
          </div>
          <span className="text-[11px] font-mono text-[#007A52] font-semibold tracking-wide uppercase">
            Decision Engine
          </span>
        </div>
        <h1 className="text-xl sm:text-2xl font-bold text-[#0A0D0C] tracking-tight">
          Quality &amp; Escalation
        </h1>
        <p className="text-xs sm:text-sm text-[#68706B] mt-1 max-w-3xl leading-relaxed">
          Dynamic quality gates evaluate small model outputs against required confidence thresholds. High confidence outputs are accepted immediately with 75–85% carbon savings, while uncertain outputs are selectively escalated to frontier models.
        </p>
      </header>

      {/* Interactive Scenario & Threshold Selector */}
      <div className="rounded-xl border border-[#DDE2DE] bg-[#FFFFFF] p-4 sm:p-5 shadow-xs space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div>
            <span className="text-xs font-bold text-[#0A0D0C] block">Select Benchmark Task</span>
            <span className="text-[11px] text-[#68706B]">Choose a scenario to inspect the automated decision flow</span>
          </div>

          {/* Scenario Buttons */}
          <div className="flex flex-wrap gap-2">
            {PRESET_SCENARIOS.map((s) => (
              <button
                key={s.id}
                onClick={() => {
                  setSelectedScenarioId(s.id);
                  setCustomConfidence(null);
                }}
                className={`px-3 py-1.5 rounded-lg text-xs font-medium border transition-colors cursor-pointer ${
                  selectedScenarioId === s.id && customConfidence === null
                    ? 'bg-[#00D98B] border-[#00D98B] text-[#0A0D0C] font-semibold'
                    : 'bg-[#FFFFFF] border-[#DDE2DE] text-[#68706B] hover:text-[#0A0D0C] hover:bg-[#F7F8F5]'
                }`}
              >
                {s.name}
              </button>
            ))}
          </div>
        </div>

        {/* Sliders: Required Threshold & Small Model Confidence */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 pt-3 border-t border-[#DDE2DE]">
          {/* Required Quality Threshold Slider */}
          <div className="p-3.5 rounded-lg border border-[#DDE2DE] bg-[#F7F8F5] space-y-2">
            <div className="flex items-center justify-between">
              <label className="text-xs font-semibold text-[#0A0D0C] flex items-center gap-1.5">
                <Sliders className="w-3.5 h-3.5 text-[#007A52]" />
                <span>Required Quality Threshold</span>
              </label>
              <span className="text-xs font-mono font-bold text-[#007A52] bg-[#E7F8F1] px-2 py-0.5 rounded border border-[#C9EBDC]">
                {requiredThreshold.toFixed(1)}%
              </span>
            </div>
            <input
              type="range"
              min={75}
              max={98}
              step={0.5}
              value={requiredThreshold}
              onChange={(e) => setRequiredThreshold(parseFloat(e.target.value))}
              className="w-full h-1.5 bg-[#DDE2DE] rounded-lg appearance-none cursor-pointer accent-[#007A52]"
            />
            <div className="flex justify-between text-[10px] font-mono text-[#8A918D]">
              <span>75.0% (Relaxed)</span>
              <span>88.0% (Standard)</span>
              <span>98.0% (Strict)</span>
            </div>
          </div>

          {/* Test Small Model Confidence Slider */}
          <div className="p-3.5 rounded-lg border border-[#DDE2DE] bg-[#F7F8F5] space-y-2">
            <div className="flex items-center justify-between">
              <label className="text-xs font-semibold text-[#0A0D0C] flex items-center gap-1.5">
                <Cpu className="w-3.5 h-3.5 text-[#007A52]" />
                <span>Small Model Output Confidence</span>
              </label>
              <span className="text-xs font-mono font-bold text-[#0A0D0C] bg-[#FFFFFF] px-2 py-0.5 rounded border border-[#DDE2DE]">
                {activeConfidence.toFixed(1)}%
              </span>
            </div>
            <input
              type="range"
              min={70}
              max={99}
              step={0.5}
              value={activeConfidence}
              onChange={(e) => setCustomConfidence(parseFloat(e.target.value))}
              className="w-full h-1.5 bg-[#DDE2DE] rounded-lg appearance-none cursor-pointer accent-[#00D98B]"
            />
            <div className="flex justify-between text-[10px] font-mono text-[#8A918D]">
              <span className="text-[#C0392B] font-semibold">Low confidence (&lt;88%)</span>
              <span className="text-[#007A52] font-semibold">High confidence (&ge;88%)</span>
            </div>
          </div>
        </div>
      </div>

      {/* ==================================================
          VISUAL PIPELINE:
          Task
          ↓
          Small Model
          ↓
          Quality Gate
          ↓
          Accept OR Escalate
          ↓
          Final Result
          ================================================== */}
      <section className="space-y-3">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-base sm:text-lg font-bold text-[#0A0D0C] tracking-tight">
              Visual Escalation Pipeline
            </h2>
            <p className="text-xs text-[#68706B]">
              Step-by-step verification pipeline focusing on the automated gating decision
            </p>
          </div>
          <span className="text-xs font-mono text-[#68706B] bg-[#F7F8F5] px-2.5 py-1 rounded border border-[#DDE2DE]">
            Pipeline Status: <strong className={isAccepted ? 'text-[#007A52]' : 'text-[#C0392B]'}>{decision}</strong>
          </span>
        </div>

        {/* Pipeline Container */}
        <div className="rounded-2xl border border-[#DDE2DE] bg-[#FFFFFF] p-6 shadow-xs">
          <div className="flex flex-col lg:flex-row items-stretch justify-between gap-4 relative">
            
            {/* 1. TASK */}
            <div className="flex-1 rounded-xl border border-[#DDE2DE] bg-[#F7F8F5] p-4 flex flex-col justify-between space-y-3">
              <div>
                <div className="flex items-center justify-between gap-2 mb-1.5">
                  <span className="text-[10px] font-mono uppercase tracking-wider text-[#8A918D]">Step 1</span>
                  <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-[#FFFFFF] border border-[#DDE2DE] text-[#68706B]">
                    {scenario.category}
                  </span>
                </div>
                <div className="flex items-center gap-2">
                  <FileText className="w-4 h-4 text-[#007A52] shrink-0" />
                  <h3 className="text-sm font-bold text-[#0A0D0C] leading-snug">
                    {scenario.name}
                  </h3>
                </div>
                <p className="text-xs text-[#68706B] mt-2 leading-relaxed">
                  {scenario.inputDescription}
                </p>
              </div>

              <div className="pt-2 border-t border-[#DDE2DE] text-[11px] font-mono text-[#8A918D]">
                Input Payload: 1,420 tokens
              </div>
            </div>

            {/* Pipeline Arrow 1 */}
            <div className="flex items-center justify-center text-[#8A918D] shrink-0 self-center">
              <ArrowDown className="w-5 h-5 lg:hidden text-[#007A52]" />
              <ArrowRight className="w-5 h-5 hidden lg:block text-[#007A52]" />
            </div>

            {/* 2. SMALL MODEL */}
            <div className="flex-1 rounded-xl border border-[#DDE2DE] bg-[#FFFFFF] p-4 flex flex-col justify-between space-y-3 shadow-2xs">
              <div>
                <div className="flex items-center justify-between gap-2 mb-1.5">
                  <span className="text-[10px] font-mono uppercase tracking-wider text-[#8A918D]">Step 2</span>
                  <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-[#E7F8F1] border border-[#C9EBDC] text-[#007A52] font-semibold">
                    Small Model
                  </span>
                </div>
                <div className="flex items-center gap-2">
                  <Cpu className="w-4 h-4 text-[#007A52] shrink-0" />
                  <h3 className="text-sm font-bold text-[#0A0D0C] leading-snug">
                    {scenario.smallModel}
                  </h3>
                </div>
                <p className="text-xs text-[#68706B] mt-2">
                  Fast, energy-efficient inference right-sized for routine extraction.
                </p>
              </div>

              <div className="pt-2 border-t border-[#DDE2DE] space-y-1 text-xs font-mono">
                <div className="flex justify-between text-[#68706B]">
                  <span>Raw Confidence:</span>
                  <strong className="text-[#0A0D0C]">{activeConfidence.toFixed(1)}%</strong>
                </div>
                <div className="flex justify-between text-[#68706B]">
                  <span>Footprint:</span>
                  <span className="text-[#007A52]">{scenario.smallCarbon} gCO₂e • {scenario.smallLatency}ms</span>
                </div>
              </div>
            </div>

            {/* Pipeline Arrow 2 */}
            <div className="flex items-center justify-center text-[#8A918D] shrink-0 self-center">
              <ArrowDown className="w-5 h-5 lg:hidden text-[#007A52]" />
              <ArrowRight className="w-5 h-5 hidden lg:block text-[#007A52]" />
            </div>

            {/* 3. QUALITY GATE */}
            <div className={`flex-1 rounded-xl border p-4 flex flex-col justify-between space-y-3 transition-colors ${
              isAccepted
                ? 'border-[#C9EBDC] bg-[#E7F8F1]/40'
                : 'border-[#F5B7B1] bg-[#FDEDEC]/40'
            }`}>
              <div>
                <div className="flex items-center justify-between gap-2 mb-1.5">
                  <span className="text-[10px] font-mono uppercase tracking-wider text-[#8A918D]">Step 3</span>
                  <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-[#FFFFFF] border border-[#DDE2DE] text-[#0A0D0C] font-semibold">
                    Quality Gate
                  </span>
                </div>
                <div className="flex items-center gap-2">
                  <ShieldCheck className="w-4 h-4 text-[#007A52] shrink-0" />
                  <h3 className="text-sm font-bold text-[#0A0D0C] leading-snug">
                    Grounding &amp; Verifier
                  </h3>
                </div>
                <div className="mt-2 text-xs space-y-1">
                  <div className="flex justify-between text-[#68706B]">
                    <span>Score vs Threshold:</span>
                    <span className="font-mono font-bold text-[#0A0D0C]">
                      {activeConfidence.toFixed(1)}% / {requiredThreshold.toFixed(1)}%
                    </span>
                  </div>
                  <div className="w-full bg-[#DDE2DE] h-1.5 rounded-full overflow-hidden">
                    <div
                      className={`h-full rounded-full ${isAccepted ? 'bg-[#00D98B]' : 'bg-[#C0392B]'}`}
                      style={{ width: `${Math.min(activeConfidence, 100)}%` }}
                    />
                  </div>
                </div>
              </div>

              <div className="pt-2 border-t border-[#DDE2DE] text-[11px] leading-snug">
                {isAccepted ? (
                  <span className="text-[#007A52] font-semibold flex items-center gap-1">
                    <CheckCircle2 className="w-3.5 h-3.5 shrink-0" />
                    High confidence &ge; {requiredThreshold}%
                  </span>
                ) : (
                  <span className="text-[#C0392B] font-semibold flex items-center gap-1">
                    <AlertTriangle className="w-3.5 h-3.5 shrink-0" />
                    Confidence deficit: -{(requiredThreshold - activeConfidence).toFixed(1)}%
                  </span>
                )}
              </div>
            </div>

            {/* Pipeline Arrow 3 */}
            <div className="flex items-center justify-center text-[#8A918D] shrink-0 self-center">
              <ArrowDown className="w-5 h-5 lg:hidden text-[#007A52]" />
              <ArrowRight className="w-5 h-5 hidden lg:block text-[#007A52]" />
            </div>

            {/* 4. ACCEPT OR ESCALATE (THE FOCUS) */}
            <div className={`flex-1 rounded-xl border-2 p-4 flex flex-col justify-between space-y-3 relative shadow-sm ${
              isAccepted
                ? 'border-[#00D98B] bg-[#FFFFFF]'
                : 'border-[#C0392B] bg-[#FFFFFF]'
            }`}>
              <div className="absolute -top-3 left-4 px-2 py-0.5 rounded-md text-[10px] font-mono font-bold tracking-wider uppercase bg-[#0A0D0C] text-[#FFFFFF]">
                Gating Decision
              </div>

              <div>
                <div className="flex items-center justify-between gap-2 mt-1 mb-2">
                  <span className="text-[10px] font-mono uppercase tracking-wider text-[#8A918D]">Step 4</span>
                  <span className={`text-[11px] font-mono px-2.5 py-1 rounded-md font-bold ${
                    isAccepted
                      ? 'bg-[#E7F8F1] text-[#007A52] border border-[#C9EBDC]'
                      : 'bg-[#FDEDEC] text-[#C0392B] border border-[#F5B7B1]'
                  }`}>
                    {decision === 'ACCEPT' ? '✓ ACCEPT SMALL MODEL' : '⚡ ESCALATE TO FRONTIER'}
                  </span>
                </div>

                <div className="space-y-1.5">
                  <div className="text-xs font-semibold text-[#0A0D0C]">
                    {isAccepted ? 'High confidence → accept' : 'Low confidence → escalate'}
                  </div>
                  <p className="text-[11px] text-[#68706B] leading-relaxed">
                    {isAccepted ? scenario.rationale.accept : scenario.rationale.escalate}
                  </p>
                </div>
              </div>

              <div className="pt-2 border-t border-[#DDE2DE] space-y-1 text-[11px] font-mono">
                <div className="flex justify-between">
                  <span className="text-[#68706B]">Carbon Impact:</span>
                  <span className={`font-semibold ${isAccepted ? 'text-[#007A52]' : 'text-[#C0392B]'}`}>
                    {isAccepted ? `${carbonImpactGrams.toFixed(1)} gCO₂e (Saved)` : `+${carbonImpactGrams.toFixed(1)} gCO₂e (Targeted)`}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-[#68706B]">Latency Impact:</span>
                  <span className={`font-semibold ${isAccepted ? 'text-[#007A52]' : 'text-[#C0392B]'}`}>
                    {isAccepted ? `${latencyImpactMs} ms (Saved)` : `+${latencyImpactMs} ms`}
                  </span>
                </div>
              </div>
            </div>

            {/* Pipeline Arrow 4 */}
            <div className="flex items-center justify-center text-[#8A918D] shrink-0 self-center">
              <ArrowDown className="w-5 h-5 lg:hidden text-[#007A52]" />
              <ArrowRight className="w-5 h-5 hidden lg:block text-[#007A52]" />
            </div>

            {/* 5. FINAL RESULT */}
            <div className="flex-1 rounded-xl border border-[#DDE2DE] bg-[#F7F8F5] p-4 flex flex-col justify-between space-y-3">
              <div>
                <div className="flex items-center justify-between gap-2 mb-1.5">
                  <span className="text-[10px] font-mono uppercase tracking-wider text-[#8A918D]">Step 5</span>
                  <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-[#FFFFFF] border border-[#DDE2DE] text-[#0A0D0C] font-semibold">
                    Final Result
                  </span>
                </div>
                <div className="flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 text-[#00D98B] shrink-0" />
                  <h3 className="text-sm font-bold text-[#0A0D0C] leading-snug">
                    Verified Execution
                  </h3>
                </div>
                <p className="text-xs text-[#68706B] mt-2 leading-relaxed">
                  {isAccepted ? scenario.outputAccept : scenario.outputEscalate}
                </p>
              </div>

              <div className="pt-2 border-t border-[#DDE2DE] text-[11px] font-mono text-[#007A52] font-semibold">
                Delivered with {finalConfidence.toFixed(1)}% verified confidence
              </div>
            </div>

          </div>
        </div>
      </section>

      {/* ==================================================
          DECISION FOCUS SUMMARY CARDS
          Model
          Confidence
          Required Quality
          Decision
          Carbon Impact
          Latency Impact
          ================================================== */}
      <section className="space-y-3">
        <h2 className="text-base sm:text-lg font-bold text-[#0A0D0C] tracking-tight">
          Decision Telemetry
        </h2>

        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3">
          {/* 1. Model */}
          <div className="rounded-xl border border-[#DDE2DE] bg-[#FFFFFF] p-3.5 shadow-xs space-y-1">
            <span className="text-[11px] font-mono text-[#8A918D] uppercase tracking-wider block">
              Model
            </span>
            <span className="text-xs sm:text-sm font-bold text-[#0A0D0C] block truncate" title={activeModel}>
              {isAccepted ? 'Gemini 2.5 Flash' : 'Gemini 2.5 Pro'}
            </span>
            <span className="text-[10px] font-mono text-[#68706B] block">
              {isAccepted ? 'Small Tier' : 'Frontier Tier'}
            </span>
          </div>

          {/* 2. Confidence */}
          <div className="rounded-xl border border-[#DDE2DE] bg-[#FFFFFF] p-3.5 shadow-xs space-y-1">
            <span className="text-[11px] font-mono text-[#8A918D] uppercase tracking-wider block">
              Confidence
            </span>
            <span className="text-xs sm:text-sm font-bold text-[#0A0D0C] block">
              {activeConfidence.toFixed(1)}%
            </span>
            <span className={`text-[10px] font-mono font-semibold block ${isAccepted ? 'text-[#007A52]' : 'text-[#C0392B]'}`}>
              {isAccepted ? 'Above threshold' : 'Below threshold'}
            </span>
          </div>

          {/* 3. Required Quality */}
          <div className="rounded-xl border border-[#DDE2DE] bg-[#FFFFFF] p-3.5 shadow-xs space-y-1">
            <span className="text-[11px] font-mono text-[#8A918D] uppercase tracking-wider block">
              Required Quality
            </span>
            <span className="text-xs sm:text-sm font-bold text-[#0A0D0C] block">
              {requiredThreshold.toFixed(1)}%
            </span>
            <span className="text-[10px] font-mono text-[#68706B] block">
              SLA Standard
            </span>
          </div>

          {/* 4. Decision */}
          <div className={`rounded-xl border p-3.5 shadow-xs space-y-1 ${
            isAccepted ? 'border-[#C9EBDC] bg-[#E7F8F1]' : 'border-[#F5B7B1] bg-[#FDEDEC]'
          }`}>
            <span className="text-[11px] font-mono text-[#8A918D] uppercase tracking-wider block">
              Decision
            </span>
            <span className={`text-xs sm:text-sm font-bold block ${isAccepted ? 'text-[#007A52]' : 'text-[#C0392B]'}`}>
              {decision}
            </span>
            <span className="text-[10px] font-mono text-[#68706B] block">
              {isAccepted ? 'Small Model' : 'Frontier Gate'}
            </span>
          </div>

          {/* 5. Carbon Impact */}
          <div className="rounded-xl border border-[#DDE2DE] bg-[#FFFFFF] p-3.5 shadow-xs space-y-1">
            <span className="text-[11px] font-mono text-[#8A918D] uppercase tracking-wider block">
              Carbon Impact
            </span>
            <span className={`text-xs sm:text-sm font-bold block ${isAccepted ? 'text-[#007A52]' : 'text-[#C0392B]'}`}>
              {isAccepted ? `${carbonImpactGrams.toFixed(1)} gCO₂e` : `+${carbonImpactGrams.toFixed(1)} gCO₂e`}
            </span>
            <span className="text-[10px] font-mono text-[#68706B] block">
              {isAccepted ? '-85% vs Frontier' : 'Selective spend'}
            </span>
          </div>

          {/* 6. Latency Impact */}
          <div className="rounded-xl border border-[#DDE2DE] bg-[#FFFFFF] p-3.5 shadow-xs space-y-1">
            <span className="text-[11px] font-mono text-[#8A918D] uppercase tracking-wider block">
              Latency Impact
            </span>
            <span className={`text-xs sm:text-sm font-bold block ${isAccepted ? 'text-[#007A52]' : 'text-[#C0392B]'}`}>
              {isAccepted ? `${latencyImpactMs} ms` : `+${latencyImpactMs} ms`}
            </span>
            <span className="text-[10px] font-mono text-[#68706B] block">
              {isAccepted ? '-74% execution time' : 'Within slack'}
            </span>
          </div>
        </div>
      </section>

      {/* Decision Log of Recent Automated Executions */}
      <section className="space-y-3">
        <h2 className="text-base sm:text-lg font-bold text-[#0A0D0C] tracking-tight">
          Historical Quality Decisions Log
        </h2>

        <div className="rounded-xl border border-[#DDE2DE] bg-[#FFFFFF] overflow-hidden shadow-xs">
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs border-collapse">
              <thead>
                <tr className="border-b border-[#DDE2DE] bg-[#F7F8F5] text-[#68706B] font-mono">
                  <th className="py-2.5 px-4 font-medium">Task</th>
                  <th className="py-2.5 px-4 font-medium">Initial Model</th>
                  <th className="py-2.5 px-4 font-medium">Confidence</th>
                  <th className="py-2.5 px-4 font-medium">Required</th>
                  <th className="py-2.5 px-4 font-medium">Decision</th>
                  <th className="py-2.5 px-4 font-medium">Final Model</th>
                  <th className="py-2.5 px-4 font-medium">Carbon Impact</th>
                  <th className="py-2.5 px-4 font-medium">Latency</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#DDE2DE] text-[#0A0D0C]">
                <tr>
                  <td className="py-3 px-4 font-medium">Doc Triage &amp; Routing</td>
                  <td className="py-3 px-4 font-mono text-[#68706B]">Gemini 2.5 Flash</td>
                  <td className="py-3 px-4 font-mono text-[#007A52] font-semibold">96.0%</td>
                  <td className="py-3 px-4 font-mono text-[#8A918D]">85.0%</td>
                  <td className="py-3 px-4">
                    <span className="px-2 py-0.5 rounded bg-[#E7F8F1] text-[#007A52] border border-[#C9EBDC] font-mono font-bold text-[11px]">
                      ACCEPT
                    </span>
                  </td>
                  <td className="py-3 px-4 font-mono text-[#68706B]">Gemini 2.5 Flash</td>
                  <td className="py-3 px-4 font-mono text-[#007A52] font-semibold">-12.8 gCO₂e</td>
                  <td className="py-3 px-4 font-mono text-[#68706B]">280 ms</td>
                </tr>

                <tr>
                  <td className="py-3 px-4 font-medium">Cross-Border Indemnity (Clause 14)</td>
                  <td className="py-3 px-4 font-mono text-[#68706B]">Gemini 2.5 Flash</td>
                  <td className="py-3 px-4 font-mono text-[#C0392B] font-semibold">84.0%</td>
                  <td className="py-3 px-4 font-mono text-[#8A918D]">90.0%</td>
                  <td className="py-3 px-4">
                    <span className="px-2 py-0.5 rounded bg-[#FDEDEC] text-[#C0392B] border border-[#F5B7B1] font-mono font-bold text-[11px]">
                      ESCALATE
                    </span>
                  </td>
                  <td className="py-3 px-4 font-mono text-[#0A0D0C] font-semibold">Gemini 2.5 Pro</td>
                  <td className="py-3 px-4 font-mono text-[#C0392B] font-semibold">+4.2 gCO₂e</td>
                  <td className="py-3 px-4 font-mono text-[#68706B]">820 ms</td>
                </tr>

                <tr>
                  <td className="py-3 px-4 font-medium">Contextual Policy Retrieval</td>
                  <td className="py-3 px-4 font-mono text-[#68706B]">Gemini 2.5 Flash</td>
                  <td className="py-3 px-4 font-mono text-[#007A52] font-semibold">92.4%</td>
                  <td className="py-3 px-4 font-mono text-[#8A918D]">88.0%</td>
                  <td className="py-3 px-4">
                    <span className="px-2 py-0.5 rounded bg-[#E7F8F1] text-[#007A52] border border-[#C9EBDC] font-mono font-bold text-[11px]">
                      ACCEPT
                    </span>
                  </td>
                  <td className="py-3 px-4 font-mono text-[#68706B]">Gemini 2.5 Flash</td>
                  <td className="py-3 px-4 font-mono text-[#007A52] font-semibold">-11.4 gCO₂e</td>
                  <td className="py-3 px-4 font-mono text-[#68706B]">210 ms</td>
                </tr>

                <tr>
                  <td className="py-3 px-4 font-medium">Audit Ledger Certification</td>
                  <td className="py-3 px-4 font-mono text-[#68706B]">Deterministic Engine</td>
                  <td className="py-3 px-4 font-mono text-[#007A52] font-semibold">99.9%</td>
                  <td className="py-3 px-4 font-mono text-[#8A918D]">95.0%</td>
                  <td className="py-3 px-4">
                    <span className="px-2 py-0.5 rounded bg-[#E7F8F1] text-[#007A52] border border-[#C9EBDC] font-mono font-bold text-[11px]">
                      ACCEPT
                    </span>
                  </td>
                  <td className="py-3 px-4 font-mono text-[#68706B]">Deterministic Engine</td>
                  <td className="py-3 px-4 font-mono text-[#007A52] font-semibold">-14.2 gCO₂e</td>
                  <td className="py-3 px-4 font-mono text-[#68706B]">160 ms</td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>
      </section>
    </div>
  );
};
