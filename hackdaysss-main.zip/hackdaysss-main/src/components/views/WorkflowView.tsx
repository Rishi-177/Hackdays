import React, { useState } from 'react';
import {
  INITIAL_WORKFLOW_NODES,
  INITIAL_WORKFLOW_EDGES,
  OPTIMIZATION_DECISIONS,
  DetailedWorkflowNode,
  DetailedWorkflowEdge,
} from '../workflow/workflowData';
import { WorkflowDagCanvas } from '../workflow/WorkflowDagCanvas';
import { WorkflowSummaryPanel } from '../workflow/WorkflowSummaryPanel';
import { SelectedNodeWhyPanel } from '../workflow/SelectedNodeWhyPanel';
import { OptimizationSimulationModal } from '../workflow/OptimizationSimulationModal';
import {
  GitMerge,
  Sparkles,
  CheckCircle2,
  Sliders,
  PanelRightClose,
  PanelRightOpen,
  ArrowRight,
  ShieldCheck,
  Leaf,
  Clock,
} from 'lucide-react';

export interface WorkflowViewProps {
  onNavigateToDesignSystem?: () => void;
}

export const WorkflowView: React.FC<WorkflowViewProps> = () => {
  // DAG State
  const [nodes, setNodes] = useState<DetailedWorkflowNode[]>(INITIAL_WORKFLOW_NODES);
  const [edges] = useState<DetailedWorkflowEdge[]>(INITIAL_WORKFLOW_EDGES);
  const [selectedNode, setSelectedNode] = useState<DetailedWorkflowNode | null>(
    INITIAL_WORKFLOW_NODES[0] // Pre-select first task so the Why Panel is immediately visible and useful
  );
  const [highlightCriticalPath, setHighlightCriticalPath] = useState<boolean>(true);
  const [isSidePanelOpen, setIsSidePanelOpen] = useState<boolean>(true);

  // Workflow Summary State (updates on optimization)
  const [metrics, setMetrics] = useState({
    carbonGrams: 24.9,
    workflowTimeSeconds: 1.52,
    qualityPercent: 94.6,
    budgetGrams: 50.0,
    consumedBudgetGrams: 24.9,
    deadlineMs: 2500,
    slackMs: 980,
  });

  // Optimization Simulation State
  const [isOptimizationModalOpen, setIsOptimizationModalOpen] = useState<boolean>(false);
  const [isOptimizingVisual, setIsOptimizingVisual] = useState<boolean>(false);
  const [lastOptimizedAt, setLastOptimizedAt] = useState<string>('Just now');
  const [justOptimizedBanner, setJustOptimizedBanner] = useState<boolean>(false);

  // Handle clicking "Optimize Workflow"
  const handleStartOptimization = () => {
    setIsOptimizationModalOpen(true);
  };

  // When optimization sequence completes
  const handleOptimizationComplete = () => {
    setIsOptimizationModalOpen(false);
    setIsOptimizingVisual(true);

    // Visually update the workflow with re-calculated optimal execution values
    setTimeout(() => {
      setMetrics({
        carbonGrams: 23.8, // subtle improvement after whole-workflow constraint evaluation
        workflowTimeSeconds: 1.48,
        qualityPercent: 95.1,
        budgetGrams: 50.0,
        consumedBudgetGrams: 23.8,
        deadlineMs: 2500,
        slackMs: 1020,
      });

      // Flash visual update across nodes
      setNodes((prevNodes) =>
        prevNodes.map((n) => ({
          ...n,
          status: n.id === 'node-doc-analysis' ? 'completed' : n.status,
        }))
      );

      setIsOptimizingVisual(false);
      setJustOptimizedBanner(true);
      setLastOptimizedAt('Just now');

      // Auto-dismiss the success banner after 4 seconds
      setTimeout(() => {
        setJustOptimizedBanner(false);
      }, 4000);
    }, 400);
  };

  const handleSelectNode = (node: DetailedWorkflowNode) => {
    setSelectedNode(node);
    if (!isSidePanelOpen) {
      setIsSidePanelOpen(true);
    }
  };

  const handleSelectNodeById = (nodeId?: string) => {
    if (!nodeId) return;
    const found = nodes.find((n) => n.id === nodeId);
    if (found) {
      setSelectedNode(found);
      setIsSidePanelOpen(true);
    }
  };

  return (
    <div className="max-w-7xl mx-auto space-y-6 pb-12">
      {/* ==================================================
          PAGE HEADER & PRIMARY ACTION
          Answers: "How is CarbonPilot optimizing the entire workflow?"
          Primary action: Optimize Workflow
          ================================================== */}
      <header className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 pb-2 border-b border-[#DDE2DE]">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <div className="w-6 h-6 rounded-md bg-[#E7F8F1] border border-[#C9EBDC] flex items-center justify-center text-[#007A52]">
              <GitMerge className="w-3.5 h-3.5" />
            </div>
            <span className="text-[11px] font-mono text-[#007A52] font-semibold tracking-wide uppercase">
              Whole-Workflow DAG
            </span>
            <span className="text-[#8A918D]">•</span>
            <span className="text-[11px] font-mono text-[#68706B]">
              Last scheduled: {lastOptimizedAt}
            </span>
          </div>

          <h1 className="text-xl sm:text-2xl font-bold text-[#0A0D0C] tracking-tight">
            Workflow Optimization
          </h1>
          <p className="text-xs sm:text-sm text-[#68706B] mt-0.5 max-w-2xl">
            Inspect how CarbonPilot dynamically balances model selection, carbon budgets, deadline slack, and quality thresholds across the entire DAG.
          </p>
        </div>

        {/* Primary Action Button */}
        <div className="flex items-center gap-2">
          <button
            onClick={() => setIsSidePanelOpen(!isSidePanelOpen)}
            className="p-2 rounded-xl border border-[#DDE2DE] bg-[#FFFFFF] hover:bg-[#F7F8F5] text-[#68706B] hover:text-[#0A0D0C] transition-colors cursor-pointer hidden lg:flex items-center gap-1.5 text-xs font-medium"
            title={isSidePanelOpen ? 'Collapse side panel' : 'Expand side panel'}
          >
            {isSidePanelOpen ? (
              <>
                <PanelRightClose className="w-4 h-4" />
                <span>Hide Details</span>
              </>
            ) : (
              <>
                <PanelRightOpen className="w-4 h-4" />
                <span>Show Details</span>
              </>
            )}
          </button>

          <button
            onClick={handleStartOptimization}
            className="flex items-center justify-center gap-2 px-4 py-2.5 rounded-xl bg-[#00D98B] hover:bg-[#00c57d] text-[#0A0D0C] font-semibold text-xs sm:text-sm transition-all shadow-xs hover:shadow-sm cursor-pointer shrink-0"
          >
            <Sparkles className="w-4 h-4 text-[#0A0D0C]" />
            <span>Optimize Workflow</span>
          </button>
        </div>
      </header>

      {/* Just-Optimized Notification Banner */}
      {justOptimizedBanner && (
        <div className="p-3 rounded-xl bg-[#E7F8F1] border border-[#00D98B] flex items-center justify-between text-xs text-[#007A52] shadow-2xs animate-in fade-in slide-in-from-top-1">
          <div className="flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 text-[#00D98B] shrink-0" />
            <span className="font-semibold">
              Workflow re-optimized successfully: Execution plan updated with 1.48s wall-clock time and 23.8 gCO₂e total footprint.
            </span>
          </div>
          <button
            onClick={() => setJustOptimizedBanner(false)}
            className="text-[11px] font-mono text-[#007A52] hover:underline cursor-pointer"
          >
            Dismiss
          </button>
        </div>
      )}

      {/* ==================================================
          PURPOSE SECTION
          Answers: "How is CarbonPilot optimizing the entire workflow?"
          ================================================== */}
      <section className="rounded-xl border border-[#DDE2DE] bg-[#FFFFFF] p-4 sm:p-5 shadow-xs space-y-3">
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2">
          <div className="flex items-center gap-2">
            <div className="w-6 h-6 rounded-md bg-[#E7F8F1] border border-[#C9EBDC] flex items-center justify-center text-[#007A52] shrink-0">
              <Sparkles className="w-3.5 h-3.5 text-[#00D98B]" />
            </div>
            <h2 className="text-sm sm:text-base font-bold text-[#0A0D0C]">
              How is CarbonPilot optimizing the entire workflow?
            </h2>
          </div>
          <span className="text-[11px] font-mono text-[#007A52] bg-[#E7F8F1] px-2.5 py-0.5 rounded-full border border-[#C9EBDC] font-semibold w-fit">
            Whole-Workflow Policy &amp; Constraint Engine
          </span>
        </div>

        <p className="text-xs text-[#68706B] leading-relaxed">
          Unlike static single-prompt routing, CarbonPilot evaluates the entire DAG as a unified constraint optimization problem:
        </p>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-2.5 text-xs">
          <div className="p-2.5 rounded-lg border border-[#DDE2DE] bg-[#F7F8F5] space-y-1">
            <div className="flex items-center gap-1.5 font-bold text-[#0A0D0C]">
              <span className="w-1.5 h-1.5 rounded-full bg-[#00D98B]" />
              <span>Right-Sized Models</span>
            </div>
            <p className="text-[#68706B] text-[11px] leading-snug">
              Routes routine tasks to small models when predicted confidence exceeds quality gates.
            </p>
          </div>

          <div className="p-2.5 rounded-lg border border-[#DDE2DE] bg-[#F7F8F5] space-y-1">
            <div className="flex items-center gap-1.5 font-bold text-[#0A0D0C]">
              <span className="w-1.5 h-1.5 rounded-full bg-[#F39C12]" />
              <span>Clean Grid Deferrals</span>
            </div>
            <p className="text-[#68706B] text-[11px] leading-snug">
              Defers non-critical tasks (Task 4) into solar/wind peak windows using deadline slack.
            </p>
          </div>

          <div className="p-2.5 rounded-lg border border-[#DDE2DE] bg-[#F7F8F5] space-y-1">
            <div className="flex items-center gap-1.5 font-bold text-[#0A0D0C]">
              <span className="w-1.5 h-1.5 rounded-full bg-[#007A52]" />
              <span>Early Quality Verification</span>
            </div>
            <p className="text-[#68706B] text-[11px] leading-snug">
              Halts ungrounded outputs at Stage 3 gate before triggering high-emission frontier loops.
            </p>
          </div>

          <div className="p-2.5 rounded-lg border border-[#DDE2DE] bg-[#F7F8F5] space-y-1">
            <div className="flex items-center gap-1.5 font-bold text-[#0A0D0C]">
              <span className="w-1.5 h-1.5 rounded-full bg-[#E74C3C]" />
              <span>Selective Escalation</span>
            </div>
            <p className="text-[#68706B] text-[11px] leading-snug">
              Reserves frontier GPU compute exclusively for high-risk legal clauses and executive synthesis.
            </p>
          </div>
        </div>
      </section>

      {/* ==================================================
          MAIN AREA: LARGE WORKFLOW DAG & SIDE PANEL
          Main area: Large workflow DAG
          Side panel: Selected Node Details (Why Panel)
          ================================================== */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-5 items-start">
        {/* Main Area: Large Workflow DAG (spans 8 or 12 cols depending on side panel) */}
        <div className={isSidePanelOpen ? 'lg:col-span-8 space-y-3' : 'lg:col-span-12 space-y-3'}>
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-sm font-bold text-[#0A0D0C]">
                Dependency Graph (DAG)
              </h2>
              <p className="text-xs text-[#68706B]">
                Default nodes display Task, Model, and Status. Click any node to reveal full telemetry in the side panel.
              </p>
            </div>
            {!isSidePanelOpen && (
              <button
                onClick={() => setIsSidePanelOpen(true)}
                className="text-xs font-semibold text-[#007A52] hover:underline flex items-center gap-1 cursor-pointer"
              >
                <span>Inspect selected node</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            )}
          </div>

          <WorkflowDagCanvas
            nodes={nodes}
            edges={edges}
            selectedNodeId={selectedNode?.id || null}
            onSelectNode={handleSelectNode}
            highlightCriticalPath={highlightCriticalPath}
            onToggleCriticalPath={() => setHighlightCriticalPath(!highlightCriticalPath)}
            isOptimizing={isOptimizingVisual}
          />
        </div>

        {/* Side Panel: Selected Node Details & Why Panel */}
        {isSidePanelOpen && (
          <div className="lg:col-span-4 h-[520px] sm:h-[580px] rounded-2xl border border-[#DDE2DE] overflow-hidden shadow-xs">
            <SelectedNodeWhyPanel
              node={selectedNode}
              onClose={() => setIsSidePanelOpen(false)}
              onSelectNodeById={handleSelectNodeById}
              allNodes={nodes}
            />
          </div>
        )}
      </div>

      {/* ==================================================
          SECONDARY AREA: WORKFLOW SUMMARY
          Show: Carbon, Workflow Time, Quality, Budget, Deadline
          Then: "Optimization Decisions"
          ================================================== */}
      <div className="pt-4 border-t border-[#DDE2DE]">
        <WorkflowSummaryPanel
          carbonGrams={metrics.carbonGrams}
          workflowTimeSeconds={metrics.workflowTimeSeconds}
          qualityPercent={metrics.qualityPercent}
          budgetGrams={metrics.budgetGrams}
          consumedBudgetGrams={metrics.consumedBudgetGrams}
          deadlineMs={metrics.deadlineMs}
          slackMs={metrics.slackMs}
          decisions={OPTIMIZATION_DECISIONS}
          onSelectDecisionNode={handleSelectNodeById}
        />
      </div>

      {/* ==================================================
          SIMULATED OPTIMIZATION PROCESS MODAL
          Analyzing workflow → evaluating models → evaluating constraints → selecting execution plan → optimized
          ================================================== */}
      <OptimizationSimulationModal
        isOpen={isOptimizationModalOpen}
        onComplete={handleOptimizationComplete}
        onClose={() => setIsOptimizationModalOpen(false)}
      />
    </div>
  );
};
