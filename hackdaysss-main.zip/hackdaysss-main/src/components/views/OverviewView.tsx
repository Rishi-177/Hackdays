import React, { useState } from 'react';
import {
  Workflow,
  WorkflowNode,
  WorkflowMetrics,
  CarbonBudget,
  BaselineComparison,
  NavigationTabId,
} from '../../types';
import {
  Leaf,
  Clock,
  ShieldCheck,
  CheckCircle2,
  ArrowRight,
  Sparkles,
  TrendingDown,
  Layers,
  ArrowDownRight,
  Scale,
  Cpu,
  Sliders,
} from 'lucide-react';
import { WorkflowNodeCard } from '../design-system/WorkflowNodeCard';
import { Drawer } from '../design-system/Drawer';

export interface OverviewViewProps {
  workflow: Workflow;
  metrics: WorkflowMetrics;
  budget: CarbonBudget;
  baseline: BaselineComparison;
  onNavigateToDesignSystem?: () => void;
  onNavigateTab?: (tab: NavigationTabId) => void;
  onTriggerSchedulerRun?: () => void;
  isRunningScheduler?: boolean;
}

export const OverviewView: React.FC<OverviewViewProps> = ({
  workflow,
  metrics,
  budget,
  onNavigateTab,
  onTriggerSchedulerRun,
  isRunningScheduler,
}) => {
  const [selectedNode, setSelectedNode] = useState<WorkflowNode | null>(null);
  const [isDrawerOpen, setIsDrawerOpen] = useState(false);

  // Workflow nodes categorized into clean DAG stages
  // Ensuring the requested "Task 4 (Delayed)" example is explicitly represented
  const allNodes: WorkflowNode[] = [
    {
      id: 'task-1-analysis',
      name: 'Document Analysis',
      type: 'triage',
      status: 'completed',
      model: 'Small Model (Gemini 2.5 Flash)',
      modelTier: 'small',
      estimatedLatencyMs: 190,
      estimatedCarbonGrams: 1.4,
      estimatedCostUsd: 0.00025,
      qualityConfidence: 96,
      requiredQualityThreshold: 85,
      priority: 'high',
      deadlineMs: 3000,
      slackMs: 1400,
      dependencies: [],
      decisionReason: {
        headline: 'Small Model selected because predicted confidence exceeded required quality threshold.',
        explanation: 'Confidence score (96%) comfortably exceeded the 85% requirement. Routing to a small model reduced carbon emissions by 78% compared to frontier models with zero SLA delay.',
        tradeOffs: 'Negligible variance in classification accuracy (+0.2% vs Gemini Pro), saving 5.8 gCO₂e.',
        confidenceScore: 96,
        policyTriggered: 'Policy CP-OPT-01: Cost & Carbon Pre-Filter',
      },
    },
    {
      id: 'task-2-retrieval',
      name: 'Contextual Policy Retrieval',
      type: 'retrieval',
      status: 'completed',
      model: 'Small Model (Flash Ranker)',
      modelTier: 'small',
      estimatedLatencyMs: 320,
      estimatedCarbonGrams: 2.1,
      estimatedCostUsd: 0.00042,
      qualityConfidence: 92,
      requiredQualityThreshold: 88,
      priority: 'medium',
      deadlineMs: 2800,
      slackMs: 980,
      dependencies: ['Document Analysis'],
      decisionReason: {
        headline: 'Filtered with low-power vector retrieval',
        explanation: 'Ranked regulatory guidelines using low-power semantic vectors rather than brute-force LLM context expansion.',
        tradeOffs: 'Saved 250k token context loading on downstream nodes.',
        confidenceScore: 92,
        policyTriggered: 'Policy CP-RET-04: Carbon-Aware Chunk Filtering',
      },
    },
    {
      id: 'task-3-extraction',
      name: 'Multimodal Contract Extraction',
      type: 'generation',
      status: 'completed',
      model: 'Small Model (Gemini 2.5 Flash)',
      modelTier: 'small',
      estimatedLatencyMs: 640,
      estimatedCarbonGrams: 6.8,
      estimatedCostUsd: 0.0018,
      qualityConfidence: 89,
      requiredQualityThreshold: 85,
      priority: 'high',
      deadlineMs: 2400,
      slackMs: 620,
      dependencies: ['Document Analysis'],
      decisionReason: {
        headline: 'Flash Vision Model Selected',
        explanation: 'Clause layout and table structure parsed accurately using small model vision capabilities without frontier GPU overhead.',
        tradeOffs: 'Extraction accuracy 89% vs 91% on Ultra, comfortably within safety tolerance.',
        confidenceScore: 89,
        policyTriggered: 'Policy CP-GEN-02: Structured Extraction Allocation',
      },
    },
    {
      id: 'task-4-delay',
      name: 'Task 4: Compliance Audit Batch',
      type: 'action',
      status: 'delayed',
      model: 'Small Model (Batch Engine)',
      modelTier: 'small',
      estimatedLatencyMs: 420,
      estimatedCarbonGrams: 0.3,
      estimatedCostUsd: 0.00008,
      qualityConfidence: 99,
      requiredQualityThreshold: 95,
      priority: 'low',
      deadlineMs: 3000,
      slackMs: 1400,
      dependencies: ['Document Analysis'],
      decisionReason: {
        headline: 'Task has sufficient deadline slack (+1,400 ms)',
        explanation: 'Delayed execution by 45 seconds to align with an incoming solar generation window on the regional grid, cutting grid marginal intensity from 340 to 180 gCO₂/kWh.',
        tradeOffs: 'Execution deferred without impacting overall critical path delivery.',
        confidenceScore: 99,
        policyTriggered: 'Policy CP-SLACK-02: Clean-Window Deferral',
      },
    },
    {
      id: 'task-5-gate',
      name: 'Quality Gate & Hallucination Guard',
      type: 'verifier',
      status: 'completed',
      model: 'Small Model (Cross-Verifier)',
      modelTier: 'small',
      estimatedLatencyMs: 240,
      estimatedCarbonGrams: 1.9,
      estimatedCostUsd: 0.00035,
      qualityConfidence: 94.2,
      requiredQualityThreshold: 92,
      priority: 'critical',
      deadlineMs: 1800,
      slackMs: 440,
      dependencies: ['Contextual Policy Retrieval', 'Multimodal Contract Extraction'],
      decisionReason: {
        headline: 'Quality gate passed — confidence exceeded threshold',
        explanation: 'Verified factual grounding with 94.2% confidence against retrieved regulatory clauses. Safely passed without triggering costly frontier model escalation.',
        tradeOffs: 'Small 240ms gate check prevented multi-step rework loops.',
        confidenceScore: 94.2,
        policyTriggered: 'Policy CP-QG-01: Quality Assurance Guard',
      },
    },
    {
      id: 'task-6-synthesis',
      name: 'Risk Synthesis & Remediation',
      type: 'synthesis',
      status: 'scheduled',
      model: 'Frontier Model (Gemini 2.5 Pro)',
      modelTier: 'frontier',
      estimatedLatencyMs: 980,
      estimatedCarbonGrams: 12.4,
      estimatedCostUsd: 0.0065,
      qualityConfidence: 97,
      requiredQualityThreshold: 90,
      priority: 'critical',
      deadlineMs: 1200,
      slackMs: 160,
      dependencies: ['Quality Gate & Hallucination Guard'],
      decisionReason: {
        headline: 'Reserved frontier model for high-stakes final output',
        explanation: 'Because early stages preserved 59.6% carbon, the scheduler comfortably allocated the remaining carbon budget for Gemini 2.5 Pro for deep nuanced reasoning.',
        tradeOffs: 'Allocated 12.4 gCO₂e specifically for executive-ready compliance findings.',
        confidenceScore: 97,
        policyTriggered: 'Policy CP-BUD-03: Whole-Workflow Budget Allocation',
      },
    },
  ];

  const handleInspectNode = (node: WorkflowNode) => {
    setSelectedNode(node);
    setIsDrawerOpen(true);
  };

  // Decisions list adhering strictly to user request
  const decisions = [
    {
      id: 'dec-1',
      decision: 'Used smaller model',
      why: 'Quality requirement already satisfied (predicted confidence 96% exceeded 85% requirement).',
      impact: '-36.8 gCO₂e (-74% vs frontier baseline)',
      icon: CheckCircle2,
      iconColor: 'text-[#007A52]',
      bgColor: 'bg-[#E7F8F1]',
    },
    {
      id: 'dec-2',
      decision: 'Delayed Task 4',
      why: 'Task has sufficient deadline slack (+1,400 ms on non-critical branch).',
      impact: 'Shifted compute into clean solar/wind grid window',
      icon: ArrowDownRight,
      iconColor: 'text-[#B9770E]',
      bgColor: 'bg-[#FEF5E7]',
    },
    {
      id: 'dec-3',
      decision: 'Quality gate passed',
      why: 'Confidence (94.2%) exceeded threshold, ensuring high grounding.',
      impact: 'Avoided frontier model escalation loop',
      icon: ShieldCheck,
      iconColor: 'text-[#007A52]',
      bgColor: 'bg-[#E7F8F1]',
    },
    {
      id: 'dec-4',
      decision: 'Targeted frontier model allocation',
      why: 'Reserved carbon budget specifically for final executive risk synthesis.',
      impact: 'Maximized analytical depth within 50.0 gCO₂e budget ceiling',
      icon: Sparkles,
      iconColor: 'text-[#0A0D0C]',
      bgColor: 'bg-[#F7F8F5]',
    },
  ];

  // DAG Structure partition
  const stage1Node = allNodes[0]; // Document Analysis
  const stage2Nodes = [allNodes[1], allNodes[2], allNodes[3]]; // Policy Retrieval, Contract Extraction, Delayed Audit
  const stage3Node = allNodes[4]; // Quality Gate
  const stage4Node = allNodes[5]; // Risk Synthesis

  return (
    <div className="max-w-6xl mx-auto space-y-7 pb-16">
      {/* ==================================================
          1. TOP METRICS & WORKFLOW HEALTH
          Show only four primary metrics:
          - Carbon: 24.9 gCO₂e
          - Workflow Time: 1.52 s
          - Quality: 94.6%
          - Budget Remaining: 25.1 gCO₂e
          ================================================== */}
      <section className="space-y-4">
        {/* 4 Top Metric Cards */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3.5">
          {/* Carbon */}
          <div className="rounded-xl border border-[#DDE2DE] bg-[#FFFFFF] p-4 shadow-xs transition-colors hover:border-[#C9D0CB]">
            <span className="text-[11px] font-semibold text-[#8A918D] uppercase tracking-wider block">
              Carbon
            </span>
            <div className="flex items-baseline gap-1.5 mt-1 mb-1">
              <span className="text-2xl sm:text-3xl font-bold font-mono text-[#0A0D0C] tracking-tight">
                24.9
              </span>
              <span className="text-xs font-mono font-medium text-[#68706B]">
                gCO₂e
              </span>
            </div>
            <p className="text-xs text-[#68706B]">
              Estimated workflow emissions
            </p>
          </div>

          {/* Workflow Time */}
          <div className="rounded-xl border border-[#DDE2DE] bg-[#FFFFFF] p-4 shadow-xs transition-colors hover:border-[#C9D0CB]">
            <span className="text-[11px] font-semibold text-[#8A918D] uppercase tracking-wider block">
              Workflow Time
            </span>
            <div className="flex items-baseline gap-1.5 mt-1 mb-1">
              <span className="text-2xl sm:text-3xl font-bold font-mono text-[#0A0D0C] tracking-tight">
                1.52
              </span>
              <span className="text-xs font-mono font-medium text-[#68706B]">
                s
              </span>
            </div>
            <p className="text-xs text-[#68706B]">
              Total wall-clock duration
            </p>
          </div>

          {/* Quality */}
          <div className="rounded-xl border border-[#DDE2DE] bg-[#FFFFFF] p-4 shadow-xs transition-colors hover:border-[#C9D0CB]">
            <span className="text-[11px] font-semibold text-[#8A918D] uppercase tracking-wider block">
              Quality
            </span>
            <div className="flex items-baseline gap-1.5 mt-1 mb-1">
              <span className="text-2xl sm:text-3xl font-bold font-mono text-[#007A52] tracking-tight">
                94.6%
              </span>
            </div>
            <p className="text-xs text-[#68706B]">
              Average confidence score
            </p>
          </div>

          {/* Budget Remaining */}
          <div className="rounded-xl border border-[#DDE2DE] bg-[#FFFFFF] p-4 shadow-xs transition-colors hover:border-[#C9D0CB]">
            <span className="text-[11px] font-semibold text-[#8A918D] uppercase tracking-wider block">
              Budget Remaining
            </span>
            <div className="flex items-baseline gap-1.5 mt-1 mb-1">
              <span className="text-2xl sm:text-3xl font-bold font-mono text-[#0A0D0C] tracking-tight">
                25.1
              </span>
              <span className="text-xs font-mono font-medium text-[#68706B]">
                gCO₂e
              </span>
            </div>
            <p className="text-xs text-[#68706B]">
              Against 50.0 g budget
            </p>
          </div>
        </div>

        {/* WORKFLOW HEALTH: Compact status section */}
        <div className="rounded-lg border border-[#DDE2DE] bg-[#FFFFFF] px-4 py-3 shadow-xs flex flex-wrap items-center justify-between gap-3 text-xs">
          <div className="flex items-center gap-2 text-[#8A918D] font-medium">
            <span className="text-[11px] uppercase tracking-wider font-semibold text-[#0A0D0C]">
              Workflow Health:
            </span>
          </div>

          <div className="flex flex-wrap items-center gap-4 sm:gap-8 font-medium">
            {/* Carbon: Within Budget */}
            <div className="flex items-center gap-2">
              <span className="w-2 h-2 rounded-full bg-[#00D98B]" />
              <span className="text-[#68706B]">Carbon:</span>
              <span className="text-[#007A52] font-semibold">Within Budget</span>
            </div>

            {/* Quality: Above Requirement */}
            <div className="flex items-center gap-2">
              <span className="w-2 h-2 rounded-full bg-[#00D98B]" />
              <span className="text-[#68706B]">Quality:</span>
              <span className="text-[#007A52] font-semibold">Above Requirement</span>
            </div>

            {/* Deadline: On Track */}
            <div className="flex items-center gap-2">
              <span className="w-2 h-2 rounded-full bg-[#00D98B]" />
              <span className="text-[#68706B]">Deadline:</span>
              <span className="text-[#007A52] font-semibold">On Track</span>
            </div>
          </div>
        </div>
      </section>

      {/* ==================================================
          2. MAIN WORKFLOW
          The workflow should be the largest and most important section.
          Heading: "Workflow"
          Subheading: "Multimodal Compliance Workflow"
          Show the DAG clearly.
          Each default node shows ONLY:
          Task
          Model
          Status
          ================================================== */}
      <section className="space-y-3.5">
        <div className="flex flex-col sm:flex-row sm:items-baseline justify-between gap-1">
          <div>
            <h2 className="text-xl sm:text-2xl font-bold tracking-tight text-[#0A0D0C]">
              Workflow
            </h2>
            <p className="text-xs sm:text-sm text-[#68706B] mt-0.5">
              Multimodal Compliance Workflow
            </p>
          </div>
          <span className="text-xs text-[#8A918D] font-mono">
            Click any task node to inspect why CarbonPilot chose it
          </span>
        </div>

        {/* Clear DAG Visualization Box */}
        <div className="rounded-xl border border-[#DDE2DE] bg-[#FFFFFF] p-5 sm:p-7 shadow-xs overflow-x-auto">
          <div className="min-w-[860px] flex items-center justify-between gap-4 py-2">
            {/* STAGE 1: INGEST */}
            <div className="flex flex-col items-center space-y-2">
              <span className="text-[10px] font-mono text-[#8A918D] uppercase tracking-wider">
                Stage 1 • Root
              </span>
              <WorkflowNodeCard
                node={stage1Node}
                isSelected={selectedNode?.id === stage1Node.id}
                onSelect={handleInspectNode}
              />
            </div>

            {/* Connector Arrow Split */}
            <div className="flex flex-col items-center justify-center shrink-0 px-1 text-[#8A918D]">
              <span className="text-[10px] font-mono text-[#007A52] mb-1">branch</span>
              <ArrowRight className="w-4 h-4 text-[#00D98B]" />
            </div>

            {/* STAGE 2: PARALLEL EXECUTION (3 Tasks) */}
            <div className="flex flex-col items-center space-y-3">
              <span className="text-[10px] font-mono text-[#8A918D] uppercase tracking-wider">
                Stage 2 • Parallel Tasks
              </span>
              <div className="space-y-3">
                {stage2Nodes.map((node) => (
                  <WorkflowNodeCard
                    key={node.id}
                    node={node}
                    isSelected={selectedNode?.id === node.id}
                    onSelect={handleInspectNode}
                  />
                ))}
              </div>
            </div>

            {/* Connector Arrow Join */}
            <div className="flex flex-col items-center justify-center shrink-0 px-1 text-[#8A918D]">
              <span className="text-[10px] font-mono text-[#007A52] mb-1">verify</span>
              <ArrowRight className="w-4 h-4 text-[#00D98B]" />
            </div>

            {/* STAGE 3: QUALITY GATE */}
            <div className="flex flex-col items-center space-y-2">
              <span className="text-[10px] font-mono text-[#8A918D] uppercase tracking-wider">
                Stage 3 • Gate
              </span>
              <WorkflowNodeCard
                node={stage3Node}
                isSelected={selectedNode?.id === stage3Node.id}
                onSelect={handleInspectNode}
              />
            </div>

            {/* Connector Arrow to Synthesis */}
            <div className="flex flex-col items-center justify-center shrink-0 px-1 text-[#8A918D]">
              <span className="text-[10px] font-mono text-[#0A0D0C] mb-1">synthesize</span>
              <ArrowRight className="w-4 h-4 text-[#00D98B]" />
            </div>

            {/* STAGE 4: SYNTHESIS */}
            <div className="flex flex-col items-center space-y-2">
              <span className="text-[10px] font-mono text-[#8A918D] uppercase tracking-wider">
                Stage 4 • Frontier
              </span>
              <WorkflowNodeCard
                node={stage4Node}
                isSelected={selectedNode?.id === stage4Node.id}
                onSelect={handleInspectNode}
              />
            </div>
          </div>
        </div>
      </section>

      {/* ==================================================
          3. CARBONPILOT DECISIONS
          Below the workflow, create:
          "CarbonPilot Decisions"
          Show only the most important decisions:
          Each decision should have:
          Decision
          Why
          Impact
          ================================================== */}
      <section className="space-y-3.5">
        <div>
          <h3 className="text-base sm:text-lg font-bold text-[#0A0D0C] tracking-tight">
            CarbonPilot Decisions
          </h3>
          <p className="text-xs text-[#68706B] mt-0.5">
            Key dynamic optimization choices made across models, timing, and verification gates.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-3.5">
          {decisions.map((item) => {
            const Icon = item.icon;
            return (
              <div
                key={item.id}
                className="rounded-xl border border-[#DDE2DE] bg-[#FFFFFF] p-4.5 space-y-2.5 shadow-xs hover:border-[#C9D0CB] transition-colors"
              >
                {/* Decision title */}
                <div className="flex items-start gap-2.5">
                  <div className={`p-1.5 rounded-md ${item.bgColor} shrink-0 mt-0.5`}>
                    <Icon className={`w-4 h-4 ${item.iconColor}`} />
                  </div>
                  <div className="min-w-0">
                    <h4 className="text-sm font-semibold text-[#0A0D0C] leading-snug">
                      {item.decision}
                    </h4>
                  </div>
                </div>

                {/* Why */}
                <div className="pl-8 text-xs text-[#68706B] leading-relaxed">
                  <span className="font-semibold text-[#0A0D0C]">Why: </span>
                  {item.why}
                </div>

                {/* Impact */}
                <div className="pl-8 pt-1 flex items-center gap-1.5 text-xs">
                  <span className="font-semibold text-[#007A52]">Impact: </span>
                  <span className="font-mono text-[#007A52] font-semibold bg-[#E7F8F1] px-2 py-0.5 rounded border border-[#C9EBDC]">
                    {item.impact}
                  </span>
                </div>
              </div>
            );
          })}
        </div>
      </section>

      {/* ==================================================
          4. EXPLORE DEEPER: What-If, Baseline Comparison & Guided Demo
          ================================================== */}
      {onNavigateTab && (
        <section className="pt-1">
          <div className="rounded-xl border border-[#DDE2DE] bg-[#FFFFFF] p-4 sm:p-5 shadow-xs">
            <span className="text-[11px] font-mono text-[#8A918D] uppercase tracking-wider font-semibold block mb-3">
              Explore Decision Capabilities
            </span>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              <button
                onClick={() => onNavigateTab('what-if')}
                className="p-3.5 rounded-lg border border-[#DDE2DE] bg-[#F7F8F5] hover:bg-[#E7F8F1] hover:border-[#00D98B] transition-all text-left group cursor-pointer"
              >
                <div className="flex items-center justify-between mb-1">
                  <span className="text-xs font-bold text-[#0A0D0C] group-hover:text-[#007A52]">
                    What-If Engine
                  </span>
                  <Sliders className="w-3.5 h-3.5 text-[#007A52]" />
                </div>
                <p className="text-[11px] text-[#68706B] leading-relaxed">
                  Adjust sensitivity, latency &amp; carbon budgets to see the DAG re-optimize.
                </p>
              </button>

              <button
                onClick={() => onNavigateTab('comparison')}
                className="p-3.5 rounded-lg border border-[#DDE2DE] bg-[#F7F8F5] hover:bg-[#E7F8F1] hover:border-[#00D98B] transition-all text-left group cursor-pointer"
              >
                <div className="flex items-center justify-between mb-1">
                  <span className="text-xs font-bold text-[#0A0D0C] group-hover:text-[#007A52]">
                    Baseline vs CarbonPilot
                  </span>
                  <Scale className="w-3.5 h-3.5 text-[#007A52]" />
                </div>
                <p className="text-[11px] text-[#68706B] leading-relaxed">
                  Head-to-head comparison against static unoptimized frontier models.
                </p>
              </button>

              <button
                onClick={() => onNavigateTab('demo')}
                className="p-3.5 rounded-lg border border-[#DDE2DE] bg-[#F7F8F5] hover:bg-[#E7F8F1] hover:border-[#00D98B] transition-all text-left group cursor-pointer"
              >
                <div className="flex items-center justify-between mb-1">
                  <span className="text-xs font-bold text-[#0A0D0C] group-hover:text-[#007A52]">
                    3-Minute Demo Mode
                  </span>
                  <Sparkles className="w-3.5 h-3.5 text-[#007A52]" />
                </div>
                <p className="text-[11px] text-[#68706B] leading-relaxed">
                  Step-by-step walkthrough explaining decisions and trade-offs.
                </p>
              </button>
            </div>
          </div>
        </section>
      )}

      {/* ==================================================
          5. NODE DETAILS SIDE PANEL (SLIDE-OVER / BOTTOM SHEET)
          When a node is clicked:
          Open a side panel.
          Show:
          Task
          Model
          Status
          Carbon
          Latency
          Quality
          Cost
          Slack
          Dependencies

          Then prominently show:
          "Why did CarbonPilot choose this?"
          "Alternative considered"
          "Trade-off"
          ================================================== */}
      <Drawer
        id="node-details-drawer"
        isOpen={isDrawerOpen}
        onClose={() => setIsDrawerOpen(false)}
        title={selectedNode ? selectedNode.name : 'Task Details'}
        subtitle={selectedNode ? `Stage: ${selectedNode.type.toUpperCase()}` : ''}
        width="lg"
      >
        {selectedNode && (
          <div className="space-y-6">
            {/* Primary Task & Model Header */}
            <div className="p-4 rounded-xl border border-[#DDE2DE] bg-[#F7F8F5] space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-[11px] font-mono uppercase tracking-wider text-[#8A918D]">
                  Task & Assigned Model
                </span>
                <span className="inline-flex items-center gap-1.5 px-2 py-0.5 rounded-full text-[11px] font-medium bg-[#FFFFFF] border border-[#DDE2DE] text-[#0A0D0C]">
                  <span className="w-1.5 h-1.5 rounded-full bg-[#00D98B]" />
                  <span className="capitalize">{selectedNode.status}</span>
                </span>
              </div>
              <h3 className="text-base font-bold text-[#0A0D0C]">
                {selectedNode.name}
              </h3>
              <div className="flex items-center gap-2 text-xs font-mono text-[#68706B]">
                <Cpu className="w-3.5 h-3.5 text-[#007A52]" />
                <span>{selectedNode.model}</span>
                <span className="text-[#8A918D]">•</span>
                <span className="uppercase text-[10px] text-[#007A52] font-semibold">
                  Tier: {selectedNode.modelTier}
                </span>
              </div>
            </div>

            {/* Metrics Breakdown (Carbon, Latency, Quality, Cost, Slack) */}
            <div className="space-y-2">
              <span className="text-[11px] font-mono uppercase tracking-wider text-[#8A918D] font-semibold">
                Task Performance & Constraints
              </span>
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-3 text-xs">
                {/* Carbon */}
                <div className="p-3 rounded-lg border border-[#DDE2DE] bg-[#FFFFFF] shadow-2xs">
                  <span className="text-[11px] text-[#68706B] block">Carbon</span>
                  <span className="font-mono text-sm font-bold text-[#007A52] block mt-0.5">
                    {selectedNode.estimatedCarbonGrams} gCO₂e
                  </span>
                </div>

                {/* Latency */}
                <div className="p-3 rounded-lg border border-[#DDE2DE] bg-[#FFFFFF] shadow-2xs">
                  <span className="text-[11px] text-[#68706B] block">Latency</span>
                  <span className="font-mono text-sm font-bold text-[#0A0D0C] block mt-0.5">
                    {selectedNode.estimatedLatencyMs} ms
                  </span>
                </div>

                {/* Quality */}
                <div className="p-3 rounded-lg border border-[#DDE2DE] bg-[#FFFFFF] shadow-2xs">
                  <span className="text-[11px] text-[#68706B] block">Quality</span>
                  <span className="font-mono text-sm font-bold text-[#0A0D0C] block mt-0.5">
                    {selectedNode.qualityConfidence}%
                  </span>
                </div>

                {/* Cost */}
                <div className="p-3 rounded-lg border border-[#DDE2DE] bg-[#FFFFFF] shadow-2xs">
                  <span className="text-[11px] text-[#68706B] block">Cost</span>
                  <span className="font-mono text-sm font-semibold text-[#0A0D0C] block mt-0.5">
                    ${selectedNode.estimatedCostUsd.toFixed(5)}
                  </span>
                </div>

                {/* Slack */}
                <div className="p-3 rounded-lg border border-[#DDE2DE] bg-[#FFFFFF] shadow-2xs sm:col-span-2">
                  <span className="text-[11px] text-[#68706B] block">Deadline Slack</span>
                  <span className="font-mono text-sm font-semibold text-[#007A52] block mt-0.5">
                    +{selectedNode.slackMs} ms (Deadline: {selectedNode.deadlineMs} ms)
                  </span>
                </div>
              </div>
            </div>

            {/* Dependencies */}
            <div className="space-y-2">
              <span className="text-[11px] font-mono uppercase tracking-wider text-[#8A918D] font-semibold">
                Dependencies
              </span>
              <div className="p-3 rounded-lg border border-[#DDE2DE] bg-[#FFFFFF] text-xs">
                {selectedNode.dependencies.length === 0 ? (
                  <span className="text-[#68706B] italic">
                    None — root ingestion task starts immediately upon trigger.
                  </span>
                ) : (
                  <div className="flex flex-wrap gap-2">
                    {selectedNode.dependencies.map((dep, idx) => (
                      <span
                        key={idx}
                        className="px-2.5 py-1 rounded-md bg-[#F7F8F5] text-[#0A0D0C] font-mono text-[11px] border border-[#DDE2DE]"
                      >
                        {dep}
                      </span>
                    ))}
                  </div>
                )}
              </div>
            </div>

            {/* Prominent Section: WHY DID CARBONPILOT CHOOSE THIS? */}
            <div className="rounded-xl border border-[#007A52]/30 bg-[#E7F8F1]/40 p-5 space-y-4 shadow-xs">
              <div className="flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-[#007A52] shrink-0" />
                <h4 className="text-xs font-bold uppercase tracking-wider text-[#007A52]">
                  Why did CarbonPilot choose this?
                </h4>
              </div>

              {/* Rationale */}
              <p className="text-sm font-medium text-[#0A0D0C] leading-relaxed">
                {selectedNode.decisionReason.headline}
              </p>
              <p className="text-xs text-[#68706B] leading-relaxed">
                {selectedNode.decisionReason.explanation}
              </p>

              {/* Alternative Considered */}
              <div className="rounded-lg bg-[#FFFFFF] border border-[#DDE2DE] p-3.5 space-y-1">
                <span className="text-[10px] font-mono uppercase tracking-wider text-[#8A918D] font-bold">
                  Alternative Considered
                </span>
                <p className="text-xs text-[#0A0D0C]">
                  {selectedNode.modelTier === 'small'
                    ? 'Frontier Model (Gemini 2.5 Pro) with 98.2% quality, +8.4 gCO₂e emissions.'
                    : 'Small Model (Flash) with 88% confidence, deemed high risk for customer contractual commitments.'}
                </p>
              </div>

              {/* Trade-off */}
              <div className="rounded-lg bg-[#FFFFFF] border border-[#DDE2DE] p-3.5 space-y-1">
                <span className="text-[10px] font-mono uppercase tracking-wider text-[#8A918D] font-bold">
                  Trade-off Evaluated
                </span>
                <p className="text-xs text-[#0A0D0C]">
                  {selectedNode.decisionReason.tradeOffs || 'Reduced carbon emissions by 74% with zero SLA deadline breach.'}
                </p>
              </div>
            </div>
          </div>
        )}
      </Drawer>
    </div>
  );
};

export default OverviewView;
