import React from 'react';
import { WorkflowNode } from '../../types';

export interface WorkflowNodeCardProps {
  node: WorkflowNode;
  isSelected?: boolean;
  onSelect?: (node: WorkflowNode) => void;
  className?: string;
}

export const WorkflowNodeCard: React.FC<WorkflowNodeCardProps> = ({
  node,
  isSelected = false,
  onSelect,
  className = '',
}) => {
  const getFriendlyModelName = () => {
    if (node.modelTier === 'small') return 'Small Model';
    if (node.modelTier === 'frontier') return 'Frontier Model';
    if (node.modelTier === 'medium') return 'Medium Model';
    return 'Specialized Tool';
  };

  const getStatusDisplay = () => {
    switch (node.status) {
      case 'completed':
        return {
          label: 'Completed',
          dotClass: 'bg-[#00D98B]',
          badgeClass: 'bg-[#E7F8F1] text-[#007A52] border-[#C9EBDC]',
        };
      case 'running':
        return {
          label: 'Running',
          dotClass: 'bg-[#00D98B] animate-ping',
          badgeClass: 'bg-[#E7F8F1] text-[#007A52] border-[#C9EBDC]',
        };
      case 'delayed':
        return {
          label: 'Delayed (Solar Window)',
          dotClass: 'bg-[#F39C12]',
          badgeClass: 'bg-[#FEF5E7] text-[#B9770E] border-[#FAD7A0]',
        };
      case 'scheduled':
        return {
          label: 'Scheduled',
          dotClass: 'bg-[#68706B]',
          badgeClass: 'bg-[#F7F8F5] text-[#68706B] border-[#DDE2DE]',
        };
      case 'escalated':
        return {
          label: 'Escalated',
          dotClass: 'bg-[#E74C3C]',
          badgeClass: 'bg-[#FDEDEC] text-[#C0392B] border-[#F5B7B1]',
        };
      default:
        return {
          label: 'Pending',
          dotClass: 'bg-[#8A918D]',
          badgeClass: 'bg-[#F7F8F5] text-[#68706B] border-[#DDE2DE]',
        };
    }
  };

  const statusInfo = getStatusDisplay();

  return (
    <div
      id={`node-card-${node.id}`}
      onClick={() => onSelect?.(node)}
      className={`group relative w-56 sm:w-60 rounded-xl border p-4 transition-all duration-150 cursor-pointer select-none text-left ${
        isSelected
          ? 'border-[#00D98B] bg-[#FFFFFF] shadow-[0_0_0_1.5px_#00D98B,0_4px_12px_rgba(0,217,139,0.12)]'
          : 'border-[#DDE2DE] bg-[#FFFFFF] hover:border-[#C9D0CB] hover:shadow-[0_2px_8px_rgba(10,13,12,0.04)] shadow-xs'
      } ${className}`}
    >
      {/* 1. Task Name */}
      <h4 className="text-sm font-semibold text-[#0A0D0C] leading-snug truncate" title={node.name}>
        {node.name}
      </h4>

      {/* 2. Model */}
      <p className="text-xs text-[#68706B] font-mono mt-1 mb-3">
        {getFriendlyModelName()}
      </p>

      {/* 3. Status */}
      <div className="flex items-center justify-between pt-2.5 border-t border-[#DDE2DE]">
        <span
          className={`inline-flex items-center gap-1.5 px-2 py-0.5 rounded-full text-[11px] font-medium border ${statusInfo.badgeClass}`}
        >
          <span className={`w-1.5 h-1.5 rounded-full ${statusInfo.dotClass}`} />
          <span>{statusInfo.label}</span>
        </span>

        <span className="text-[11px] text-[#8A918D] group-hover:text-[#007A52] font-medium transition-colors">
          Inspect →
        </span>
      </div>
    </div>
  );
};

export default WorkflowNodeCard;
