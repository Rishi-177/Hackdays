import React from 'react';
import { WorkflowEdge } from '../../types';

export interface WorkflowEdgeSvgProps {
  edge: WorkflowEdge;
  fromX: number;
  fromY: number;
  toX: number;
  toY: number;
  className?: string;
}

export const WorkflowEdgeSvg: React.FC<WorkflowEdgeSvgProps> = ({
  edge,
  fromX,
  fromY,
  toX,
  toY,
  className = '',
}) => {
  // Compute smooth bezier curve between nodes
  const dx = toX - fromX;
  const controlPointOffset = Math.max(40, dx * 0.45);
  const pathData = `M ${fromX} ${fromY} C ${fromX + controlPointOffset} ${fromY}, ${toX - controlPointOffset} ${toY}, ${toX} ${toY}`;

  const isCritical = edge.isCriticalPath;

  return (
    <g className={`transition-all duration-200 ${className}`}>
      {/* Background shadow stroke */}
      <path
        d={pathData}
        fill="none"
        stroke="#0f172a"
        strokeWidth={isCritical ? 5 : 4}
        strokeLinecap="round"
      />

      {/* Main connection line */}
      <path
        d={pathData}
        fill="none"
        stroke={isCritical ? '#f59e0b' : '#334155'}
        strokeWidth={isCritical ? 2.5 : 1.5}
        strokeDasharray={isCritical ? 'none' : '4 3'}
        markerEnd={isCritical ? 'url(#arrow-critical)' : 'url(#arrow-default)'}
        className="transition-colors"
      />

      {/* Optional edge label */}
      {edge.label && (
        <text
          x={(fromX + toX) / 2}
          y={(fromY + toY) / 2 - 8}
          textAnchor="middle"
          className="text-[10px] fill-slate-400 font-mono select-none"
        >
          {edge.label}
        </text>
      )}
    </g>
  );
};

export const WorkflowSvgDefs: React.FC = () => {
  return (
    <defs>
      <marker
        id="arrow-default"
        viewBox="0 0 10 10"
        refX="8"
        refY="5"
        markerWidth="6"
        markerHeight="6"
        orient="auto-start-reverse"
      >
        <path d="M 0 1 L 10 5 L 0 9 z" fill="#475569" />
      </marker>
      <marker
        id="arrow-critical"
        viewBox="0 0 10 10"
        refX="8"
        refY="5"
        markerWidth="7"
        markerHeight="7"
        orient="auto-start-reverse"
      >
        <path d="M 0 1 L 10 5 L 0 9 z" fill="#f59e0b" />
      </marker>
    </defs>
  );
};
