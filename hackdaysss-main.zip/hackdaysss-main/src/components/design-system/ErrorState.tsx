import React from 'react';
import { AlertTriangle, RefreshCw } from 'lucide-react';
import { Button } from './Button';

export interface ErrorStateProps {
  id?: string;
  title?: string;
  message?: string;
  onRetry?: () => void;
  className?: string;
}

export const ErrorState: React.FC<ErrorStateProps> = ({
  id,
  title = 'Failed to load scheduler data',
  message = 'An error occurred while evaluating workflow dependencies or carbon coefficients.',
  onRetry,
  className = '',
}) => {
  return (
    <div
      id={id}
      className={`flex flex-col items-center justify-center p-8 sm:p-12 text-center rounded-xl border border-[#FECACA] bg-[#FEF2F2] ${className}`}
    >
      <div className="p-3 rounded-xl bg-[#FEE2E2] text-[#B91C1C] border border-[#FECACA] mb-3.5">
        <AlertTriangle className="w-6 h-6" aria-hidden="true" />
      </div>
      <h4 className="text-sm font-semibold text-[#7F1D1D] mb-1">{title}</h4>
      <p className="text-xs text-[#991B1B] max-w-sm leading-relaxed mb-4">
        {message}
      </p>
      {onRetry && (
        <Button variant="outline" size="sm" icon={RefreshCw} onClick={onRetry}>
          Retry Operation
        </Button>
      )}
    </div>
  );
};
