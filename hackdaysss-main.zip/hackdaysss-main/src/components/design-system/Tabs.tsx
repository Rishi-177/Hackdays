import React from 'react';
import { LucideIcon } from 'lucide-react';

export interface TabItem {
  id: string;
  label: string;
  count?: number | string;
  icon?: LucideIcon;
  badge?: string;
  disabled?: boolean;
}

export interface TabsProps {
  id?: string;
  tabs: TabItem[];
  activeTab: string;
  onChange: (tabId: string) => void;
  variant?: 'pills' | 'underline' | 'boxed';
  size?: 'sm' | 'md';
  className?: string;
}

export const Tabs: React.FC<TabsProps> = ({
  id,
  tabs,
  activeTab,
  onChange,
  variant = 'underline',
  className = '',
}) => {
  if (variant === 'pills') {
    return (
      <div
        id={id}
        role="tablist"
        className={`inline-flex items-center p-1 bg-[#F7F8F5] rounded-lg border border-[#DDE2DE] gap-1 overflow-x-auto max-w-full ${className}`}
      >
        {tabs.map((tab) => {
          const isActive = tab.id === activeTab;
          const Icon = tab.icon;

          return (
            <button
              key={tab.id}
              role="tab"
              aria-selected={isActive}
              disabled={tab.disabled}
              onClick={() => onChange(tab.id)}
              className={`inline-flex items-center gap-2 px-3 py-1.5 rounded-md text-xs font-medium transition-all select-none whitespace-nowrap cursor-pointer ${
                isActive
                  ? 'bg-[#FFFFFF] text-[#0A0D0C] shadow-xs border border-[#DDE2DE]'
                  : 'text-[#68706B] hover:text-[#0A0D0C] hover:bg-[#EBEFEA]'
              } ${tab.disabled ? 'opacity-40 cursor-not-allowed' : ''}`}
            >
              {Icon && <Icon className="w-3.5 h-3.5 shrink-0" />}
              <span>{tab.label}</span>
              {tab.count !== undefined && (
                <span
                  className={`text-[10px] px-1.5 py-0.2 rounded-full font-mono ${
                    isActive ? 'bg-[#F7F8F5] text-[#0A0D0C]' : 'bg-[#EBEFEA] text-[#68706B]'
                  }`}
                >
                  {tab.count}
                </span>
              )}
            </button>
          );
        })}
      </div>
    );
  }

  // Underline variant
  return (
    <div
      id={id}
      role="tablist"
      className={`flex items-center border-b border-[#DDE2DE] gap-6 overflow-x-auto ${className}`}
    >
      {tabs.map((tab) => {
        const isActive = tab.id === activeTab;
        const Icon = tab.icon;

        return (
          <button
            key={tab.id}
            role="tab"
            aria-selected={isActive}
            disabled={tab.disabled}
            onClick={() => onChange(tab.id)}
            className={`group inline-flex items-center gap-2 pb-3 text-xs sm:text-sm font-medium transition-all relative border-b-2 select-none whitespace-nowrap cursor-pointer ${
              isActive
                ? 'border-[#00D98B] text-[#0A0D0C]'
                : 'border-transparent text-[#68706B] hover:text-[#0A0D0C] hover:border-[#C9D0CB]'
            } ${tab.disabled ? 'opacity-40 cursor-not-allowed' : ''}`}
          >
            {Icon && <Icon className="w-4 h-4 shrink-0" />}
            <span>{tab.label}</span>
            {tab.count !== undefined && (
              <span
                className={`text-[11px] px-1.5 py-0.5 rounded-full font-mono ${
                  isActive ? 'bg-[#E7F8F1] text-[#007A52]' : 'bg-[#F7F8F5] text-[#68706B]'
                }`}
              >
                {tab.count}
              </span>
            )}
            {tab.badge && (
              <span className="text-[10px] font-mono px-1.5 py-0.5 rounded bg-[#F7F8F5] text-[#68706B] border border-[#DDE2DE]">
                {tab.badge}
              </span>
            )}
          </button>
        );
      })}
    </div>
  );
};
