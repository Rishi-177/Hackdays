import React from 'react';

export interface SliderProps {
  id?: string;
  label: string;
  value: number;
  min: number;
  max: number;
  step?: number;
  unit?: string;
  onChange: (val: number) => void;
  helperText?: string;
  variant?: 'emerald' | 'amber' | 'indigo';
  disabled?: boolean;
  className?: string;
}

export const Slider: React.FC<SliderProps> = ({
  id,
  label,
  value,
  min,
  max,
  step = 1,
  unit = '',
  onChange,
  helperText,
  variant = 'emerald',
  disabled = false,
  className = '',
}) => {
  const percentage = ((value - min) / (max - min)) * 100;

  const accentColors = {
    emerald: 'accent-[#00D98B]',
    amber: 'accent-[#F59E0B]',
    indigo: 'accent-[#4F46E5]',
  };

  return (
    <div className={`w-full space-y-2 ${className}`}>
      <div className="flex justify-between items-center text-xs">
        <label htmlFor={id} className="font-medium text-[#0A0D0C]">
          {label}
        </label>
        <span className="font-mono font-semibold text-[#0A0D0C] bg-[#F7F8F5] px-2 py-0.5 rounded border border-[#DDE2DE]">
          {value.toLocaleString()} {unit}
        </span>
      </div>

      <div className="relative flex items-center">
        <input
          type="range"
          id={id}
          min={min}
          max={max}
          step={step}
          value={value}
          disabled={disabled}
          onChange={(e) => onChange(Number(e.target.value))}
          className={`w-full h-2 bg-[#E5EAE7] rounded-lg appearance-none cursor-pointer disabled:opacity-50 disabled:cursor-not-allowed ${accentColors[variant]}`}
          style={{
            background: `linear-gradient(to right, #00D98B 0%, #00D98B ${percentage}%, #E5EAE7 ${percentage}%, #E5EAE7 100%)`,
          }}
        />
      </div>

      <div className="flex justify-between text-[11px] font-mono text-[#8A918D]">
        <span>{min} {unit}</span>
        {helperText && <span className="text-[#68706B] font-sans">{helperText}</span>}
        <span>{max} {unit}</span>
      </div>
    </div>
  );
};
