import React from 'react';
import { LucideIcon, Loader2 } from 'lucide-react';

export type ButtonVariant = 'primary' | 'secondary' | 'outline' | 'ghost' | 'danger' | 'eco';
export type ButtonSize = 'sm' | 'md' | 'lg';

export interface ButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: ButtonVariant;
  size?: ButtonSize;
  icon?: LucideIcon;
  iconPosition?: 'left' | 'right';
  isLoading?: boolean;
  children: React.ReactNode;
}

export const Button: React.FC<ButtonProps> = ({
  id,
  variant = 'primary',
  size = 'md',
  icon: Icon,
  iconPosition = 'left',
  isLoading = false,
  disabled,
  className = '',
  children,
  ...props
}) => {
  const baseStyles = 'inline-flex items-center justify-center transition-all duration-150 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#00D98B] focus:ring-offset-2 focus:ring-offset-[#FFFFFF] disabled:opacity-50 disabled:cursor-not-allowed whitespace-nowrap active:scale-[0.98] select-none cursor-pointer';

  const sizeStyles: Record<ButtonSize, string> = {
    sm: 'text-xs px-3 py-1.5 gap-1.5 font-medium',
    md: 'text-xs sm:text-sm px-4 py-2 gap-2 font-medium',
    lg: 'text-sm sm:text-base px-5 py-2.5 gap-2.5 font-semibold',
  };

  const variantStyles: Record<ButtonVariant, string> = {
    primary: 'bg-[#00D98B] hover:bg-[#00C47D] text-[#0A0D0C] font-semibold border border-transparent shadow-[0_1px_2px_rgba(10,13,12,0.06)]',
    eco: 'bg-[#E7F8F1] hover:bg-[#00D98B]/20 text-[#007A52] font-semibold border border-[#DDE2DE]',
    secondary: 'bg-[#FFFFFF] hover:bg-[#F7F8F5] text-[#0A0D0C] border border-[#DDE2DE] hover:border-[#C9D0CB] font-medium shadow-[0_1px_2px_rgba(10,13,12,0.04)]',
    outline: 'bg-transparent hover:bg-[#F7F8F5] text-[#0A0D0C] border border-[#DDE2DE] hover:border-[#C9D0CB]',
    ghost: 'bg-transparent hover:bg-[#F7F8F5] text-[#68706B] hover:text-[#0A0D0C]',
    danger: 'bg-[#FEF2F2] hover:bg-[#FEE2E2] text-[#B91C1C] border border-[#FECACA]',
  };

  return (
    <button
      id={id}
      disabled={disabled || isLoading}
      className={`${baseStyles} ${sizeStyles[size]} ${variantStyles[variant]} ${className}`}
      {...props}
    >
      {isLoading ? (
        <Loader2 className="w-4 h-4 animate-spin text-current" aria-hidden="true" />
      ) : Icon && iconPosition === 'left' ? (
        <Icon className="w-4 h-4 text-current" aria-hidden="true" />
      ) : null}
      <span>{children}</span>
      {!isLoading && Icon && iconPosition === 'right' ? (
        <Icon className="w-4 h-4 text-current" aria-hidden="true" />
      ) : null}
    </button>
  );
};
