import React from 'react';
import { Info, AlertTriangle, AlertCircle, CheckCircle2, X } from 'lucide-react';

export type AlertVariant = 'info' | 'warning' | 'error' | 'success';

export interface AlertProps {
  id?: string;
  variant?: AlertVariant;
  title?: string;
  children: React.ReactNode;
  onDismiss?: () => void;
  className?: string;
}

export const Alert: React.FC<AlertProps> = ({
  id,
  variant = 'info',
  title,
  children,
  onDismiss,
  className = '',
}) => {
  const variantConfig = {
    info: {
      container: 'bg-[#F7F8F5] border-[#DDE2DE] text-[#0A0D0C]',
      icon: Info,
      iconColor: 'text-[#68706B]',
    },
    warning: {
      container: 'bg-[#FFFBEB] border-[#FDE68A] text-[#B45309]',
      icon: AlertTriangle,
      iconColor: 'text-[#D97706]',
    },
    error: {
      container: 'bg-[#FEF2F2] border-[#FECACA] text-[#B91C1C]',
      icon: AlertCircle,
      iconColor: 'text-[#DC2626]',
    },
    success: {
      container: 'bg-[#E7F8F1] border-[#DDE2DE] text-[#007A52]',
      icon: CheckCircle2,
      iconColor: 'text-[#007A52]',
    },
  };

  const config = variantConfig[variant];
  const IconComponent = config.icon;

  return (
    <div
      id={id}
      role="alert"
      className={`rounded-lg border p-3.5 flex items-start gap-3 text-xs sm:text-sm ${config.container} ${className}`}
    >
      <IconComponent className={`w-4 h-4 mt-0.5 shrink-0 ${config.iconColor}`} aria-hidden="true" />
      <div className="flex-1 space-y-1">
        {title && <h5 className="font-semibold tracking-tight text-[#0A0D0C]">{title}</h5>}
        <div className="text-[#68706B] leading-relaxed">{children}</div>
      </div>
      {onDismiss && (
        <button
          onClick={onDismiss}
          className="p-1 rounded text-[#8A918D] hover:text-[#0A0D0C] transition-colors"
          aria-label="Dismiss alert"
        >
          <X className="w-3.5 h-3.5" />
        </button>
      )}
    </div>
  );
};
