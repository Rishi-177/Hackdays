import React from 'react';

export type StatusType =
  | 'running'
  | 'completed'
  | 'scheduled'
  | 'pending'
  | 'delayed'
  | 'escalated'
  | 'failed'
  | 'healthy'
  | 'warning'
  | 'critical';

export interface StatusIndicatorProps {
  id?: string;
  status: StatusType;
  label?: string;
  showPulse?: boolean;
  size?: 'sm' | 'md' | 'lg';
  className?: string;
}

export const StatusIndicator: React.FC<StatusIndicatorProps> = ({
  id,
  status,
  label,
  showPulse = false,
  size = 'md',
  className = '',
}) => {
  const statusConfig: Record<StatusType, { dot: string; text: string; defaultLabel: string }> = {
    running: {
      dot: 'bg-[#00D98B] ring-[#00D98B]/20',
      text: 'text-[#007A52] font-medium',
      defaultLabel: 'Running',
    },
    completed: {
      dot: 'bg-[#00D98B] ring-[#00D98B]/20',
      text: 'text-[#007A52] font-medium',
      defaultLabel: 'Completed',
    },
    scheduled: {
      dot: 'bg-[#68706B] ring-[#68706B]/20',
      text: 'text-[#68706B]',
      defaultLabel: 'Scheduled',
    },
    pending: {
      dot: 'bg-[#8A918D] ring-[#8A918D]/20',
      text: 'text-[#8A918D]',
      defaultLabel: 'Pending',
    },
    delayed: {
      dot: 'bg-[#D97706] ring-[#D97706]/20',
      text: 'text-[#B45309]',
      defaultLabel: 'Delayed (Slack)',
    },
    escalated: {
      dot: 'bg-[#007A52] ring-[#007A52]/20',
      text: 'text-[#007A52]',
      defaultLabel: 'Escalated',
    },
    failed: {
      dot: 'bg-[#DC2626] ring-[#DC2626]/20',
      text: 'text-[#B91C1C]',
      defaultLabel: 'Failed',
    },
    healthy: {
      dot: 'bg-[#00D98B] ring-[#00D98B]/20',
      text: 'text-[#007A52] font-medium',
      defaultLabel: 'Healthy',
    },
    warning: {
      dot: 'bg-[#D97706] ring-[#D97706]/20',
      text: 'text-[#B45309]',
      defaultLabel: 'Warning',
    },
    critical: {
      dot: 'bg-[#DC2626] ring-[#DC2626]/20',
      text: 'text-[#B91C1C]',
      defaultLabel: 'Critical',
    },
  };

  const config = statusConfig[status];
  const displayLabel = label || config.defaultLabel;

  const dotSize = {
    sm: 'w-1.5 h-1.5',
    md: 'w-2 h-2',
    lg: 'w-2.5 h-2.5',
  };

  const textSize = {
    sm: 'text-xs',
    md: 'text-xs',
    lg: 'text-sm',
  };

  const shouldPulse = showPulse || status === 'running';

  return (
    <div id={id} className={`inline-flex items-center gap-2 ${className}`}>
      <span className="relative flex items-center justify-center">
        {shouldPulse && (
          <span
            className={`animate-ping absolute inline-flex h-full w-full rounded-full opacity-75 ${config.dot}`}
          />
        )}
        <span
          className={`relative inline-flex rounded-full ring-2 ${dotSize[size]} ${config.dot}`}
        />
      </span>
      {displayLabel && (
        <span className={`${textSize[size]} ${config.text} select-none`}>
          {displayLabel}
        </span>
      )}
    </div>
  );
};
