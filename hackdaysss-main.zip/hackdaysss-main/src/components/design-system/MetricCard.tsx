import React from 'react';
import { LucideIcon, TrendingDown, TrendingUp, Minus } from 'lucide-react';

export interface MetricCardProps {
  id?: string;
  label: string;
  value: string | number;
  unit?: string;
  context: string; // Explanatory context e.g. "Estimated workflow carbon"
  trend?: {
    value: string;
    direction: 'down-good' | 'up-good' | 'down-bad' | 'up-bad' | 'neutral';
    label?: string;
  };
  icon?: LucideIcon;
  status?: 'optimal' | 'warning' | 'critical' | 'neutral';
  badge?: string;
  className?: string;
}

export const MetricCard: React.FC<MetricCardProps> = ({
  id,
  label,
  value,
  unit,
  context,
  trend,
  icon: Icon,
  badge,
  className = '',
}) => {
  const trendStyles = {
    'down-good': 'text-[#007A52] bg-[#E7F8F1] border-[#DDE2DE]',
    'up-good': 'text-[#007A52] bg-[#E7F8F1] border-[#DDE2DE]',
    'down-bad': 'text-[#B91C1C] bg-[#FEF2F2] border-[#FECACA]',
    'up-bad': 'text-[#B91C1C] bg-[#FEF2F2] border-[#FECACA]',
    neutral: 'text-[#68706B] bg-[#F7F8F5] border-[#DDE2DE]',
  };

  return (
    <div
      id={id}
      className={`rounded-xl border border-[#DDE2DE] bg-[#FFFFFF] p-5 shadow-[0_1px_3px_rgba(10,13,12,0.03)] hover:border-[#C9D0CB] transition-colors flex flex-col justify-between ${className}`}
    >
      <div className="flex items-start justify-between gap-3">
        <div className="space-y-1">
          <p className="text-[11px] font-semibold text-[#8A918D] tracking-wider uppercase">
            {label}
          </p>
          <div className="flex items-baseline gap-1.5 pt-1">
            <span className="text-2xl sm:text-3xl font-bold font-mono tracking-tight text-[#0A0D0C]">
              {value}
            </span>
            {unit && (
              <span className="text-sm font-medium text-[#68706B] font-mono select-none">
                {unit}
              </span>
            )}
          </div>
        </div>

        <div className="flex flex-col items-end gap-1.5">
          {Icon && (
            <div className="p-2 rounded-lg bg-[#F7F8F5] text-[#0A0D0C] border border-[#DDE2DE]">
              <Icon className="w-4 h-4 text-[#007A52]" aria-hidden="true" />
            </div>
          )}
          {badge && (
            <span className="text-[11px] font-mono px-2 py-0.5 rounded bg-[#E7F8F1] text-[#007A52] border border-[#DDE2DE]">
              {badge}
            </span>
          )}
        </div>
      </div>

      <div className="pt-4 mt-2 border-t border-[#DDE2DE] flex items-center justify-between text-xs gap-2">
        <span className="text-[#68706B] line-clamp-1 text-xs">{context}</span>
        {trend && (
          <span
            className={`inline-flex items-center gap-1 px-2 py-0.5 rounded text-xs font-mono font-medium border shrink-0 ${trendStyles[trend.direction]}`}
          >
            {trend.direction.includes('up') ? (
              <TrendingUp className="w-3 h-3" />
            ) : trend.direction.includes('down') ? (
              <TrendingDown className="w-3 h-3" />
            ) : (
              <Minus className="w-3 h-3" />
            )}
            <span>{trend.value}</span>
          </span>
        )}
      </div>
    </div>
  );
};
