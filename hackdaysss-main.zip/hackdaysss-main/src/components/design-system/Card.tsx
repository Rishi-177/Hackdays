import React from 'react';

export interface CardProps extends React.HTMLAttributes<HTMLDivElement> {
  variant?: 'default' | 'muted' | 'accent' | 'highlight';
  hoverEffect?: boolean;
  children: React.ReactNode;
}

export const Card: React.FC<CardProps> = ({
  id,
  variant = 'default',
  hoverEffect = false,
  className = '',
  children,
  ...props
}) => {
  const variantStyles = {
    default: 'bg-[#FFFFFF] border-[#DDE2DE] text-[#0A0D0C] shadow-[0_1px_3px_rgba(10,13,12,0.03)]',
    muted: 'bg-[#F7F8F5] border-[#DDE2DE] text-[#68706B]',
    accent: 'bg-[#FFFFFF] border-[#00D98B]/40 text-[#0A0D0C] ring-1 ring-[#00D98B]/20 shadow-sm',
    highlight: 'bg-[#E7F8F1] border-[#00D98B]/30 text-[#0A0D0C]',
  };

  const hoverStyles = hoverEffect
    ? 'hover:border-[#C9D0CB] hover:shadow-[0_4px_12px_rgba(10,13,12,0.05)] transition-all duration-200 cursor-pointer'
    : '';

  return (
    <div
      id={id}
      className={`rounded-xl border p-5 ${variantStyles[variant]} ${hoverStyles} ${className}`}
      {...props}
    >
      {children}
    </div>
  );
};

export const CardHeader: React.FC<React.HTMLAttributes<HTMLDivElement>> = ({
  className = '',
  children,
  ...props
}) => {
  return (
    <div className={`flex flex-col space-y-1.5 pb-4 border-b border-[#DDE2DE] ${className}`} {...props}>
      {children}
    </div>
  );
};

export const CardTitle: React.FC<React.HTMLAttributes<HTMLHeadingElement>> = ({
  className = '',
  children,
  ...props
}) => {
  return (
    <h3 className={`text-base font-semibold tracking-tight text-[#0A0D0C] ${className}`} {...props}>
      {children}
    </h3>
  );
};

export const CardDescription: React.FC<React.HTMLAttributes<HTMLParagraphElement>> = ({
  className = '',
  children,
  ...props
}) => {
  return (
    <p className={`text-xs text-[#68706B] leading-relaxed ${className}`} {...props}>
      {children}
    </p>
  );
};

export const CardContent: React.FC<React.HTMLAttributes<HTMLDivElement>> = ({
  className = '',
  children,
  ...props
}) => {
  return (
    <div className={`pt-4 ${className}`} {...props}>
      {children}
    </div>
  );
};

export const CardFooter: React.FC<React.HTMLAttributes<HTMLDivElement>> = ({
  className = '',
  children,
  ...props
}) => {
  return (
    <div className={`flex items-center pt-4 border-t border-[#DDE2DE] mt-4 ${className}`} {...props}>
      {children}
    </div>
  );
};
