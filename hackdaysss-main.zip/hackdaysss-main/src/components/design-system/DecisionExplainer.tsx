import React from 'react';
import { CheckCircle2, Cpu, Leaf, Clock } from 'lucide-react';
import { DecisionReason } from '../../types';

export interface DecisionExplainerProps {
  id?: string;
  reason: DecisionReason;
  nodeName?: string;
  modelName?: string;
  carbonSavedGrams?: number;
  latencySavedMs?: number;
  compact?: boolean;
  className?: string;
}

export const DecisionExplainer: React.FC<DecisionExplainerProps> = ({
  id,
  reason,
  nodeName,
  modelName,
  carbonSavedGrams,
  latencySavedMs,
  compact = false,
  className = '',
}) => {
  return (
    <div
      id={id}
      className={`rounded-xl border border-[#DDE2DE] bg-[#FFFFFF] p-5 shadow-sm space-y-4 ${className}`}
    >
      {/* Top Header */}
      <div className="flex items-center justify-between gap-3 pb-3 border-b border-[#DDE2DE]">
        <div>
          <span className="text-[11px] font-bold uppercase tracking-wider text-[#007A52]">
            Why did CarbonPilot choose this?
          </span>
          {nodeName && (
            <p className="text-xs text-[#68706B] mt-0.5 font-medium">{nodeName}</p>
          )}
        </div>

        {reason.policyTriggered && (
          <span className="text-[10px] font-mono text-[#68706B] bg-[#F7F8F5] px-2 py-0.5 rounded border border-[#DDE2DE]">
            {reason.policyTriggered}
          </span>
        )}
      </div>

      {/* Main decision headline & explanation */}
      <div className="space-y-2">
        <div className="flex items-start gap-2.5">
          <CheckCircle2 className="w-4 h-4 text-[#00D98B] mt-0.5 shrink-0" />
          <div>
            <h4 className="text-sm font-semibold text-[#0A0D0C]">
              {reason.headline}
            </h4>
            <p className="text-xs text-[#68706B] leading-relaxed mt-1">
              {reason.explanation}
            </p>
          </div>
        </div>

        {reason.tradeOffs && (
          <div className="ml-6.5 mt-2 rounded-lg bg-[#F7F8F5] border border-[#DDE2DE] p-3 text-xs text-[#68706B]">
            <span className="font-semibold text-[#0A0D0C]">Trade-off evaluated: </span>
            {reason.tradeOffs}
          </div>
        )}
      </div>

      {/* Visual metric chips */}
      {!compact && (
        <div className="pt-3 border-t border-[#DDE2DE] flex flex-wrap items-center gap-2 text-xs">
          {modelName && (
            <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded bg-[#F7F8F5] text-[#0A0D0C] border border-[#DDE2DE] font-mono text-[11px]">
              <Cpu className="w-3.5 h-3.5 text-[#68706B]" />
              <span>{modelName}</span>
            </span>
          )}

          {reason.confidenceScore !== undefined && (
            <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded bg-[#E7F8F1] text-[#007A52] border border-[#DDE2DE] font-mono text-[11px]">
              <span>Confidence:</span>
              <strong>{reason.confidenceScore}%</strong>
            </span>
          )}

          {carbonSavedGrams !== undefined && carbonSavedGrams > 0 && (
            <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded bg-[#E7F8F1] text-[#007A52] border border-[#DDE2DE] font-mono text-[11px]">
              <Leaf className="w-3.5 h-3.5 text-[#00D98B]" />
              <span>-{carbonSavedGrams} gCO₂e</span>
            </span>
          )}

          {latencySavedMs !== undefined && (
            <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded bg-[#F7F8F5] text-[#68706B] border border-[#DDE2DE] font-mono text-[11px]">
              <Clock className="w-3.5 h-3.5" />
              <span>{latencySavedMs > 0 ? `-${latencySavedMs}ms faster` : `+${Math.abs(latencySavedMs)}ms delay`}</span>
            </span>
          )}
        </div>
      )}
    </div>
  );
};
