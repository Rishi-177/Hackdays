import React from 'react';
import { ChevronDown } from 'lucide-react';

export interface SelectOption {
  value: string;
  label: string;
  description?: string;
  disabled?: boolean;
}

export interface SelectProps extends Omit<React.SelectHTMLAttributes<HTMLSelectElement>, 'onChange'> {
  label?: string;
  options: SelectOption[];
  value: string;
  onChange: (value: string) => void;
  helperText?: string;
  error?: string;
}

export const Select: React.FC<SelectProps> = ({
  id,
  label,
  options,
  value,
  onChange,
  helperText,
  error,
  disabled,
  className = '',
  ...props
}) => {
  return (
    <div className="w-full space-y-1.5">
      {label && (
        <label htmlFor={id} className="block text-xs font-medium text-[#0A0D0C]">
          {label}
        </label>
      )}

      <div className="relative">
        <select
          id={id}
          value={value}
          disabled={disabled}
          onChange={(e) => onChange(e.target.value)}
          className={`w-full appearance-none rounded-lg bg-[#FFFFFF] border border-[#DDE2DE] px-3 py-2 pr-9 text-xs sm:text-sm text-[#0A0D0C] focus:border-[#00D98B] focus:outline-none focus:ring-1 focus:ring-[#00D98B] disabled:opacity-50 disabled:cursor-not-allowed transition-colors shadow-xs ${
            error ? 'border-[#EF4444] focus:border-[#EF4444] focus:ring-[#EF4444]' : ''
          } ${className}`}
          {...props}
        >
          {options.map((opt) => (
            <option key={opt.value} value={opt.value} disabled={opt.disabled} className="bg-[#FFFFFF] text-[#0A0D0C]">
              {opt.label}
            </option>
          ))}
        </select>

        <div className="pointer-events-none absolute inset-y-0 right-0 flex items-center px-2.5 text-[#68706B]">
          <ChevronDown className="w-4 h-4" />
        </div>
      </div>

      {helperText && !error && (
        <p className="text-[11px] text-[#68706B] leading-tight">{helperText}</p>
      )}
      {error && (
        <p className="text-[11px] text-[#EF4444] leading-tight">{error}</p>
      )}
    </div>
  );
};
