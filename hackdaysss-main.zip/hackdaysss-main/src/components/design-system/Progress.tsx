import React from 'react';

export interface ProgressProps {
  id?: string;
  value: number; // 0 to 100
  max?: number;
  variant?: 'emerald' | 'amber' | 'rose' | 'sky' | 'slate' | 'dynamic';
  showLabel?: boolean;
  label?: string;
  unit?: string;
  thresholdMarker?: number; // e.g. budget warning threshold line at 80%
  size?: 'sm' | 'md' | 'lg';
  className?: string;
}

export const Progress: React.FC<ProgressProps> = ({
  id,
  value,
  max = 100,
  variant = 'dynamic',
  showLabel = false,
  label,
  unit = '%',
  thresholdMarker,
  size = 'md',
  className = '',
}) => {
  const percentage = Math.min(100, Math.max(0, (value / max) * 100));

  // Dynamic status based on percentage
  const getDynamicVariant = () => {
    if (percentage > 90) return 'rose';
    if (percentage > 70) return 'amber';
    return 'emerald';
  };

  const activeVariant = variant === 'dynamic' ? getDynamicVariant() : variant;

  const variantColors = {
    emerald: 'bg-[#00D98B]',
    amber: 'bg-[#F59E0B]',
    rose: 'bg-[#EF4444]',
    sky: 'bg-[#0284C7]',
    slate: 'bg-[#8A918D]',
  };

  const heightStyles = {
    sm: 'h-1.5',
    md: 'h-2.5',
    lg: 'h-4',
  };

  return (
    <div id={id} className={`w-full space-y-1.5 ${className}`}>
      {(showLabel || label) && (
        <div className="flex justify-between items-center text-xs font-medium text-[#0A0D0C]">
          <span>{label}</span>
          <span className="font-mono text-[#68706B]">
            {value.toLocaleString()} / {max.toLocaleString()}{unit} ({Math.round(percentage)}%)
          </span>
        </div>
      )}

      <div className={`relative w-full bg-[#E5EAE7] rounded-full overflow-hidden ${heightStyles[size]}`}>
        <div
          className={`h-full rounded-full transition-all duration-300 ease-out ${variantColors[activeVariant]}`}
          style={{ width: `${percentage}%` }}
        />

        {thresholdMarker !== undefined && thresholdMarker >= 0 && thresholdMarker <= 100 && (
          <div
            className="absolute top-0 bottom-0 w-0.5 bg-[#EF4444] z-10"
            style={{ left: `${thresholdMarker}%` }}
            title={`Threshold Marker: ${thresholdMarker}%`}
          />
        )}
      </div>
    </div>
  );
};
