import React from 'react';
import { LucideIcon, CheckCircle2, AlertTriangle, AlertCircle, Info, Leaf, Clock, Cpu } from 'lucide-react';

export type BadgeVariant =
  | 'success'
  | 'warning'
  | 'error'
  | 'info'
  | 'carbon'
  | 'latency'
  | 'model'
  | 'neutral'
  | 'outline';

export type BadgeSize = 'sm' | 'md';

export interface BadgeProps extends React.HTMLAttributes<HTMLSpanElement> {
  variant?: BadgeVariant;
  size?: BadgeSize;
  icon?: LucideIcon;
  showDefaultIcon?: boolean;
  children: React.ReactNode;
}

export const Badge: React.FC<BadgeProps> = ({
  id,
  variant = 'neutral',
  size = 'md',
  icon: CustomIcon,
  showDefaultIcon = false,
  className = '',
  children,
  ...props
}) => {
  const sizeStyles = {
    sm: 'text-[11px] px-2 py-0.5 gap-1 rounded-md font-medium',
    md: 'text-xs px-2.5 py-1 gap-1.5 rounded-md font-medium',
  };

  const variantStyles: Record<BadgeVariant, { container: string; defaultIcon?: LucideIcon }> = {
    success: {
      container: 'bg-[#E7F8F1] text-[#007A52] border border-[#DDE2DE]',
      defaultIcon: CheckCircle2,
    },
    warning: {
      container: 'bg-[#FFFBEB] text-[#B45309] border border-[#FDE68A]',
      defaultIcon: AlertTriangle,
    },
    error: {
      container: 'bg-[#FEF2F2] text-[#B91C1C] border border-[#FECACA]',
      defaultIcon: AlertCircle,
    },
    info: {
      container: 'bg-[#F7F8F5] text-[#68706B] border border-[#DDE2DE]',
      defaultIcon: Info,
    },
    carbon: {
      container: 'bg-[#E7F8F1] text-[#007A52] border border-[#DDE2DE]',
      defaultIcon: Leaf,
    },
    latency: {
      container: 'bg-[#FFFBEB] text-[#B45309] border border-[#FDE68A]',
      defaultIcon: Clock,
    },
    model: {
      container: 'bg-[#F7F8F5] text-[#0A0D0C] border border-[#DDE2DE] font-mono text-[11px]',
      defaultIcon: Cpu,
    },
    neutral: {
      container: 'bg-[#F7F8F5] text-[#68706B] border border-[#DDE2DE]',
    },
    outline: {
      container: 'bg-transparent text-[#68706B] border border-[#DDE2DE]',
    },
  };

  const currentConfig = variantStyles[variant];
  const IconComponent = CustomIcon || (showDefaultIcon ? currentConfig.defaultIcon : null);

  return (
    <span
      id={id}
      className={`inline-flex items-center whitespace-nowrap leading-none transition-colors select-none ${sizeStyles[size]} ${currentConfig.container} ${className}`}
      {...props}
    >
      {IconComponent && <IconComponent className="w-3 h-3 shrink-0" aria-hidden="true" />}
      <span>{children}</span>
    </span>
  );
};
