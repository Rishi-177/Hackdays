import React, { useEffect } from 'react';
import { X } from 'lucide-react';

export interface DrawerProps {
  id?: string;
  isOpen: boolean;
  onClose: () => void;
  title: string;
  subtitle?: string;
  children: React.ReactNode;
  footer?: React.ReactNode;
  width?: 'sm' | 'md' | 'lg' | 'xl';
}

export const Drawer: React.FC<DrawerProps> = ({
  id,
  isOpen,
  onClose,
  title,
  subtitle,
  children,
  footer,
  width = 'lg',
}) => {
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape' && isOpen) {
        onClose();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, onClose]);

  if (!isOpen) return null;

  const widthClasses = {
    sm: 'sm:max-w-sm',
    md: 'sm:max-w-md',
    lg: 'sm:max-w-lg',
    xl: 'sm:max-w-xl',
  };

  return (
    <div id={id} className="fixed inset-0 z-50 overflow-hidden" role="dialog" aria-modal="true">
      {/* Backdrop */}
      <div
        className="fixed inset-0 bg-[#0A0D0C]/35 backdrop-blur-xs transition-opacity animate-in fade-in duration-150"
        onClick={onClose}
        aria-hidden="true"
      />

      {/* Container: Bottom Sheet on Mobile, Slide-over on sm+ */}
      <div className="fixed inset-x-0 bottom-0 sm:inset-y-0 sm:right-0 sm:left-auto flex max-w-full">
        <div
          className={`w-full ${widthClasses[width]} max-h-[85vh] sm:max-h-full flex flex-col bg-[#FFFFFF] rounded-t-2xl sm:rounded-none border-t sm:border-t-0 sm:border-l border-[#DDE2DE] shadow-2xl transition-transform duration-200 ease-in-out`}
        >
          {/* Mobile Drag Indicator */}
          <div className="sm:hidden pt-2.5 pb-1 flex justify-center cursor-pointer" onClick={onClose}>
            <span className="w-10 h-1 rounded-full bg-[#DDE2DE]" />
          </div>

          {/* Drawer Header */}
          <div className="flex items-center justify-between px-5 py-4 border-b border-[#DDE2DE]">
            <div className="space-y-0.5 min-w-0 pr-3">
              <h2 className="text-base font-bold text-[#0A0D0C] truncate">{title}</h2>
              {subtitle && (
                <p className="text-xs text-[#68706B] font-normal truncate">{subtitle}</p>
              )}
            </div>
            <button
              onClick={onClose}
              className="p-1.5 rounded-md text-[#68706B] hover:text-[#0A0D0C] hover:bg-[#F7F8F5] border border-transparent hover:border-[#DDE2DE] transition-colors shrink-0 cursor-pointer"
              aria-label="Close panel"
            >
              <X className="w-4 h-4" />
            </button>
          </div>

          {/* Drawer Body */}
          <div className="flex-1 overflow-y-auto p-5 text-[#0A0D0C] space-y-6">
            {children}
          </div>

          {/* Drawer Footer */}
          {footer && (
            <div className="p-4 border-t border-[#DDE2DE] bg-[#F7F8F5] flex items-center justify-end gap-3 shrink-0">
              {footer}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default Drawer;
