import React from 'react';
import { Loader2 } from 'lucide-react';

export interface LoadingStateProps {
  id?: string;
  message?: string;
  subtitle?: string;
  className?: string;
}

export const LoadingState: React.FC<LoadingStateProps> = ({
  id,
  message = 'Calculating whole-workflow plan...',
  subtitle = 'Evaluating carbon-latency Pareto frontier across agent nodes',
  className = '',
}) => {
  return (
    <div
      id={id}
      className={`flex flex-col items-center justify-center p-8 sm:p-12 text-center rounded-xl border border-[#DDE2DE] bg-[#FFFFFF] shadow-sm ${className}`}
    >
      <Loader2 className="w-7 h-7 text-[#007A52] animate-spin mb-3" />
      <h4 className="text-sm font-semibold text-[#0A0D0C] mb-1">{message}</h4>
      {subtitle && (
        <p className="text-xs text-[#68706B] max-w-sm leading-relaxed">
          {subtitle}
        </p>
      )}
    </div>
  );
};
