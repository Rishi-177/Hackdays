import React from 'react';

export interface BarComparisonItem {
  label: string;
  baselineValue: number;
  carbonPilotValue: number;
  unit: string;
  formatValue?: (val: number) => string;
  inverseIsGood?: boolean; // true if lower is better (carbon, latency, cost)
}

export interface BarComparisonProps {
  id?: string;
  title?: string;
  subtitle?: string;
  items: BarComparisonItem[];
  className?: string;
}

export const BarComparison: React.FC<BarComparisonProps> = ({
  id,
  title,
  subtitle,
  items,
  className = '',
}) => {
  return (
    <div id={id} className={`space-y-4 ${className}`}>
      {(title || subtitle) && (
        <div className="space-y-0.5">
          {title && <h4 className="text-xs font-semibold text-[#0A0D0C] uppercase tracking-wider">{title}</h4>}
          {subtitle && <p className="text-xs text-[#68706B]">{subtitle}</p>}
        </div>
      )}

      <div className="space-y-3.5">
        {items.map((item, idx) => {
          const max = Math.max(item.baselineValue, item.carbonPilotValue) * 1.15 || 100;
          const baselinePct = (item.baselineValue / max) * 100;
          const cpPct = (item.carbonPilotValue / max) * 100;
          const delta = ((item.carbonPilotValue - item.baselineValue) / item.baselineValue) * 100;

          return (
            <div key={idx} className="space-y-1.5 text-xs">
              <div className="flex justify-between items-center text-[#0A0D0C]">
                <span className="font-semibold text-xs">{item.label}</span>
                <span
                  className={`font-mono text-xs px-2 py-0.5 rounded font-medium border ${
                    delta < 0
                      ? 'bg-[#E7F8F1] text-[#007A52] border-[#DDE2DE]'
                      : 'bg-[#FEF2F2] text-[#B91C1C] border-[#FECACA]'
                  }`}
                >
                  {delta > 0 ? `+${delta.toFixed(1)}%` : `${delta.toFixed(1)}%`}
                </span>
              </div>

              {/* Baseline vs CarbonPilot Bars */}
              <div className="space-y-2.5 bg-[#F7F8F5] p-3 rounded-lg border border-[#DDE2DE]">
                {/* Baseline Bar */}
                <div className="space-y-1">
                  <div className="flex items-center justify-between text-[11px]">
                    <span className="text-[#68706B] flex items-center gap-1.5 font-medium">
                      <span className="w-2 h-2 rounded-sm bg-[#8A918D] inline-block" />
                      Baseline (Frontier Static)
                    </span>
                    <span className="font-mono text-[#0A0D0C] font-medium">
                      {item.formatValue ? item.formatValue(item.baselineValue) : item.baselineValue} {item.unit}
                    </span>
                  </div>
                  <div className="w-full bg-[#DDE2DE] h-1.5 rounded-full overflow-hidden">
                    <div className="bg-[#8A918D] h-full rounded-full transition-all duration-300" style={{ width: `${baselinePct}%` }} />
                  </div>
                </div>

                {/* CarbonPilot Bar */}
                <div className="space-y-1 pt-0.5">
                  <div className="flex items-center justify-between text-[11px]">
                    <span className="text-[#007A52] font-semibold flex items-center gap-1.5">
                      <span className="w-2 h-2 rounded-sm bg-[#00D98B] inline-block" />
                      CarbonPilot (Optimized)
                    </span>
                    <span className="font-mono font-bold text-[#007A52]">
                      {item.formatValue ? item.formatValue(item.carbonPilotValue) : item.carbonPilotValue} {item.unit}
                    </span>
                  </div>
                  <div className="w-full bg-[#DDE2DE] h-1.5 rounded-full overflow-hidden">
                    <div className="bg-[#00D98B] h-full rounded-full transition-all duration-300" style={{ width: `${cpPct}%` }} />
                  </div>
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
