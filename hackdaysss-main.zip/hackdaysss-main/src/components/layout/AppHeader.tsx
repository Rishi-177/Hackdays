import React from 'react';
import { Compass, Menu, X, ArrowLeft, RefreshCw } from 'lucide-react';
import { NavigationTabId } from '../../types';

export interface AppHeaderProps {
  currentTab: NavigationTabId;
  onSelectTab: (tab: NavigationTabId) => void;
  mobileMenuOpen: boolean;
  onToggleMobileMenu: () => void;
  workflowName?: string;
  workflowStatus?: string;
  onTriggerSchedulerRun?: () => void;
  isRunningScheduler?: boolean;
  onNavigateLanding?: () => void;
}

export const AppHeader: React.FC<AppHeaderProps> = ({
  onSelectTab,
  mobileMenuOpen,
  onToggleMobileMenu,
  workflowName = 'Multimodal Compliance Workflow',
  workflowStatus = 'Optimized',
  onTriggerSchedulerRun,
  isRunningScheduler = false,
  onNavigateLanding,
}) => {
  return (
    <header className="sticky top-0 z-40 w-full border-b border-[#DDE2DE] bg-[#FFFFFF] shadow-[0_1px_3px_rgba(10,13,12,0.03)]">
      <div className="flex h-14 items-center justify-between px-4 sm:px-6">
        {/* Left: Mobile hamburger + Brand + Current workflow name + Status */}
        <div className="flex items-center gap-3 sm:gap-4 min-w-0">
          <button
            type="button"
            onClick={onToggleMobileMenu}
            className="lg:hidden p-1.5 rounded-md text-[#68706B] hover:text-[#0A0D0C] hover:bg-[#F7F8F5] border border-[#DDE2DE] focus:outline-none cursor-pointer"
            aria-label={mobileMenuOpen ? 'Close menu' : 'Open menu'}
          >
            {mobileMenuOpen ? <X className="w-4 h-4" /> : <Menu className="w-4 h-4" />}
          </button>

          {/* Logo / Brand Name */}
          <div
            onClick={() => (onNavigateLanding ? onNavigateLanding() : onSelectTab('overview'))}
            className="flex items-center gap-2 cursor-pointer select-none group shrink-0"
            title="Return to Product Landing Page"
          >
            <div className="flex h-7 w-7 items-center justify-center rounded-md bg-[#E7F8F1] border border-[#DDE2DE] text-[#007A52] group-hover:bg-[#00D98B]/20 transition-colors">
              <Compass className="w-4 h-4" />
            </div>
            <span className="text-sm font-bold tracking-tight text-[#0A0D0C] font-sans">
              CarbonPilot
            </span>
          </div>

          <div className="hidden sm:block h-4 w-px bg-[#DDE2DE] shrink-0" />

          {/* Current Workflow Name & Status */}
          <div className="flex items-center gap-2.5 min-w-0">
            <span className="text-xs font-semibold text-[#0A0D0C] truncate max-w-[200px] sm:max-w-[320px]">
              {workflowName}
            </span>
            <div className="inline-flex items-center gap-1.5 px-2 py-0.5 rounded-full bg-[#E7F8F1] border border-[#DDE2DE] text-[11px] font-medium text-[#007A52] shrink-0">
              <span className="w-1.5 h-1.5 rounded-full bg-[#00D98B] animate-pulse" />
              <span>{workflowStatus}</span>
            </div>
          </div>
        </div>

        {/* Right: One Primary Action — Optimize Workflow (+ Return to Landing link) */}
        <div className="flex items-center gap-2 sm:gap-3 shrink-0">
          {onNavigateLanding && (
            <button
              onClick={onNavigateLanding}
              className="hidden md:inline-flex items-center gap-1 text-xs text-[#68706B] hover:text-[#0A0D0C] px-2.5 py-1.5 rounded-md border border-transparent hover:border-[#DDE2DE] hover:bg-[#F7F8F5] transition-colors cursor-pointer"
            >
              <ArrowLeft className="w-3.5 h-3.5 text-[#007A52]" />
              <span>Landing Page</span>
            </button>
          )}

          {/* Primary Action Button */}
          <button
            onClick={onTriggerSchedulerRun}
            disabled={isRunningScheduler}
            className="inline-flex items-center justify-center gap-2 px-3.5 py-1.5 rounded-md text-xs font-semibold bg-[#00D98B] text-[#0A0D0C] hover:bg-[#00C47D] active:bg-[#00B070] transition-all duration-150 shadow-xs cursor-pointer disabled:opacity-70 disabled:cursor-not-allowed"
          >
            <RefreshCw
              className={`w-3.5 h-3.5 text-[#0A0D0C] ${
                isRunningScheduler ? 'animate-spin' : ''
              }`}
            />
            <span>{isRunningScheduler ? 'Optimizing...' : 'Optimize Workflow'}</span>
          </button>
        </div>
      </div>
    </header>
  );
};

export default AppHeader;
