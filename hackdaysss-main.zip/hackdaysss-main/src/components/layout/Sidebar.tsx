import React from 'react';
import {
  LayoutDashboard,
  GitMerge,
  ShieldCheck,
  Leaf,
  Sliders,
  Clock,
  PlayCircle,
  Scale,
  Sparkles,
  ArrowLeft,
  LucideIcon,
} from 'lucide-react';
import { NavigationTabId } from '../../types';

export interface SidebarProps {
  currentTab: NavigationTabId;
  onSelectTab: (tab: NavigationTabId) => void;
  carbonBudgetConsumed?: number;
  carbonBudgetAllocated?: number;
  onCloseMobile?: () => void;
  onNavigateLanding?: () => void;
}

interface NavItem {
  id: NavigationTabId;
  label: string;
  icon: LucideIcon;
}

export const Sidebar: React.FC<SidebarProps> = ({
  currentTab,
  onSelectTab,
  carbonBudgetConsumed = 24.9,
  carbonBudgetAllocated = 50.0,
  onCloseMobile,
  onNavigateLanding,
}) => {
  const navItems: NavItem[] = [
    { id: 'overview', label: 'Overview', icon: LayoutDashboard },
    { id: 'optimizer', label: 'Workflow', icon: GitMerge },
    { id: 'quality', label: 'Quality & Escalation', icon: ShieldCheck },
    { id: 'budget', label: 'Carbon Budget', icon: Leaf },
    { id: 'deadline', label: 'Deadline & Slack', icon: Clock },
    { id: 'what-if', label: 'What-If', icon: Sliders },
    { id: 'comparison', label: 'Baseline vs CarbonPilot', icon: Scale },
    { id: 'demo', label: 'Demo Mode', icon: Sparkles },
  ];

  const handleNavClick = (tabId: NavigationTabId) => {
    onSelectTab(tabId);
    if (onCloseMobile) {
      onCloseMobile();
    }
  };

  const budgetPct = Math.round((carbonBudgetConsumed / carbonBudgetAllocated) * 100);

  return (
    <aside className="w-64 shrink-0 border-r border-[#DDE2DE] bg-[#FFFFFF] flex flex-col justify-between h-[calc(100vh-3.5rem)] overflow-y-auto">
      <div className="p-3 space-y-4">
        {onNavigateLanding && (
          <button
            onClick={() => {
              if (onCloseMobile) onCloseMobile();
              onNavigateLanding();
            }}
            className="w-full flex items-center gap-2 px-3 py-2 rounded-md text-xs font-medium text-[#68706B] hover:text-[#0A0D0C] hover:bg-[#F7F8F5] border border-[#DDE2DE] transition-colors cursor-pointer"
          >
            <ArrowLeft className="w-3.5 h-3.5 text-[#007A52]" />
            <span>Landing Page</span>
          </button>
        )}

        <div className="space-y-1">
          {navItems.map((item) => {
            const Icon = item.icon;
            const isActive = currentTab === item.id;

            return (
              <button
                key={item.id}
                onClick={() => handleNavClick(item.id)}
                className={`w-full flex items-center justify-between px-3 py-2.5 rounded-md text-xs transition-colors select-none relative cursor-pointer ${
                  isActive
                    ? 'bg-[#E7F8F1] text-[#0A0D0C] font-semibold'
                    : 'text-[#68706B] hover:text-[#0A0D0C] hover:bg-[#F7F8F5]'
                }`}
              >
                {/* Active green indicator */}
                {isActive && (
                  <span className="absolute left-0 top-1.5 bottom-1.5 w-1 rounded-r bg-[#00D98B]" />
                )}

                <div className="flex items-center gap-2.5 truncate">
                  <Icon
                    className={`w-4 h-4 shrink-0 ${
                      isActive ? 'text-[#007A52]' : 'text-[#8A918D]'
                    }`}
                  />
                  <span className="truncate">{item.label}</span>
                </div>
              </button>
            );
          })}
        </div>
      </div>

      {/* Sidebar Footer: Compact Carbon Budget */}
      <div className="p-3 border-t border-[#DDE2DE] bg-[#F7F8F5]">
        <div className="rounded-md border border-[#DDE2DE] bg-[#FFFFFF] p-3 space-y-2 shadow-xs">
          <div className="flex items-center justify-between text-xs">
            <span className="text-[#68706B] flex items-center gap-1.5 font-medium">
              <Leaf className="w-3.5 h-3.5 text-[#007A52]" />
              Carbon Budget
            </span>
            <span className="font-mono text-[#0A0D0C] font-semibold">
              {budgetPct}%
            </span>
          </div>

          <div className="w-full bg-[#DDE2DE] h-1.5 rounded-full overflow-hidden">
            <div
              className="h-full bg-[#00D98B] rounded-full transition-all duration-300"
              style={{ width: `${budgetPct}%` }}
            />
          </div>

          <div className="flex justify-between items-center text-[10px] text-[#8A918D] font-mono">
            <span>{carbonBudgetConsumed} gCO₂e used</span>
            <span>{carbonBudgetAllocated} gCO₂e cap</span>
          </div>
        </div>
      </div>
    </aside>
  );
};

export default Sidebar;
