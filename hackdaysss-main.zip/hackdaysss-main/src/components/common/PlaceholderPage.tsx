import React from 'react';
import { LucideIcon, CheckCircle2 } from 'lucide-react';
import { Card, CardHeader, CardTitle, CardDescription, CardContent } from '../design-system/Card';
import { Button } from '../design-system/Button';

export interface PlaceholderPageProps {
  id?: string;
  title: string;
  category?: string;
  description: string;
  icon: LucideIcon;
  plannedFeatures: string[];
  backendServiceMethodsReady?: string[];
  primaryActionLabel?: string;
  onPrimaryAction?: () => void;
  isPrimaryActionLoading?: boolean;
  onNavigateOverview?: () => void;
}

export const PlaceholderPage: React.FC<PlaceholderPageProps> = ({
  id,
  title,
  description,
  icon: Icon,
  plannedFeatures,
  primaryActionLabel,
  onPrimaryAction,
  isPrimaryActionLoading = false,
  onNavigateOverview,
}) => {
  return (
    <div id={id} className="max-w-4xl mx-auto space-y-6">
      {/* Header Banner */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 p-6 rounded-xl border border-[#DDE2DE] bg-[#FFFFFF] shadow-sm">
        <div className="flex items-start gap-4">
          <div className="p-3 rounded-xl bg-[#E7F8F1] text-[#007A52] border border-[#DDE2DE] shrink-0">
            <Icon className="w-5 h-5" />
          </div>
          <div className="space-y-1">
            <h1 className="text-xl font-bold tracking-tight text-[#0A0D0C]">
              {title}
            </h1>
            <p className="text-xs sm:text-sm text-[#68706B] max-w-xl leading-relaxed">
              {description}
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2 self-start sm:self-center shrink-0">
          {primaryActionLabel && onPrimaryAction && (
            <Button
              variant="eco"
              size="sm"
              isLoading={isPrimaryActionLoading}
              onClick={onPrimaryAction}
            >
              {primaryActionLabel}
            </Button>
          )}
          {onNavigateOverview && (
            <Button variant="secondary" size="sm" onClick={onNavigateOverview}>
              Back to Overview
            </Button>
          )}
        </div>
      </div>

      {/* Feature Capabilities Card */}
      <Card variant="default">
        <CardHeader>
          <CardTitle className="text-sm">Key Capabilities</CardTitle>
          <CardDescription>
            Core whole-workflow mechanisms and policies managed by this module
          </CardDescription>
        </CardHeader>
        <CardContent>
          <ul className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            {plannedFeatures.map((feat, idx) => (
              <li key={idx} className="flex items-start gap-2.5 text-xs text-[#0A0D0C] p-3 rounded-lg bg-[#F7F8F5] border border-[#DDE2DE]">
                <CheckCircle2 className="w-4 h-4 text-[#00D98B] shrink-0 mt-0.5" />
                <span>{feat}</span>
              </li>
            ))}
          </ul>
        </CardContent>
      </Card>
    </div>
  );
};
