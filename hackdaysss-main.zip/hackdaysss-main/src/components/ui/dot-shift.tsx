import React, { useEffect, useRef } from 'react';
import { cn } from '../../lib/utils';

export interface DotShiftProps {
  /** Animation speed multiplier (default: 0.5) */
  speed?: number;
  /** Grid scale factor (default: 0.6) */
  scale?: number;
  /** Size multiplier for individual dots (default: 0.6) */
  dotSize?: number;
  /** Softness / blur of the dots from 0 (sharp) to 1 (soft glow) (default: 0.5) */
  dotBlur?: number;
  /** Base color hue of the dots (default: #00D98B) */
  baseColor?: string;
  /** Additional CSS classes */
  className?: string;
  /** Maximum dot opacity (default: 0.35) */
  opacity?: number;
  /** Interactive mouse repulsion/shift effect (default: true) */
  interactive?: boolean;
}

/**
 * Dot Shift Component (from React Bits Pro @reactbits-starter/dot-shift-tw)
 * Renders a shifting, undulating grid of animated dots on an HTML5 canvas.
 */
export const DotShift: React.FC<DotShiftProps> = ({
  speed = 0.5,
  scale = 0.6,
  dotSize = 0.6,
  dotBlur = 0.5,
  baseColor = '#00D98B',
  className = '',
  opacity = 0.35,
  interactive = true,
}) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const mouseRef = useRef<{ x: number; y: number; active: boolean }>({
    x: -9999,
    y: -9999,
    active: false,
  });

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let animationFrameId: number;
    let width = 0;
    let height = 0;
    let startTime = performance.now();

    // Helper to parse hex/rgb color to rgba components
    const parseColorToRgba = (color: string, alpha: number): string => {
      // If it's already an rgba string, adjust alpha
      if (color.startsWith('rgba')) {
        return color.replace(/[\d\.]+\)$/g, `${alpha})`);
      }
      if (color.startsWith('rgb')) {
        return color.replace('rgb', 'rgba').replace(')', `, ${alpha})`);
      }
      // Hex to RGBA
      if (color.startsWith('#')) {
        let hex = color.slice(1);
        if (hex.length === 3) {
          hex = hex.split('').map((c) => c + c).join('');
        }
        const num = parseInt(hex, 16);
        const r = (num >> 16) & 255;
        const g = (num >> 8) & 255;
        const b = num & 255;
        return `rgba(${r}, ${g}, ${b}, ${alpha})`;
      }
      return color;
    };

    const handleResize = () => {
      if (!canvas) return;
      const rect = canvas.getBoundingClientRect();
      const dpr = Math.min(window.devicePixelRatio || 1, 2);
      width = rect.width;
      height = rect.height;
      canvas.width = Math.floor(width * dpr);
      canvas.height = Math.floor(height * dpr);
      ctx.setTransform(1, 0, 0, 1, 0, 0);
      ctx.scale(dpr, dpr);
    };

    const resizeObserver = new ResizeObserver(() => {
      handleResize();
    });

    resizeObserver.observe(canvas);
    handleResize();

    const handleMouseMove = (e: MouseEvent) => {
      if (!interactive || !canvas) return;
      const rect = canvas.getBoundingClientRect();
      mouseRef.current = {
        x: e.clientX - rect.left,
        y: e.clientY - rect.top,
        active: true,
      };
    };

    const handleMouseLeave = () => {
      mouseRef.current.active = false;
    };

    const parent = canvas.parentElement;
    if (parent && interactive) {
      parent.addEventListener('mousemove', handleMouseMove);
      parent.addEventListener('mouseleave', handleMouseLeave);
    }

    const render = (now: number) => {
      const elapsed = (now - startTime) * 0.001;
      ctx.clearRect(0, 0, width, height);

      if (width === 0 || height === 0) {
        animationFrameId = requestAnimationFrame(render);
        return;
      }

      // Safe bounds for scale and dot size
      const safeScale = Math.max(0.1, scale);
      const safeSpeed = Math.max(0, speed);
      const safeDotSize = Math.max(0.1, dotSize);
      const safeBlur = Math.min(Math.max(0, dotBlur), 1);

      // Spacing between dots in the grid
      const baseSpacing = 28;
      const spacing = baseSpacing / safeScale;
      const cols = Math.ceil(width / spacing) + 2;
      const rows = Math.ceil(height / spacing) + 2;

      // Base radius calculation
      const baseRadius = Math.max(1.2, spacing * 0.08 * safeDotSize);
      const blurMultiplier = 1 + safeBlur * 1.8;

      const time = elapsed * safeSpeed * 1.5;

      for (let r = -1; r < rows; r++) {
        for (let c = -1; c < cols; c++) {
          const originX = c * spacing;
          const originY = r * spacing;

          // Harmonic multi-frequency shift
          const waveA = Math.sin(c * 0.35 + r * 0.28 + time * 1.2);
          const waveB = Math.cos(c * 0.22 - r * 0.38 + time * 0.9);
          const waveC = Math.sin((c + r) * 0.18 + time * 0.6);

          let shiftX = (waveA * 0.6 + waveC * 0.4) * (spacing * 0.28);
          let shiftY = (waveB * 0.6 + waveC * 0.4) * (spacing * 0.28);

          let posX = originX + shiftX;
          let posY = originY + shiftY;

          // Interactive subtle deflection from cursor
          if (interactive && mouseRef.current.active) {
            const dx = posX - mouseRef.current.x;
            const dy = posY - mouseRef.current.y;
            const dist = Math.sqrt(dx * dx + dy * dy);
            const maxDist = 140;

            if (dist < maxDist && dist > 0) {
              const force = (1 - dist / maxDist) * 16;
              posX += (dx / dist) * force;
              posY += (dy / dist) * force;
            }
          }

          // Opacity variation across waves
          const waveAlpha = 0.5 + 0.5 * Math.sin(c * 0.4 + r * 0.3 + time);
          const currentAlpha = Math.min(1, Math.max(0.08, opacity * (0.6 + waveAlpha * 0.6)));

          const dotRad = baseRadius * (0.8 + 0.35 * waveAlpha);

          if (safeBlur > 0.08) {
            // Soft glowing radial dot
            const outerRad = dotRad * blurMultiplier;
            const gradient = ctx.createRadialGradient(
              posX,
              posY,
              0,
              posX,
              posY,
              outerRad
            );
            gradient.addColorStop(0, parseColorToRgba(baseColor, currentAlpha));
            gradient.addColorStop(
              0.5,
              parseColorToRgba(baseColor, currentAlpha * (1 - safeBlur * 0.5))
            );
            gradient.addColorStop(1, parseColorToRgba(baseColor, 0));

            ctx.beginPath();
            ctx.arc(posX, posY, outerRad, 0, Math.PI * 2);
            ctx.fillStyle = gradient;
            ctx.fill();
          } else {
            // Crisp dot
            ctx.beginPath();
            ctx.arc(posX, posY, dotRad, 0, Math.PI * 2);
            ctx.fillStyle = parseColorToRgba(baseColor, currentAlpha);
            ctx.fill();
          }
        }
      }

      animationFrameId = requestAnimationFrame(render);
    };

    animationFrameId = requestAnimationFrame(render);

    return () => {
      cancelAnimationFrame(animationFrameId);
      resizeObserver.disconnect();
      if (parent && interactive) {
        parent.removeEventListener('mousemove', handleMouseMove);
        parent.removeEventListener('mouseleave', handleMouseLeave);
      }
    };
  }, [speed, scale, dotSize, dotBlur, baseColor, opacity, interactive]);

  return (
    <canvas
      ref={canvasRef}
      aria-hidden="true"
      className={cn(
        'pointer-events-none absolute inset-0 h-full w-full select-none',
        className
      )}
    />
  );
};

export default DotShift;
