export { DotShift } from './dot-shift';
export type { DotShiftProps } from './dot-shift';
